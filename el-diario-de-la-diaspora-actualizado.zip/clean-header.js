const fs = require('fs');
let code = fs.readFileSync('src/components/site/Header.tsx', 'utf8');

// 1. Remove LanguageTranslator imports
code = code.replace(/import \{ LanguageTranslator, setPageLanguage \} from "\.\/LanguageTranslator";/g, '');
code = code.replace(/<LanguageTranslator \/>/g, '');

// 2. Remove Desktop Language Switcher
const desktopLanguageRegex = /\{\/\* SELECTOR DE IDIOMA \*\/\}[\s\S]*?<\/div>[\s\n]*<\/div>[\s\n]*\{\/\* BUSCAR, SUSCRIBIRSE Y PERFIL/g;
code = code.replace(desktopLanguageRegex, '{/* BUSCAR, SUSCRIBIRSE Y PERFIL');

// 3. Remove Mobile Language Switcher
const mobileLanguageRegex = /\{\/\* Selector de Idioma.*?[\s\S]*?<\/div>[\s\n]*<\/div>[\s\n]*<div>[\s\n]*<h3 className="text-xs/g;
code = code.replace(mobileLanguageRegex, '<div>\n                  <h3 className="text-xs');

fs.writeFileSync('src/components/site/Header.tsx', code, 'utf8');
console.log('Cleaned Language buttons');
