
'use client';
import type { SiteSettings } from "@/lib/types";
import { trackAdClick } from "@/lib/firestore";

interface AdBannerClientProps {
  ad?: SiteSettings['ads']['homeHorizontal'];
  defaultSize?: string;
  isVertical?: boolean;
  adName: string;
  pageSlug: string;
}

export const AdBannerClient = ({ ad, defaultSize, isVertical, adName, pageSlug }: AdBannerClientProps) => {
    const borderClass = isVertical ? 'border border-dashed border-amber-500/40 dark:border-amber-400/30' : 'border border-dashed border-amber-500/40 dark:border-amber-400/30';
    const dimensionsText = isVertical ? "300 x 250 px / 300 x 600 px (Medida Estándar Sidebar)" : "728 x 90 px (Leaderboard) / 320 x 50 px (Móvil)";

    if (ad && ad.enabled && ad.imageUrl) {
      const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
          if (ad.linkUrl) {
              e.preventDefault();
              trackAdClick(adName, pageSlug, ad.linkUrl);
              window.open(ad.linkUrl, '_blank');
          }
      };

      return (
          <div className={`relative bg-slate-100 dark:bg-slate-900 rounded-xl flex justify-center items-center text-center my-6 overflow-hidden shadow-sm ${defaultSize || ''} border border-slate-200/80 dark:border-slate-800`}>
              <a 
                href={ad.linkUrl}
                target="_blank" 
                rel="noopener noreferrer" 
                className="relative w-full h-full block group"
                onClick={handleClick}
              >
                  <img src={ad.imageUrl} alt={ad.label || "Anuncio"} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.02]" />
                  <span className="absolute bottom-1.5 right-2 bg-black/60 backdrop-blur-sm text-[9px] uppercase font-bold text-white px-1.5 py-0.5 rounded tracking-widest">
                    {ad.label || "Publicidad"}
                  </span>
              </a>
          </div>
      );
    }

    // Rendered visual AdSense mockup block if no custom image is configured
    return (
        <div className={`relative bg-amber-500/5 dark:bg-amber-950/20 rounded-xl flex flex-col justify-center items-center text-center p-4 my-6 shadow-xs ${defaultSize || 'w-full min-h-[90px]'} ${borderClass}`}>
            <span className="text-[10px] font-bold uppercase tracking-widest text-amber-700 dark:text-amber-400 bg-amber-500/10 px-2.5 py-0.5 rounded-full border border-amber-500/20 mb-1">
              ESPACIO RESERVADO GOOGLE ADSENSE
            </span>
            <span className="text-xs font-mono font-semibold text-slate-700 dark:text-slate-300">
              Formato: {dimensionsText}
            </span>
            <span className="text-[10px] text-slate-400 mt-1">
              Ubicación: {adName.replace(/-/g, ' ').toUpperCase()}
            </span>
        </div>
    );
};

