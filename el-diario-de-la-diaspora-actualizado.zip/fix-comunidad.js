const fs = require('fs');
let code = fs.readFileSync('src/app/comunidad/page.tsx', 'utf8');

const heroContent = `<div className="relative z-10 text-center px-4 max-w-3xl mx-auto flex flex-col items-center">
                <Image 
                    src="/logo-horizontal.png" 
                    alt="Logo El Diario de la Diáspora" 
                    width={300} 
                    height={80} 
                    className="h-16 w-auto object-contain mb-6 drop-shadow-xl brightness-[10] contrast-200 sepia-[0.3] hue-rotate-[180deg]" 
                    style={{ filter: 'brightness(0) invert(1) drop-shadow(0px 2px 4px rgba(0,0,0,0.5))' }}
                />
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-white font-headline tracking-tight mb-4 drop-shadow-lg">
                    Nuestra Comunidad
                </h1>
                <p className="text-lg md:text-xl text-slate-200 font-medium drop-shadow-md">
                    Más que un medio de comunicación, somos una familia comprometida con llevarte la mejor información todos los días.
                </p>
            </div>`;

// Replace the existing content
code = code.replace(/<div className="relative z-10 text-center px-4 max-w-3xl mx-auto">[\s\S]*?<\/div>/, heroContent);

fs.writeFileSync('src/app/comunidad/page.tsx', code, 'utf8');
console.log('Fixed comunidad page logo');
