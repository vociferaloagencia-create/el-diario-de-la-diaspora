const fs = require('fs');
const lines = fs.readFileSync('C:/Users/Legit/.gemini/antigravity/brain/22191237-8228-4784-ad3b-bd6e8f8557a1/.system_generated/logs/transcript_full.jsonl', 'utf8').split('\n');
for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('GENERIC') && lines[i].includes('Total Lines: 342')) {
    const idx = lines[i].indexOf('<nav ');
    console.log(lines[i].substring(idx - 100, idx + 2000));
    break;
  }
}
