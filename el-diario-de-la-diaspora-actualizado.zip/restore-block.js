const fs = require('fs');

let code = fs.readFileSync('src/components/site/Header.tsx', 'utf8');

const target = /<div className="space-y-2">[\s\S]*?NUESTRA COMUNIDAD[\s\S]*?<\/div>/;

const replacement = `<div className="space-y-2">
                  <h3 className="text-xs font-extrabold uppercase tracking-widest text-slate-400 dark:text-slate-500 mb-1">
                    INSTITUCIONAL
                  </h3>
                  <Link
                    href="/comunidad"
                    onClick={() => setIsSheetOpen(false)}
                    className="block text-xs font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-300 hover:text-primary py-1"
                  >
                    Nuestra Comunidad
                  </Link>
                  <Link
                    href="/category/la-diaspora"
                    onClick={() => setIsSheetOpen(false)}
                    className="block text-xs font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-300 hover:text-primary py-1"
                  >
                    Visión
                  </Link>
                </div>`;

code = code.replace(target, replacement);

fs.writeFileSync('src/components/site/Header.tsx', code, 'utf8');
console.log('Restored Institucional block');
