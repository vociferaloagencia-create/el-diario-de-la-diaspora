const fs = require('fs');

// 1. Fix Header.tsx
let headerCode = fs.readFileSync('src/components/site/Header.tsx', 'utf8');

// Remove translate="no"
headerCode = headerCode.replace(/<span translate="no">\{country\.name\}<\/span>/g, '<span>{country.name}</span>');

// Fix "PaÃ­ses"
headerCode = headerCode.replace(/PaÃ­ses/g, 'Países');

// Change "Chile" to "República de Chile" in the array to fix the translation bug
headerCode = headerCode.replace(/\{ name: 'Chile', slug: 'chile' \}/g, "{ name: 'República de Chile', slug: 'chile' }");

fs.writeFileSync('src/components/site/Header.tsx', headerCode, 'utf8');

// 2. Fix category/[slug]/page.tsx
let categoryCode = fs.readFileSync('src/app/category/[slug]/page.tsx', 'utf8');

// Remove translate="no"
categoryCode = categoryCode.replace(/\s+translate="no">/g, '>');

// Change "Chile" to "República de Chile" in the array
categoryCode = categoryCode.replace(/'Chile',/g, "'República de Chile',");

fs.writeFileSync('src/app/category/[slug]/page.tsx', categoryCode, 'utf8');

console.log('Fixed translations and Chile name');
