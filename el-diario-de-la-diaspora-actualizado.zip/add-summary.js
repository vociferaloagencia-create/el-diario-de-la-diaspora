const fs = require('fs');
let code = fs.readFileSync('src/components/site/ArticlePageClient.tsx', 'utf8');

const titleEnd = '</h1>';
if (code.includes(titleEnd) && !code.includes('article.summary')) {
  const insert = `
                      {article.summary && (
                        <p className="text-lg sm:text-xl text-slate-600 dark:text-slate-300 font-medium leading-relaxed mb-6 mt-4">
                          {article.summary}
                        </p>
                      )}
`;
  code = code.replace(titleEnd, titleEnd + insert);
  fs.writeFileSync('src/components/site/ArticlePageClient.tsx', code, 'utf8');
  console.log('Added summary subtitle');
}
