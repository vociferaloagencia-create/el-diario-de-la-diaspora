const fs = require('fs');
let code = fs.readFileSync('src/components/site/Header.tsx', 'utf8');

// Fix encoding issues in Header
code = code.replace(/Repblica/g, 'República');
code = code.replace(/Mxico/g, 'México');
code = code.replace(/Canad/g, 'Canadá');
code = code.replace(/Espaa/g, 'España');
code = code.replace(/Opinin/g, 'Opinión');
code = code.replace(/Dispora/g, 'Diáspora');
code = code.replace(/PaA-ses/g, 'Países');

// The weird arrow character
code = code.replace(/<span className="text-\[9px\] text-slate-400">\+'<\/span>/g, '<span className="text-[9px] text-slate-400">→</span>');

// Actually, just target the generic map inner content:
code = code.replace(/<span>\{country\.name\}<\/span>\s*<span className="text-\[9px\] text-slate-400">.*?<\/span>/gs, '<span translate="no">{country.name}</span>\n                                    <span className="text-[9px] text-slate-400">→</span>');

fs.writeFileSync('src/components/site/Header.tsx', code, 'utf8');
console.log('Fixed Header.tsx');
