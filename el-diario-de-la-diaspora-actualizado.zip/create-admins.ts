import { signUp, updateUserRole } from './src/lib/auth';

async function createAccounts() {
  try {
    console.log('Creating Sharleen...');
    const u1 = await signUp('Sharleen', 'sharleen@eldiariodeladiaspora.com', 'AdminSharleen2026');
    await updateUserRole(u1.uid, 'superadmin');
    console.log('Created Sharleen successfully!');
    
    console.log('Creating Cliente...');
    const u2 = await signUp('Cliente Principal', 'cliente@eldiariodeladiaspora.com', 'AdminCliente2026');
    await updateUserRole(u2.uid, 'superadmin');
    console.log('Created Cliente successfully!');
    
    process.exit(0);
  } catch (error) {
    console.error('Error creating accounts:', error);
    process.exit(1);
  }
}

createAccounts();
