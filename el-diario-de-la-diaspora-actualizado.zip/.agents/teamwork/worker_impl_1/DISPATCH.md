# Dispatch Assignment — Worker (Implementation)

## Identity
- Role: Worker (teamwork_preview_worker)
- Working directory: C:\Users\Legit\.gemini\antigravity\scratch\el-diario-de-la-diaspora-main\.agents\teamwork\worker_impl_1
- Project workspace: C:\Users\Legit\.gemini\antigravity\scratch\el-diario-de-la-diaspora-main
- Parent: Project Orchestrator (orchestrator_main)

## Mandatory Reading
1. `C:\Users\Legit\.gemini\antigravity\scratch\el-diario-de-la-diaspora-main\.agents\teamwork\ORIGINAL_REQUEST.md` (MUST READ FIRST)
2. `C:\Users\Legit\.gemini\antigravity\scratch\el-diario-de-la-diaspora-main\.agents\teamwork\PROJECT.md`
3. Explorer survey reports:
   - `C:\Users\Legit\.gemini\antigravity\scratch\el-diario-de-la-diaspora-main\.agents\teamwork\explorer_survey_1\survey_auth.md`
   - `C:\Users\Legit\.gemini\antigravity\scratch\el-diario-de-la-diaspora-main\.agents\teamwork\explorer_survey_2\survey_middleware.md`
   - `C:\Users\Legit\.gemini\antigravity\scratch\el-diario-de-la-diaspora-main\.agents\teamwork\explorer_survey_3\survey_editorial.md`

## MANDATORY INTEGRITY WARNING
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A teamwork_preview_auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

## Detailed Scope of Work
Implement the required fixes and features across the codebase:

### 1. Authentication & Timeout Resiliency (`src/lib/auth.ts`, `src/hooks/useUserRole.ts`)
- Implement `syncAuthCookies(user: User, role?: string): Promise<void>` that awaits `user.getIdToken()` and sets both `firebaseAuthToken` and `userRole` cookies (`SameSite=Lax; path=/; max-age=604800`).
- Ensure `syncAuthCookies` is called and awaited before returning from `signIn`, `signUp`, and `signInWithGoogle`.
- Implement `clearAuthCookies()` and call it on `signOut()`.
- Fix `onAuthUserChanged`: remove the early exit condition `if (authUser?.uid === currentUid && authUser) return;` so token and cookies are properly refreshed.
- Set strict 1800ms (1.8s) timeout default in `withTimeout<T>(promise, ms = 1800, fallbackValue)` and apply to all Firestore calls in `src/lib/auth.ts` (`getDoc`, `setDoc`, `updateDoc`, `getAllUsers`, `updateUserRole`).
- Ensure non-blocking timeout fallback to local/reader session works seamlessly without freezing or looping when `firestore.googleapis.com` is unreachable or blocked.
- Ensure `prompt: 'select_account'` is preserved on GoogleAuthProvider.
- Ensure role assignment assigns `role: 'user'` for readers, and `'admin'` for editorial staff.
- In `src/hooks/useUserRole.ts`, align `isIsolatedMode` check with `firebase.ts` so it doesn't mistakenly bypass Firestore when API key fallback is used.

### 2. Middleware & Redirect Loop Elimination (`src/middleware.ts`, `src/app/login/page.tsx`, `src/app/dashboard/layout.tsx`)
- In `src/middleware.ts`:
  - REMOVE the unconditional redirect `if (pathname === '/dashboard') return NextResponse.redirect('/dashboard/profile')`.
  - Read `firebaseAuthToken` and `userRole` from cookies.
  - If `pathname.startsWith('/dashboard')` and no `firebaseAuthToken`: redirect to `/login?redirect=${pathname}`.
  - If `userRole === 'user'` and pathname is `/dashboard` or admin routes (`/dashboard/articles*`, `/categories*`, `/ads*`, `/settings*`): redirect to `/dashboard/profile`.
  - If `userRole` is `'admin'`, `'editor'`, or `'superadmin'`: allow access to `/dashboard` and administrative routes.
  - If authenticated user accesses `/dashboard/profile`: allow access.
- In `src/app/login/page.tsx`:
  - Ensure login, registration, and Google OAuth navigation waits for cookie synchronization.
  - Redirect admin to `/dashboard` (or redirect URL) and reader to `/dashboard/profile`.
  - Handle already authenticated users gracefully without redirect bouncing.
- In `src/app/dashboard/layout.tsx`:
  - Ensure admin sidebar is strictly hidden for reader users (`role: 'user'`).
  - Reader view must show only the reader profile interface.

### 3. Editorial CMS, Storage & Firestore Security Rules (`src/lib/firestore.ts`, `src/components/admin/*`, `firestore.rules`)
- In `src/lib/firestore.ts`:
  - Add missing imports from `'firebase/storage'`: `ref`, `uploadBytes`, `getDownloadURL`, `deleteObject`.
  - Standardize all query timeouts to 1800ms.
  - Implement `updateCategory(id: string, data: Partial<Category>): Promise<void>`.
- In `src/components/admin/articles/ArticleForm.tsx`:
  - Add `showOnMostRead` switch/checkbox so editors can set articles to show on most read.
- In `src/components/admin/CategoriesTable.tsx`:
  - Support updating existing categories.
- In `firestore.rules`:
  - Fix collection mismatches: support `settings`, `ad_clicks`, `reels`, `authors`, and article comments.
  - Fix privilege escalation vulnerability: prevent non-admin users from modifying the `role` field on their user document.

### 4. Build & Verification
- Run `npm.cmd run typecheck` and `npm.cmd run build` to verify clean compilation.
- Write a detailed completion report to `handoff.md` in your working directory.
