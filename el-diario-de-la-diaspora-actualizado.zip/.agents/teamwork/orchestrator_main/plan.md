# Orchestration Plan — El Diario de la Diáspora

## Objective
Verify, fix, and fully implement the El Diario de la Diáspora newspaper platform according to ORIGINAL_REQUEST.md.

## Phases

### Phase 0: Architectural Survey & Scope Mapping
- Spawn 3 parallel Explorers:
  1. Explorer 1: Authentication & User Profiles (Firebase Auth, Email/Password, Google OAuth `select_account`, role assignment, non-blocking firestore timeouts).
  2. Explorer 2: Middleware & Routing (Next.js middleware, redirect loop prevention `/login` <-> `/dashboard/profile`, session handling, route protection).
  3. Explorer 3: Editorial Panel & Public Site (Articles, categories, hero section, most-read grid, admin dashboard, reader dashboard, Firestore security rules).
- Collect reports, synthesize Feature Inventory, Architecture, Code Layout, Interface Contracts into `PROJECT.md`.

### Phase 1: Parallel Tracks Setup
- Spawn E2E Testing Track Orchestrator / Test Writer to establish comprehensive test suite (Tiers 1-4) and `TEST_READY.md`.
- Finalize Milestones for Implementation Track:
  - Milestone 1: Core Auth, Non-blocking Firestore Timeouts, Google OAuth `select_account`
  - Milestone 2: Middleware, Route Protection & Redirect Loop Prevention
  - Milestone 3: Reader vs Admin Dashboards, Public Views & Firestore Security Rules
  - Milestone 4: Final Integration & E2E Test Suite Pass (Tiers 1-4)
  - Milestone 5: Adversarial Hardening (Tier 5)

### Phase 2: Implementation & Verification Loop
For each milestone:
1. 3 Explorers analyze and plan
2. 1 Worker implements
3. 2 Reviewers inspect
4. 2 Challengers test
5. 1 Forensic Auditor verifies integrity
6. Gate check (strict AND)

### Phase 3: Final Reporting
- Present verified completion to Sentinel.
