# Dispatch Assignment — Test Writer (E2E Testing Track)

## Identity
- Role: Test Writer (teamwork_preview_test_writer)
- Working directory: C:\Users\Legit\.gemini\antigravity\scratch\el-diario-de-la-diaspora-main\.agents\teamwork\test_writer_1
- Project workspace: C:\Users\Legit\.gemini\antigravity\scratch\el-diario-de-la-diaspora-main
- Parent: Project Orchestrator (orchestrator_main)

## Mandatory Reading
1. `C:\Users\Legit\.gemini\antigravity\scratch\el-diario-de-la-diaspora-main\.agents\teamwork\ORIGINAL_REQUEST.md` (MUST READ FIRST)
2. `C:\Users\Legit\.gemini\antigravity\scratch\el-diario-de-la-diaspora-main\.agents\teamwork\PROJECT.md`

## Mission
Establish the E2E Testing Track:
1. Create `TEST_INFRA.md` at project root or in `.agents/teamwork/TEST_INFRA.md` describing the opaque-box, requirement-driven test architecture.
2. Build an automated E2E test harness and test suites covering all 4 tiers based on user requirements:
   - Tier 1: Feature Coverage (isolated happy-path tests for each feature: Email/password auth, Google OAuth `select_account`, role assignment, timeout fallback, public reader views, admin dashboard routes, middleware protection).
   - Tier 2: Boundary & Corner Cases (empty/invalid credentials, offline/adblocked firestore network timeouts at 1.8s, unauthorized reader accessing admin URLs, unauthenticated users accessing protected paths).
   - Tier 3: Cross-Feature Combinations (register reader -> verify profile redirect -> attempt admin route -> verify bounce back to profile; admin login -> verify overview access -> logout -> verify cookies cleared -> verify middleware redirect to login).
   - Tier 4: Real-World Workload Scenarios (editorial workflow: article creation, most-read toggle, category update; reader experience: reading articles, browsing categories, profile viewing).
3. The test runner must be executable via a simple command (e.g., `npm.cmd test` or `node scripts/run-e2e-tests.js`).
4. Publish `TEST_READY.md` summarizing the test runner command, tiers, counts, and feature checklist.
5. Deliver handoff report at `handoff.md` in your working directory.

## 2026-09-26T04:21:48Z
<USER_REQUEST>
You are the Test Writer for the E2E Testing Track of El Diario de la Diáspora.
Your working directory: C:\Users\Legit\.gemini\antigravity\scratch\el-diario-de-la-diaspora-main\.agents\teamwork\test_writer_1
Project workspace directory: C:\Users\Legit\.gemini\antigravity\scratch\el-diario-de-la-diaspora-main

Read your dispatch assignment from:
C:\Users\Legit\.gemini\antigravity\scratch\el-diario-de-la-diaspora-main\.agents\teamwork\test_writer_1\DISPATCH.md
Read the original user request from:
C:\Users\Legit\.gemini\antigravity\scratch\el-diario-de-la-diaspora-main\.agents\teamwork\ORIGINAL_REQUEST.md
Read the project specifications from:
C:\Users\Legit\.gemini\antigravity\scratch\el-diario-de-la-diaspora-main\.agents\teamwork\PROJECT.md

Build the comprehensive E2E test suite (Tiers 1-4) following the 4-tier methodology:
1. Create TEST_INFRA.md.
2. Implement automated E2E test suites covering:
   - Tier 1: Feature Coverage (Email/password, Google OAuth select_account, role assignment, timeouts, middleware, public site, admin dashboard).
   - Tier 2: Boundary & Corner Cases (invalid auth, timeout 1.8s offline fallback, unauthorized dashboard access).
   - Tier 3: Cross-Feature Combinations (reader flow, admin flow, logout cookie wipe and bounce back).
   - Tier 4: Real-World Workload Scenarios (editorial workflow, reader viewing).
3. Ensure the test suite can be run via an automated runner script (e.g. `node scripts/run-e2e-tests.js`).
4. Publish TEST_READY.md when the test suite is ready.
5. Write handoff report to handoff.md in your working directory and notify parent.
</USER_REQUEST>
