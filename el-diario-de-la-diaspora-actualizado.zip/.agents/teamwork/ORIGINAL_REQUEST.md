# Original User Request

## 2026-09-26T04:07:02Z

# Teamwork Project Prompt — El Diario de la Diáspora

Goal: Verify and complete full implementation of El Diario de la Diáspora newspaper platform, ensuring robust Firebase Authentication (Email/Password & Google Sign-In with select_account prompt), non-blocking Firestore integration with 1.8s timeouts, zero middleware redirect loops, and complete reader/admin dashboard functionality.

Working directory: C:\Users\Legit\.gemini\antigravity\scratch\el-diario-de-la-diaspora-main
Integrity mode: development

## Requirements

### R1. Authentication and User Profiles
- Seamless Email/Password registration and sign-in for regular reader users.
- Google OAuth popup sign-in with account selection prompt (`prompt: 'select_account'`).
- Automatic user profile creation and role assignment (`role: 'user'` for regular readers, `role: 'admin'` for explicit editorial staff).
- Non-blocking fail-safe timeout protection so auth never freezes or loops even if browser adblockers block firestore.googleapis.com.

### R2. Content Management and Editorial Panel
- Dynamic category navigation, article rendering, hero section management, and most-read article grid.
- Admin dashboard for article creation, editing, category configuration, and ad slot management.
- Multi-role security rules in Firestore protecting administrative routes and write access.

## Acceptance Criteria

### Authentication
- [ ] Clicking "Crear Cuenta" or "Crear Cuenta con Google" logs the user in as a reader (`role: 'user'`) and redirects to `/dashboard/profile`.
- [ ] No infinite redirect loops between `/login` and `/dashboard/profile`.
- [ ] All network or offline timeouts gracefully fall back to local reader session without crashing.

### Public Site & Dashboard
- [ ] Public readers can view articles, categories, search, and site footer links.
- [ ] Admin sidebar is strictly hidden for non-admin readers.
