# Project: El Diario de la Diáspora

## Architecture
Next.js 14 App Router platform with Firebase Authentication and Cloud Firestore, serving as a modern digital newspaper for the diaspora.
- **Client App**: Next.js App Router (`src/app/`)
  - Public routes: `/` (Home/Hero/Most Read), `/categoria/[slug]`, `/articulo/[slug]`, `/buscar`
  - Auth routes: `/login` (Tabs: Login, Register, Google OAuth popup with `prompt: 'select_account'`)
  - Protected reader route: `/dashboard/profile` (Strictly hidden admin sidebar)
  - Protected editorial/admin routes: `/dashboard` (Overview), `/dashboard/articles`, `/dashboard/categories`, `/dashboard/ads`, `/dashboard/settings`
- **Routing & Edge**: Next.js `middleware.ts` verifying `firebaseAuthToken` and `userRole` cookies.
- **Auth Layer**: `src/lib/auth.ts`, `src/hooks/use-auth.tsx`, `src/hooks/useUserRole.ts` with synchronous cookie synchronization and strict 1.8s (1800ms) non-blocking timeout fallback.
- **Data & Storage**: `src/lib/firestore.ts`, `src/lib/firebase.ts`, `firestore.rules`.

## Feature Inventory
| # | Feature | Description | Milestone | Source |
|---|---------|-------------|-----------|--------|
| 1 | Google OAuth Account Select | Google Sign-in popup with `prompt: 'select_account'` | M1 | ORIGINAL_REQUEST §R1 |
| 2 | Email/Password Registration & Login | Reader account creation and sign-in | M1 | ORIGINAL_REQUEST §R1 |
| 3 | Non-blocking 1.8s Timeout Resiliency | All Firestore operations timeout at 1800ms with graceful reader fallback when offline/adblocked | M1 | ORIGINAL_REQUEST §R1 |
| 4 | Synchronous Cookie Synchronization | `syncAuthCookies` sets `firebaseAuthToken` and `userRole` before returning from auth functions | M1 | survey_auth & survey_middleware |
| 5 | Role Assignment & Persistence | Automatic `role: 'user'` for readers, `role: 'admin'` for editorial staff, mock session sync | M1 | ORIGINAL_REQUEST §R1 |
| 6 | Redirect Loop Elimination | Zero bouncing between `/login` and `/dashboard/profile` | M2 | ORIGINAL_REQUEST §Acceptance |
| 7 | Role-Based Edge Middleware | Route readers to `/dashboard/profile`, admins to `/dashboard`, unauth to `/login` | M2 | survey_middleware |
| 8 | Reader Dashboard & Sidebar Shielding | Reader profile at `/dashboard/profile`, admin sidebar strictly hidden for readers | M2 | ORIGINAL_REQUEST §R2 |
| 9 | Admin CMS Dashboard Overview | Admin access to `/dashboard` without unwanted redirects | M2 | survey_middleware & survey_editorial |
| 10 | Firebase Storage Fix | Import missing storage functions in `src/lib/firestore.ts` (`ref`, `uploadBytes`, `getDownloadURL`, `deleteObject`) | M3 | survey_editorial |
| 11 | Editorial Controls (Most Read & Categories) | `showOnMostRead` switch in `ArticleForm.tsx` and `updateCategory` in `CategoriesTable.tsx` | M3 | survey_editorial |
| 12 | Firestore Security Rules Multi-Role | Match actual collections (`settings`, `ad_clicks`, `reels`, `authors`), block privilege escalation on user `role` | M3 | ORIGINAL_REQUEST §R2 |
| 13 | Full E2E Acceptance Pass (Tiers 1-4) | 100% pass on comprehensive E2E test suite | M4 | Project Architecture |
| 14 | Adversarial Hardening (Tier 5) | White-box stress test against network drops, adblockers, privilege escalations | M5 | Project Architecture |

## Milestones
| # | Name | Scope | Dependencies | Status |
|---|------|-------|-------------|--------|
| 1 | Auth Resiliency & Cookie Sync | `src/lib/auth.ts`, `src/hooks/useUserRole.ts` | none | PLANNED |
| 2 | Middleware & Redirect Loop Prevention | `src/middleware.ts`, `src/app/login/page.tsx`, `src/app/dashboard/layout.tsx` | M1 | PLANNED |
| 3 | Editorial CMS, Storage & Security Rules | `src/lib/firestore.ts`, `src/components/admin/*`, `firestore.rules` | M1 | PLANNED |
| 4 | Final E2E Test Suite Pass | Opaque-box E2E test suite (Tiers 1-4) | M1, M2, M3 | PLANNED |
| 5 | Adversarial Coverage Hardening | Tier 5 white-box stress testing | M4 | PLANNED |

## Interface Contracts
### Auth Layer ↔ Middleware & Pages
- `syncAuthCookies(user: User, role?: string): Promise<void>`:
  - Sets `firebaseAuthToken=<idToken>; path=/; max-age=604800; SameSite=Lax`
  - Sets `userRole=<role>; path=/; max-age=604800; SameSite=Lax`
  - Invoked synchronously inside `signIn`, `signUp`, and `signInWithGoogle` before returning.
- `clearAuthCookies(): void`:
  - Expires `firebaseAuthToken` and `userRole` with `expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/`.
- `withTimeout<T>(promise: Promise<T>, ms: number = 1800, fallbackValue?: T): Promise<T>`:
  - Strict 1800ms limit on all Firestore network calls.
  - Returns fallback value or throws timeout error gracefully handled by caller.

### Middleware ↔ Dashboard Routes
- Path `/dashboard*` without `firebaseAuthToken` → HTTP 307 to `/login?redirect=<pathname>`
- Path `/dashboard` with `userRole === 'user'` → HTTP 307 to `/dashboard/profile`
- Path `/dashboard/articles*`, `/categories*`, `/ads*`, `/settings*` with `userRole === 'user'` → HTTP 307 to `/dashboard/profile`
- Path `/dashboard` with `userRole === 'admin' \|\| 'editor' \|\| 'superadmin'` → Allow (NextResponse.next())
- Path `/dashboard/profile` for any authenticated user → Allow (NextResponse.next())

## Code Layout
- `src/lib/auth.ts`: Authentication core, Firebase Auth, Google OAuth, timeout logic, cookie management
- `src/hooks/useUserRole.ts`: Role resolution hook
- `src/middleware.ts`: Next.js Edge route guard and cookie checker
- `src/app/login/page.tsx`: Login / Register / Google Auth UI and client redirect handling
- `src/app/dashboard/layout.tsx`: Dashboard layout, sidebar visibility gatekeeper
- `src/app/dashboard/page.tsx`: Admin CMS Overview
- `src/app/dashboard/profile/page.tsx`: Reader profile page
- `src/lib/firestore.ts`: Firestore CRUD, category management, storage upload helpers, timeout wrapping
- `firestore.rules`: Multi-role Cloud Firestore security rules
