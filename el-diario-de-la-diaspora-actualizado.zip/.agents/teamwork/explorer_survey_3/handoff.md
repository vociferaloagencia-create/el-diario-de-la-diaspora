# Handoff Report — Explorer 3: Editorial Content, Dashboards & Security Rules

**Milestone**: Survey & Discovery (R2)  
**Agent**: Explorer 3  
**Working Directory**: `C:\Users\Legit\.gemini\antigravity\scratch\el-diario-de-la-diaspora-main\.agents\teamwork\explorer_survey_3`  
**Report Document**: `survey_editorial.md`  

---

## 1. Observation

### Observation 1: Middleware Unconditional Redirect Locks Admins Out of `/dashboard`
- **File**: `src/middleware.ts`, lines 15–17
- **Code**:
  ```ts
  15:   if (pathname === '/dashboard') {
  16:     return NextResponse.redirect(new URL('/dashboard/profile', request.url));
  17:   }
  ```
- **Context**: The admin sidebar has a navigation link to `/dashboard` (labeled "Panel Principal" in `src/app/dashboard/layout.tsx` line 160). When clicked, this middleware unconditionally redirects the user to `/dashboard/profile`, preventing access to `src/app/dashboard/page.tsx` and `DashboardClient.tsx`.

### Observation 2: Firestore Security Rules Collection Name Mismatch & Missing Rules
- **File**: `firestore.rules`, lines 46–56
- **Code**:
  ```firestore
  46:     // Collection: siteSettings
  47:     match /siteSettings/{settingId} {
  48:       allow read: if true;
  49:       allow write: if isAdmin();
  50:     }
  51: 
  52:     // Collection: statistics
  53:     match /statistics/{statId} {
  54:       allow read: if isAdmin();
  55:       allow write: if true; // Allow recording ad clicks / visits
  56:     }
  ```
- **Codebase reality**:
  - `src/lib/firestore.ts`, line 260 & 294: `const docRef = doc(db, 'settings', 'site');` (collection is `'settings'`, NOT `'siteSettings'`).
  - `src/lib/firestore.ts`, line 502 & 518: `collection(db, 'ad_clicks')` (collection is `'ad_clicks'`, NOT `'statistics'`).
  - `src/lib/firestore.ts`, line 547 & 557: `collection(db, 'reels')` (no rule exists in `firestore.rules`).
  - `src/lib/firestore.ts`, line 432: `getDocument<Author>('authors', id)` (no rule exists in `firestore.rules`).
  - `src/lib/seed.ts`, line 44: `doc(collection(db, 'articles', docId, 'comments'), commentId)` (subcollection rule missing).

### Observation 3: Privilege Escalation in `firestore.rules` for User Role
- **File**: `firestore.rules`, lines 27–32
- **Code**:
  ```firestore
  27:     match /users/{userId} {
  28:       allow read: if isAuthenticated();
  29:       allow create: if isAuthenticated() && isOwner(userId);
  30:       allow update: if isOwner(userId) || isAdmin();
  31:       allow delete: if isAdmin();
  32:     }
  ```
- **Context**: An authenticated user satisfies `isOwner(userId)` and can therefore create or update their user document with `{ role: 'admin' }` or `{ role: 'superadmin' }`.

### Observation 4: Missing Admin UI for "Most Read" Articles
- **File**: `src/components/admin/articles/ArticleForm.tsx`, lines 49–59 & 222
- **Code**:
  ```tsx
  222:   showOnMostRead: article.showOnMostRead || false, // Retain existing value
  ```
- **Context**: `showOnMostRead` and `mostReadOrder` are supported by the schema and queried on the public site (`getMostReadArticles()`), but there is no field or switch in `ArticleForm.tsx` or in `HomeLayoutForm.tsx` to set or toggle it.

### Observation 5: Missing Category Update Capability
- **File**: `src/lib/firestore.ts`, lines 225–250 & `src/components/admin/CategoriesTable.tsx`
- **Context**: `addCategory` and `deleteCategory` exist, but there is no `updateCategory` function in `firestore.ts` and no edit action in `CategoriesTable.tsx` to edit category names, slugs, order, or visibility.

### Observation 6: Missing Firebase Storage Imports
- **File**: `src/lib/firestore.ts`, lines 489–491, 536–538, 574–575
- **Code**:
  ```ts
  489:   const storageRef = ref(storage, `site-assets/${Date.now()}_${file.name}`);
  490:   await uploadBytes(storageRef, file);
  491:   const downloadURL = await getDownloadURL(storageRef);
  ```
- **Context**: `ref`, `uploadBytes`, `getDownloadURL`, and `deleteObject` are called but not imported from `'firebase/storage'`.

### Observation 7: Hardcoded Footer Links Ignore Settings
- **File**: `src/components/site/Footer.tsx`, lines 53–60
- **Context**: `/contacto` and `/privacidad` are hardcoded in the JSX. Changes made by administrators in `/dashboard/settings/footer` (`settings.footer.links`) are completely ignored on the public site.

### Observation 8: Inconsistent Timeout Durations
- **File**: `src/lib/auth.ts`, lines 20, 202, 264, 416 & `src/lib/firestore.ts`, lines 152, 176, 193
- **Context**: Calls specify 2000ms, 2500ms, and 3000ms, whereas the system prompt explicitly requires strict 1.8s (1800ms) timeouts.

---

## 2. Logic Chain

1. **Premise 1**: In Next.js App Router, `middleware.ts` runs on the edge/server before every request matching `/dashboard/:path*`.
   - **Observation 1** shows `if (pathname === '/dashboard') return NextResponse.redirect('/dashboard/profile')`.
   - **Deduction**: Because the redirect is unconditional for the route `/dashboard`, no user (including `admin` and `superadmin`) can ever view `/dashboard`. This blocks the main editorial dashboard.

2. **Premise 2**: Firestore Security Rules enforce access control server-side by matching document paths. Unmatched paths or failed boolean expressions default to `DENY`.
   - **Observation 2** shows `firestore.rules` targets `/siteSettings/{settingId}` and `/statistics/{statId}`, while application code writes to `/settings/site` and `/ad_clicks`.
   - **Deduction**: When deployed to Firebase, admin setting updates will throw `PERMISSION_DENIED`, ad click tracking will fail, and ad statistics queries will fail.

3. **Premise 3**: The security model must prevent regular readers (`role: 'user'`) from elevating their privileges.
   - **Observation 3** shows `allow create: if isOwner(userId)` and `allow update: if isOwner(userId)`.
   - **Deduction**: A malicious reader can issue a client-side update with `{ role: 'admin' }`, gaining full administrative powers.

4. **Premise 4**: Acceptance criteria R2 requires managing dynamic categories and the most-read article grid.
   - **Observations 4 & 5** demonstrate that while the database model and public queries support these features, the editorial dashboard lacks UI controls to edit existing categories or set an article's `showOnMostRead` flag.
   - **Deduction**: Editorial staff cannot fully operate the portal without these controls.

---

## 3. Caveats

- **Network Mode**: The investigation was conducted in local development mode without a live connection to Google Cloud / production Firebase endpoints; Firestore timeout fallbacks to mock data were tested and verified via `npm.cmd run build`.
- **Third-party integrations**: Weather API and Google Analytics/AdSense scripts rely on external keys that were not live-tested.
- **Scope Limit**: Code was investigated read-only; no source modifications were committed during this turn in accordance with explorer role constraints.

---

## 4. Conclusion

The application has strong UI design and solid base features, but contains **three critical architectural blockers**:
1. `src/middleware.ts` blocks the editorial dashboard (`/dashboard`).
2. `firestore.rules` has collection mismatches (`settings`, `ad_clicks`, missing `reels`, `authors`) and a privilege escalation vulnerability on `role`.
3. `src/lib/firestore.ts` is missing `firebase/storage` imports, which will crash image/video uploads.

Additionally, three editorial workflow gaps must be closed:
1. Adding a `showOnMostRead` switch to `ArticleForm.tsx`.
2. Adding `updateCategory` functionality to `firestore.ts` and `CategoriesTable.tsx`.
3. Standardizing all non-blocking Firestore timeouts to 1800ms (1.8s).

---

## 5. Verification Method

To independently verify all observations and conclusions:

1. **Verify TypeScript compilation**:
   ```powershell
   npm.cmd run typecheck
   ```
   *Expected result*: Highlights missing imports in `src/lib/firestore.ts`, type mismatches in `Category` and `sidebar.tsx`.

2. **Verify Next.js production build**:
   ```powershell
   npm.cmd run build
   ```
   *Expected result*: Confirms build succeeds and logs 1800ms/2000ms offline Firestore timeout fallbacks.

3. **Verify Middleware Redirect Issue**:
   Inspect `src/middleware.ts` line 15:
   ```ts
   if (pathname === '/dashboard') {
     return NextResponse.redirect(new URL('/dashboard/profile', request.url));
   }
   ```
   Confirm that accessing `/dashboard` will redirect any authenticated admin away from the editorial dashboard.

4. **Verify Collection Mismatch in Firestore Rules**:
   Compare `firestore.rules` lines 47 & 53 with `src/lib/firestore.ts` lines 260 & 502.
