# Survey Report: Editorial Content, Dashboards & Firestore Security Rules
**Project**: El Diario de la Diáspora  
**Agent**: Explorer 3 (Survey: Editorial Content & Dashboards)  
**Date**: 2026-09-26  
**Workspace**: `C:\Users\Legit\.gemini\antigravity\scratch\el-diario-de-la-diaspora-main`  

---

## Executive Summary

This investigation analyzed the public-facing editorial components, dashboard routes, role-based visibility controls, and Firestore security rules in **El Diario de la Diáspora**. While the frontend layout and design system (header, hero, category pages, article page, footer, reader profile) are well-crafted, there are critical blocking bugs, architectural discrepancies in security rules, missing administrative logic for "Most Read" and Category editing, and TypeScript type violations that require remediation.

---

## 1. Public Site Investigation

### 1.1 Category Navigation
- **Header Navigation Bar** (`src/components/site/Header.tsx`, lines 356–375):
  - Renders horizontal scrolling category navigation with active indicators (`pathname === '/category/${item.slug}'`).
  - Mobile Sheet Drawer (`src/components/site/Header.tsx`, lines 220–353):
    - Includes an accordion for **"La Diáspora"** with direct links to 14 countries (`/category/la-diaspora?pais=${country.slug}`).
    - Filters out unwanted categories (`comunidad`, `visión`) per editorial directives.
    - Default categories fallback provided when Firestore categories are empty.
- **Category Page** (`src/app/category/[slug]/page.tsx`):
  - Dynamically renders category articles with pagination (9 articles/page).
  - Exclusive country filter bar for **"La Diáspora"** category (`DIASPORA_COUNTRIES` tabs with query param `?pais=...`).
  - Robust fallback in `src/lib/firestore.ts` (`getCategoryBySlug` lines 220–223) that auto-generates a fallback category so no valid category slug ever yields a 404.
  - **Issue Detected** (`src/app/category/[slug]/page.tsx`, lines 83–86, 180–184):
    - Inline server action `'use server'` is passed as a prop (`onAdClick`) to client components (`SideHighlightAd`). This pattern is fragile in Next.js Server Components. Ad click tracking should be handled directly in the client component or via a standard client function.

### 1.2 Article Rendering
- **Article Page Server Component** (`src/app/articles/[slug]/page.tsx`):
  - Dynamic route (`force-dynamic`).
  - Fetches article by slug, site settings, author, categories, and computes `relatedArticles` and `mostReadArticles`.
  - Generates SEO `Metadata` (OpenGraph title, description, hero image).
- **Article Page Client Component** (`src/components/site/ArticlePageClient.tsx`):
  - Journalist Card: Displays author avatar, name, editorial role badge, and publication date formatted with `date-fns/locale/es`.
  - Action Toolbar: Functional "Imprimir" (`window.print()`), "Compartir" (copies URL to clipboard with toast notification), reading time minutes badge.
  - Media: Supports hero video (`heroVideoUrl`) and hero image (`heroImageUrl`) with responsive sizing.
  - Content: Injects TipTap HTML content via `ArticleBody` (`src/components/site/ArticleBody.tsx`), which calculates content length and inserts an in-article banner ad (`inArticle`) at the midpoint if length > 1,800 characters.
  - Tag links: Clickable hashtags leading to `/tag/[slug]`.
  - Social Share Buttons (`ShareButtons.tsx`).
  - Reader Comments (`ArticleComments.tsx`): LocalStorage-persisted reader comments section with likes and submission.
  - **Issue Detected** (`src/components/site/RelatedArticles.tsx`, line 27):
    - `<Image src={article.imageUrl} ... />` will throw a runtime error if `imageUrl` is empty or undefined. Needs fallback image rendering like `ArticleCard.tsx`.

### 1.3 Hero Section
- **Hero Component** (`src/components/site/HeroPrincipal.tsx`):
  - High-impact cinematic visual card (420px–500px height).
  - Displays category badge, journalist badge ("Periodista: [Name]"), "Tema Principal" badge, reading time, and large font-serif headline.
- **Home Page Fallback** (`src/app/page.tsx`, lines 20–23):
  - Selects `sortedHeroes[0]`. If none marked as hero, falls back gracefully to `latestPublished[0]`.
- **Hero Section Management**:
  - Managed via `src/components/admin/settings/HomeLayoutForm.tsx` (drag-and-drop sortable list using `@dnd-kit`).

### 1.4 Most-Read Article Grid ("Lo más leído")
- **Component** (`src/components/site/MostReadList.tsx`):
  - Displays up to 4 numbered items (`01`, `02`, `03`, `04`) with trending icon, bold font-serif titles, and link to article.
  - Rendered on Homepage, Category pages, and Article sidebar.
- **Query** (`src/lib/firestore.ts`, lines 344–364):
  - Filters articles where `showOnMostRead == true` and sorts by `mostReadOrder`.
- **CRITICAL MISSING LOGIC**:
  - There is NO UI in `src/components/admin/articles/ArticleForm.tsx` to set `showOnMostRead` or `mostReadOrder`!
  - There is NO management tab in `src/components/admin/settings/HomeLayoutForm.tsx` for "Most Read" articles.
  - An editorial admin currently has no way to configure which articles appear in the most-read grid.

### 1.5 Search Functionality
- **Search Header & Client** (`src/app/search/page.tsx`, `src/components/site/SearchClient.tsx`):
  - Search input with 400ms debounce that synchronizes query with URL (`/search?q=...`).
  - Case-insensitive search across title, summary, and tags, with tag-match weighting.
- **Next.js 15 Compatibility Note**:
  - In Next.js 15, `searchParams` in server components should be awaited (`const { q } = await searchParams;`).

### 1.6 Footer & Static Pages
- **Footer** (`src/components/site/Footer.tsx`):
  - Features white logo, copyright, social icons (Facebook, Instagram, Twitter, YouTube, WhatsApp), and reader auth links.
  - **Issue Detected**: Navigation links `/contacto` and `/privacidad` are hardcoded in `Footer.tsx` (lines 53–60). The configurable links from `settings.footer.links` (which admins edit in `/dashboard/settings/footer`) are completely ignored.
- **Static Pages**:
  - `/contacto` (`src/app/contacto/page.tsx`): Official contacts, corporate emails, and contact form.
  - `/privacidad` (`src/app/privacidad/page.tsx`): Full privacy policy.

---

## 2. Dashboard Views Investigation

### 2.1 Reader Profile Dashboard (`/dashboard/profile`)
- **Route**: `src/app/dashboard/profile/page.tsx`
- **Design & Layout**:
  - Custom reader layout in `src/app/dashboard/layout.tsx` (lines 122–140): Clean header with "Volver al Periódico" and `DashboardHeader`, but NO admin sidebar.
  - Displays avatar, name, email, role badge ("Lector", "Editor", "Administrador"), user ID, and registration date.
  - **Issue Detected**: In `src/components/admin/DashboardHeader.tsx` (line 29), `<SidebarTrigger className="sm:hidden" />` is rendered. Because the reader layout does NOT wrap in `<SidebarProvider>`, `useSidebar()` returns `null` or throws, causing issues on mobile screens.

### 2.2 Editorial Admin Dashboard (`/dashboard`)
- **Route**: `src/app/dashboard/page.tsx` + `DashboardClient.tsx`
- **Features**:
  - Stat cards: Published articles, Drafts, Categories, Ad Clicks, Featured heroes.
  - Quick action buttons: "Nuevo artículo", "Mis borradores", "Gestionar anuncios", "Ver estadísticas".
  - Recent published articles list and pending drafts card.
- **CRITICAL BUG**:
  - In `src/middleware.ts` (lines 15–17):
    ```ts
    if (pathname === '/dashboard') {
      return NextResponse.redirect(new URL('/dashboard/profile', request.url));
    }
    ```
  - **Impact**: Any admin navigating to `/dashboard` (or clicking "Panel Principal" in the sidebar) is unconditionally redirected to `/dashboard/profile`! This completely locks editors and admins out of the main editorial dashboard.
- **Branding Artifact**:
  - In `src/app/dashboard/DashboardClient.tsx` (line 62): Contains fallback string `"La Cifra"` instead of `"El Diario de la Diáspora"`. (Also in `src/app/tag/[slug]/page.tsx` line 18).

### 2.3 Article Management (`/dashboard/articles`)
- **List Page** (`src/app/dashboard/articles/page.tsx`, `ArticlesClient.tsx`, `columns.tsx`):
  - Summary stats (Total, Published, Drafts, Categories).
  - Data table with sorting, category filtering, title filtering, and action dropdown (View, Edit, Delete with AlertDialog confirmation).
- **New & Edit Article** (`/dashboard/articles/new`, `/dashboard/articles/[id]/edit`, `ArticleForm.tsx`):
  - Full TipTap WYSIWYG editor.
  - Hero image upload (`uploadImage`) and video upload (`uploadVideo`).
  - Category selector with inline "Crear Nueva Categoría" dialog.
  - Keyword tags with Enter/comma parsing.
  - Switches for "Permitir Comentarios" and "Artículo Principal (Héroe)".
  - **Missing**: Switch/field for `showOnMostRead`.

### 2.4 Categories Management (`/dashboard/categories`)
- **Route**: `src/app/dashboard/categories/page.tsx`, `CategoryClient.tsx`, `CategoriesTable.tsx`, `AddCategoryForm.tsx`
- **Features**:
  - Stats for total, visible, and hidden categories.
  - Form to add new category (auto-generates slug, assigns next order).
  - Table displaying order, name, slug, visibility badge, and delete button.
  - Safe deletion: Checks if any article is using the category before allowing deletion.
- **MISSING LOGIC**:
  - There is NO `updateCategory` function in `src/lib/firestore.ts`.
  - There is NO edit modal or row action in `CategoriesTable.tsx` to edit category name, slug, order, or toggle visibility.

### 2.5 Advertising Slot Management (`/dashboard/settings/ads`)
- **Route**: `src/app/dashboard/settings/ads/page.tsx`, `AdsSettingsForm.tsx`
- **Features**:
  - Manages 10 advertising slots:
    1. `popup` (with duration in seconds)
    2. `homeHeroSide` (sidebar top)
    3. `sidebarMiddle` (sidebar middle)
    4. `sidebarBottom` (sidebar bottom)
    5. `homeHorizontal` (homepage leaderboard)
    6. `articleBottom` (article bottom banner)
    7. `footerHorizontal` (pre-footer horizontal)
    8. `homeVerticalLeft` (desktop vertical left)
    9. `homeVerticalLeftBottom` (desktop vertical left lower)
    10. `inArticle` (in-article ad at midpoint)
  - Toggle switch to enable/disable each slot.
  - Image upload button (`uploadImage`) and live image preview.
  - Destination URL input (`linkUrl`) with external test link.
  - Saves to Firestore via `updateSiteSettings({ ads: values })`.

---

## 3. Admin Sidebar Visibility Analysis

### 3.1 Role Segregation
- **Role Hierarchy**:
  - `superadmin`: Absolute access to all panels and settings.
  - `admin`: Full access to articles, categories, statistics, users, and site settings.
  - `editor`: Access to articles list and creation/editing (`/dashboard/articles`).
  - `user`: Reader role. Access strictly limited to `/dashboard/profile`.
- **Implementation in `src/app/dashboard/layout.tsx`** (lines 111–141):
  ```tsx
  if (userProfile.role !== "admin" && userProfile.role !== "editor" && userProfile.role !== "superadmin") {
    if (pathname !== '/dashboard/profile') {
      router.push('/dashboard/profile');
      return ( ... );
    }
    // Render clean reader layout without <SidebarProvider> or <Sidebar>
    return ( ... );
  }
  ```
- **Admin Sidebar Verification**:
  - For `userProfile.role === 'user'`, `<SidebarProvider>` and `<Sidebar>` are NEVER mounted.
  - In `src/components/site/AuthArea.tsx` (lines 112–119), the "Panel" option in the user dropdown is wrapped in `<RequireRole role={['admin', 'editor']}>`. Regular readers only see "Perfil" (`/dashboard/profile`).
  - **Login Redirection Bug** (`src/app/login/page.tsx`, line 130):
    ```ts
    const isAdmin = values.email.toLowerCase().includes('admin');
    ```
    If a regular reader registers or logs in with an email containing "admin" (e.g., `admin.reader@gmail.com`), the client mistakenly redirects them to `/dashboard/articles`. This should be replaced with an exact check for `admin@eldiariodeladiaspora.com` or checked against `userProfile.role`.

---

## 4. Firestore Security Rules Audit (`firestore.rules`)

The current `firestore.rules` file contains significant security vulnerabilities, missing collections, and mismatched collection names that will block functionality in production:

### 4.1 Collection Name Mismatches & Missing Rules
| Codebase Collection | `firestore.rules` Match | Status | Impact |
|---|---|---|---|
| `settings` (`doc(db, 'settings', 'site')`) | `match /siteSettings/{settingId}` | ❌ Mismatch | All admin updates via `updateSiteSettings()` will be REJECTED in production Firestore! |
| `ad_clicks` (`collection(db, 'ad_clicks')`) | `match /statistics/{statId}` | ❌ Mismatch | Ad click recording (`trackAdClick`) fails for readers; statistics page (`getAdClicks`) fails for admins! |
| `articles/{articleId}/comments/{commentId}` | None | ❌ Missing | Reader comment subcollection writes/reads are blocked. |
| `reels` (`collection(db, 'reels')`) | None | ❌ Missing | Reels cannot be read or managed in Firestore. |
| `authors` (`collection(db, 'authors')`) | None | ❌ Missing | Author profile reads will fail if not cached. |
| `homepage` (`collection(db, 'homepage')`) | None | ❌ Missing | Homepage config reads/writes will fail. |

### 4.2 Privilege Escalation Vulnerability in `users/{userId}`
- **Current Rule**:
  ```firestore
  match /users/{userId} {
    allow read: if isAuthenticated();
    allow create: if isAuthenticated() && isOwner(userId);
    allow update: if isOwner(userId) || isAdmin();
    allow delete: if isAdmin();
  }
  ```
- **Vulnerability**: Any newly authenticated user can write `{ role: 'admin' }` or `{ role: 'superadmin' }` upon account creation or profile update because `isOwner(userId)` is satisfied.
- **Required Fix**:
  - On `create`: Must enforce `request.resource.data.role == 'user'` (or prevent non-admins from setting administrative roles).
  - On `update`: Non-admins cannot alter their `role` field (`request.resource.data.role == resource.data.role` or `!('role' in request.resource.data)`).

### 4.3 Unhandled Null Document Crash in `getUserRole()`
- In `firestore.rules` line 15:
  ```firestore
  function getUserRole() {
    return get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role;
  }
  ```
- If the user document does not yet exist at the moment of rule evaluation, accessing `.data` throws a Firestore runtime evaluation error instead of returning false. An `exists(...)` guard is required.

---

## 5. Technical Errors & Codebase Inconsistencies

### 5.1 Missing Storage Imports in `src/lib/firestore.ts`
- Lines 489, 490, 491, 536, 537, 538, 574, 575 call `ref`, `uploadBytes`, `getDownloadURL`, and `deleteObject`.
- None of these are imported from `'firebase/storage'`.
- Running `uploadImage()`, `uploadVideo()`, or `deleteReel()` in non-isolated mode will crash with `ReferenceError: ref is not defined`.

### 5.2 TypeScript Type Inconsistencies
1. **`Category` interface** (`src/lib/types.ts`, lines 147–156):
   - `description`, `parentCategoryId`, and `defaultHeroImageUrl` are marked required.
   - `defaultCategories` in `firestore.ts` and `Header.tsx` omits them, triggering `TS2739` errors.
2. **`useSidebar` context return type** (`src/components/ui/sidebar.tsx`, lines 41–44):
   - `useSidebar()` does not throw when context is missing, causing return type to be `SidebarContext | null`.
   - Lines 174, 290, 555 trigger `TS2339` errors (`Property 'isMobile' does not exist on type 'SidebarContext | null'`).
3. **`SubmitForm.tsx` date fields** (lines 120–122):
   - Passes `Timestamp.now()` to fields typed as `string` in `Article`.
4. **`src/lib/placeholder-data.ts`**:
   - Dead code with outdated schema causing `TS2561` errors.
5. **`src/lib/seed.ts`**:
   - Calls `seedCollection` with `"ad_slots"`, `"weather_config"`, `"article_page_config"` which are not typed in `seedData`.

### 5.3 Timeout Specification Compliance
- The prompt explicitly requires **1.8s (1800ms) timeouts** for non-blocking Firestore calls.
- In `src/lib/auth.ts`: `withTimeout` defaults to 3000ms, and lines 202, 264, 274, 416, 441 use 2500ms.
- In `src/lib/firestore.ts`: Several calls use 2000ms instead of 1800ms.

---

## 6. Actionable Recommendations & Proposed Fixes

| Item | File | Issue | Proposed Solution |
|---|---|---|---|
| 1 | `src/middleware.ts` | Line 15 redirects `/dashboard` to `/dashboard/profile` unconditionally | Remove unconditional redirect. Role authorization is already handled in `DashboardLayout`. |
| 2 | `firestore.rules` | Wrong collections (`siteSettings` vs `settings`, `statistics` vs `ad_clicks`), missing rules (`reels`, `authors`, `homepage`, `comments`), privilege escalation on `role` | Update rules to match actual collection names, add missing collections, and restrict `role` mutations to admins. |
| 3 | `src/lib/firestore.ts` | Missing imports from `firebase/storage` | Add `import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';` |
| 4 | `src/components/admin/articles/ArticleForm.tsx` | Missing `showOnMostRead` switch | Add `showOnMostRead` switch to publication settings card and include in form schema. |
| 5 | `src/lib/firestore.ts` & `CategoriesTable.tsx` | Missing `updateCategory` function and UI | Add `updateCategory` to `firestore.ts` and add edit/toggle capability in `CategoriesTable.tsx`. |
| 6 | `src/components/admin/DashboardHeader.tsx` | `<SidebarTrigger>` renders in reader profile without `SidebarProvider` | Wrap `<SidebarTrigger>` in check or only render when `userProfile.role !== 'user'`. |
| 7 | `src/components/site/Footer.tsx` | Hardcoded links ignore `settings.footer.links` | Dynamically render `settings.footer?.links` with fallback to `/contacto` and `/privacidad`. |
| 8 | `src/components/site/RelatedArticles.tsx` | `<Image>` crashes if `article.imageUrl` is falsy | Add fallback placeholder conditional check before rendering `<Image>`. |
| 9 | `src/lib/types.ts` & `sidebar.tsx` | TypeScript strict errors | Make optional fields optional in `Category`, fix `useSidebar()` guard in `sidebar.tsx`. |
| 10 | `src/lib/auth.ts` & `firestore.ts` | Timeout inconsistency (2000–3000ms vs 1.8s) | Standardize all `withTimeout` calls to strict `1800ms`. |
| 11 | `src/app/login/page.tsx` | `email.includes('admin')` heuristic | Replace with exact check `email.toLowerCase() === 'admin@eldiariodeladiaspora.com'`. |
| 12 | Brand name cleanup | `tag/[slug]/page.tsx` & `DashboardClient.tsx` | Replace `"La Cifra"` with `"El Diario de la Diáspora"`. |
