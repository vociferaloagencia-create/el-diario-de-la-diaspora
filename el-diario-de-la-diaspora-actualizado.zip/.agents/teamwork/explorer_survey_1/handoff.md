# Handoff Report — Explorer 1: Authentication & Timeout Resiliency

**Role**: Explorer (Architecture & Codebase Investigator)  
**Working Directory**: `C:\Users\Legit\.gemini\antigravity\scratch\el-diario-de-la-diaspora-main\.agents\teamwork\explorer_survey_1`  
**Target Milestone**: M1 — Exploration & Survey  
**Date**: 2026-09-26  

---

## 1. Observation

1. **Google OAuth Provider Configuration (`src/lib/auth.ts`, lines 253–257)**:
   ```typescript
   const provider = new GoogleAuthProvider();
   provider.setCustomParameters({ prompt: 'select_account' });
   const userCredential = await signInWithPopup(auth, provider);
   ```
   Directly observed: `prompt: 'select_account'` is configured on line 255.

2. **Cookie Clearing on Login Entry (`src/lib/auth.ts`)**:
   - `signIn` line 111:
     ```typescript
     document.cookie = 'firebaseAuthToken=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT';
     ```
   - `signUp` line 186:
     ```typescript
     document.cookie = 'firebaseAuthToken=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT';
     ```
   - `signInWithGoogle` line 250:
     ```typescript
     document.cookie = 'firebaseAuthToken=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT';
     ```
   Directly observed: All three functions actively clear the `firebaseAuthToken` cookie immediately upon entry.

3. **Missing Token Cookie Setting on Success (`src/lib/auth.ts`)**:
   - `signIn` lines 146–149:
     ```typescript
     try {
       const userCredential = await signInWithEmailAndPassword(auth, email, password);
       return userCredential.user;
     ```
   - `signUp` lines 189–207:
     ```typescript
     const userCredential = await createUserWithEmailAndPassword(auth, email, password);
     const user = userCredential.user;
     ...
     return user;
     ```
   - `signInWithGoogle` lines 256–285:
     ```typescript
     const userCredential = await signInWithPopup(auth, provider);
     const user = userCredential.user;
     ...
     return user;
     ```
   Directly observed: In the success path of all three functions, `user.getIdToken()` is never awaited and `document.cookie = firebaseAuthToken=...` is never written before the function returns `user`.

4. **Client-Side Immediate Navigation (`src/app/login/page.tsx`)**:
   - `handleGoogleLogin` lines 73–81:
     ```typescript
     const user = await signInWithGoogle();
     ...
     const redirectUrl = searchParams.get('redirect') || '/dashboard/profile';
     router.push(redirectUrl);
     router.refresh();
     ```
   - `onLoginSubmit` lines 122–134:
     ```typescript
     const user = await signIn(values.email, values.password);
     ...
     const redirectUrl = searchParams.get('redirect') || (isAdmin ? '/dashboard/articles' : '/dashboard/profile');
     router.push(redirectUrl);
     router.refresh();
     ```
   - `onSignUpSubmit` lines 149–156:
     ```typescript
     await signUp(values.name, values.email, values.password);
     ...
     const redirectUrl = searchParams.get('redirect') || '/dashboard/profile';
     router.push(redirectUrl);
     router.refresh();
     ```
   Directly observed: Navigation to `/dashboard/profile` is triggered synchronously as soon as the sign-in/up promise resolves.

5. **Server Middleware Redirect Behavior (`src/middleware.ts`)**:
   - Lines 5–13:
     ```typescript
     const token = request.cookies.get('firebaseAuthToken');
     const { pathname } = request.nextUrl;

     // Protect dashboard routes if no auth token is present
     if (pathname.startsWith('/dashboard') && !token) {
       const loginUrl = new URL('/login', request.url);
       loginUrl.searchParams.set('redirect', pathname);
       return NextResponse.redirect(loginUrl);
     }
     ```
   - Lines 15–17:
     ```typescript
     if (pathname === '/dashboard') {
       return NextResponse.redirect(new URL('/dashboard/profile', request.url));
     }
     ```
   Directly observed: Middleware requires `firebaseAuthToken` cookie on `/dashboard/:path*`. When absent, it issues a redirect to `/login?redirect=...`. Furthermore, `/dashboard` is unconditionally redirected to `/dashboard/profile`.

6. **Timeout Thresholds (`src/lib/auth.ts`)**:
   - Line 20: `function withTimeout<T>(promise: Promise<T>, ms: number = 3000): Promise<T>`
   - Line 202: `withTimeout(setDoc(...), 2500)`
   - Line 264: `withTimeout(getDoc(userRef), 2500)`
   - Line 274: `withTimeout(setDoc(...), 2500)`
   - Line 278: `withTimeout(updateDoc(...), 2500)`
   - Line 416: `withTimeout(getDoc(userRef), 2500)`
   - Line 441: `withTimeout(setDoc(...), 2500)`
   Directly observed: Timeouts are set to 2500ms and 3000ms instead of 1800ms (1.8s).
   - Lines 456 (`getAllUsers`) and 480 (`updateUserRole`) have no `withTimeout` wrapper.
   - `src/hooks/useUserRole.ts` line 44: `const snap = await getDoc(ref);` has no timeout wrapper.

---

## 2. Logic Chain

1. **From Observation 2, 3, 4, and 5 to the Login Redirect Loop**:
   - When a user submits registration or logs in with Google, `document.cookie` is deleted (Observation 2).
   - Upon successful Firebase resolution, the function returns `user` without waiting for or setting `document.cookie = firebaseAuthToken=...` (Observation 3).
   - The UI immediately invokes `router.push(redirectUrl)` (Observation 4).
   - The browser issues an HTTP request for `/dashboard/profile` to the Next.js server. Because the asynchronous `onAuthStateChanged` token fetch has not completed, the outgoing HTTP request contains no `firebaseAuthToken` cookie.
   - Next.js server middleware reads `token = request.cookies.get('firebaseAuthToken')` which evaluates to undefined (Observation 5).
   - Middleware immediately redirects the browser back to `/login?redirect=/dashboard/profile`.
   - The user experiences a jarring bounce back to the login screen, causing repeated attempts and redirect loops.
   - **Remedy**: Synchronously awaiting `user.getIdToken()` and setting `document.cookie = firebaseAuthToken=...` in `signIn`, `signUp`, and `signInWithGoogle` before returning eliminates the race condition completely.

2. **From Observation 5 (Lines 15–17) to Broken Admin Overview**:
   - In `src/middleware.ts`, any request to `/dashboard` is redirected to `/dashboard/profile`.
   - The CMS overview page (`src/app/dashboard/page.tsx`) resides at `/dashboard`.
   - When an administrator clicks "Panel Principal" (`/dashboard`), middleware intercepts and redirects to `/dashboard/profile`, preventing access to the CMS dashboard.
   - Non-admin readers are already constrained by `DashboardLayout.tsx` which redirects readers to `/dashboard/profile`.
   - **Remedy**: Removing lines 15–17 in `src/middleware.ts` restores admin access to the overview dashboard while reader protection remains enforced by `DashboardLayout.tsx`.

3. **From Observation 6 to Adblocker / Offline Resiliency**:
   - When `firestore.googleapis.com` is blocked by client adblockers, Firestore promises stay pending.
   - The system requirements specify a strict 1.8s (1800ms) fail-safe timeout protection.
   - Currently, operations take 2.5s to 3.0s or hang indefinitely (e.g. `getAllUsers`, `useUserRole.ts`).
   - Updating `withTimeout` default to 1800ms and applying it across all Firestore operations ensures the fallback reader profile is provided promptly within 1.8s.

---

## 3. Caveats

- **Firebase Storage Type Errors**: Running `npm.cmd run typecheck` highlighted that `src/lib/firestore.ts` is missing imports from `'firebase/storage'` (`ref`, `uploadBytes`, `getDownloadURL`, `deleteObject`). While this affects image/reel uploading, it does not impede the authentication flow itself.
- **Admin Creation on Client**: `createAccount()` in `src/lib/auth.ts` calls `createUserWithEmailAndPassword(auth, email, password)` on the client, which switches client auth state away from the admin. In a full production setup with Firebase Admin SDK, user creation should occur via a server action or Cloud Function.
- No other caveats.

---

## 4. Conclusion

The authentication architecture is structurally well-designed with clear role segregation and auto-recovery mechanisms, but suffers from two critical defects that directly violate the acceptance criteria:
1. **Redirect Loop Bug**: Caused by an asynchronous race condition where `firebaseAuthToken` cookie is not written synchronously before `router.push()` executes, triggering a middleware bounce.
2. **Dashboard Lock Bug**: Caused by `src/middleware.ts` unconditionally redirecting `/dashboard` to `/dashboard/profile`.
3. **Timeout Compliance**: Timeouts must be reduced from 2500ms/3000ms to 1800ms (1.8s) across `src/lib/auth.ts` and `src/hooks/useUserRole.ts`.

All required changes have been pinpointed down to exact files, line numbers, and replacement code in `survey_auth.md`.

---

## 5. Verification Method

To independently verify these findings:
1. **Inspect Cookie Management**:
   Open `src/lib/auth.ts` and observe lines 111, 147–149, 186, 207, 250, and 285. Confirm that `document.cookie` is cleared on entry and never set before returning on success.
2. **Inspect Middleware**:
   Open `src/middleware.ts` and observe lines 5–17. Confirm that `pathname === '/dashboard'` redirects to `/dashboard/profile` unconditionally, and that `pathname.startsWith('/dashboard') && !token` redirects to `/login`.
3. **Inspect Timeouts**:
   Open `src/lib/auth.ts` and check line 20 (`ms: number = 3000`) and lines 202, 264, 274, 278, 416, 441 (`2500`).
4. **Compile Check**:
   Run `npm.cmd run typecheck` to verify TypeScript diagnostics.
