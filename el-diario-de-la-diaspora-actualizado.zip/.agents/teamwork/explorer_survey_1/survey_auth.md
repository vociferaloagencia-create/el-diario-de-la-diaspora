# Survey Report: Authentication & Timeout Resiliency
**Project**: El Diario de la Diáspora  
**Investigator**: Explorer 1 (`explorer_survey_1`)  
**Date**: 2026-09-26  
**Status**: Completed  

---

## 1. Executive Summary

An exhaustive investigation of the authentication and authorization subsystems of **El Diario de la Diáspora** was performed, focusing on:
1. Firebase Client setup, Auth Context, and Auth Provider (`src/lib/firebase.ts`, `src/hooks/use-auth.tsx`).
2. Google OAuth provider parameters (`GoogleAuthProvider`, popup sign-in, and `prompt: 'select_account'`).
3. User profile creation and role assignment (`role: 'user'` for regular readers, `role: 'admin'` for explicit editorial staff).
4. Non-blocking fail-safe timeout protection (1.8s timeouts and adblocker/offline fallbacks).
5. Next.js server middleware (`src/middleware.ts`) and root causes of redirect loops between `/login` and `/dashboard/profile`.

### Key Conclusions:
- **Google OAuth prompt**: `prompt: 'select_account'` is **already present** in `src/lib/auth.ts` (line 255).
- **Critical Auth Token Race Condition (Redirect Loop Bug)**: When a user signs in, signs up, or uses Google OAuth, the functions clear `document.cookie` on entry, but on successful authentication they **never set `document.cookie = firebaseAuthToken=...` before resolving**. Because `router.push('/dashboard/profile')` executes immediately upon promise resolution, the browser sends the navigation request to Next.js server **before** the asynchronous `onAuthStateChanged` callback has set the cookie. Next.js `src/middleware.ts` detects a missing `firebaseAuthToken` cookie and issues a `307 Redirect` right back to `/login?redirect=/dashboard/profile`, causing an infinite redirect bounce / loop.
- **Middleware `/dashboard` Over-Redirect Bug**: `src/middleware.ts` lines 15–17 unconditionally redirects any request matching `/dashboard` to `/dashboard/profile`. This locks admins and editors out of the main editorial dashboard overview (`src/app/dashboard/page.tsx`), even when clicking "Panel Principal". Regular readers are already safely redirected to `/dashboard/profile` by client-side role guards in `DashboardLayout.tsx`.
- **Timeout Discrepancies**: The codebase currently utilizes `2500ms` and `3000ms` timeouts in `src/lib/auth.ts` instead of the required **1.8s (1800ms)** non-blocking threshold. Furthermore, `getAllUsers()`, `updateUserRole()`, and `useUserRole.ts` lack timeout wrappers altogether.
- **Role Assignment**: `signInWithGoogle` and `getUserProfile` correctly enforce `role: 'admin'` only for `admin@eldiariodeladiaspora.com` and `'user'` for regular readers. However, `signUp()` currently defaults to `'user'` even if registered with `admin@eldiariodeladiaspora.com`.

---

## 2. Detailed Technical Survey

### 2.1. Firebase Client Setup, Auth Context, and Auth Provider

#### Files Inspected:
- `src/lib/firebase.ts`
- `src/hooks/use-auth.tsx`
- `src/lib/auth.ts`

#### Observations:
1. **Firebase Initialization (`src/lib/firebase.ts`)**:
   - Uses `initializeApp` and singleton prevention via `!getApps().length ? initializeApp(firebaseConfig) : getApp()`.
   - Exports `auth = getAuth(app)` and `db = getFirestore(app)`.
   - Uses environmental fallback defaults for local development.
2. **Auth Context & Provider (`src/hooks/use-auth.tsx`)**:
   - Exports `AuthProvider` and `useAuth()`.
   - Provides `{ authUser: User | null, userProfile: AppUser | null, loading: boolean }`.
   - Listens to `onAuthUserChanged` in `useEffect`:
     ```typescript
     useEffect(() => {
       const unsubscribe = onAuthUserChanged((authUser, profile) => {
         setAuthUser(authUser);
         setUserProfile(profile);
         setLoading(false);
       });
       return () => unsubscribe();
     }, []);
     ```
   - Correctly integrates with client components across the application.

---

### 2.2. Google OAuth Provider Parameters

#### File Inspected:
- `src/lib/auth.ts` (lines 247–320)

#### Observations:
```typescript
export async function signInWithGoogle(): Promise<User> {
  if (typeof window !== 'undefined') {
    localStorage.removeItem('mock_user_session');
    document.cookie = 'firebaseAuthToken=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT';
  }

  try {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    const userCredential = await signInWithPopup(auth, provider);
    const user = userCredential.user;
    ...
```
1. **Parameter Verification**:
   - `provider.setCustomParameters({ prompt: 'select_account' });` is **configured properly**. It forces Google account chooser rather than silently selecting the active browser session.
2. **Issues Found in `signInWithGoogle`**:
   - **Missing Cookie Set on Success**: At line 250, the cookie is deleted. At line 285, `return user` is executed without awaiting `user.getIdToken()` or setting `document.cookie = firebaseAuthToken=...`.
   - **Timeout values**: Profile checks use `2500ms` instead of `1800ms`.

---

### 2.3. User Profile Creation & Role Assignment

#### Requirements:
- Regular readers must have `role: 'user'`.
- Editorial administrators (`admin@eldiariodeladiaspora.com`) must have `role: 'admin'`.
- Automatic user profile document creation in Firestore (`/users/{uid}`).

#### Observations in Current Code:
1. **Google Sign-In (`signInWithGoogle`)**:
   - Lines 262–263:
     ```typescript
     const isExplicitAdmin = user.email?.toLowerCase() === 'admin@eldiariodeladiaspora.com';
     const assignedRole = isExplicitAdmin ? 'admin' : 'user';
     ```
     Creates profile if missing (`setDoc(userRef, { uid, email, name, photoUrl, role: assignedRole, ... })`).
     If existing profile has `role: 'admin'` but email is not `admin@eldiariodeladiaspora.com`, updates Firestore to `'user'`.
2. **Email Registration (`signUp`)**:
   - Lines 196–202 currently hardcodes `role: 'user'` without checking if the email is `admin@eldiariodeladiaspora.com`.
   - Proposed update:
     ```typescript
     const isExplicitAdmin = email.toLowerCase() === 'admin@eldiariodeladiaspora.com';
     const assignedRole = isExplicitAdmin ? 'admin' : 'user';
     ```
3. **Profile Retrieval & Auto-Recovery (`getUserProfile`)**:
   - Lines 360–366:
     ```typescript
     const currentFirebaseUser = auth.currentUser;
     const isExplicitAdmin = currentFirebaseUser?.email?.toLowerCase() === 'admin@eldiariodeladiaspora.com';
     const fallbackProfile: AppUser = {
       uid,
       email: currentFirebaseUser?.email || '',
       role: isExplicitAdmin ? 'admin' : 'user',
       name: currentFirebaseUser?.displayName || currentFirebaseUser?.email?.split('@')[0] || 'Usuario Lector',
       photoUrl: currentFirebaseUser?.photoURL || '',
       createdAt: new Date().toISOString(),
     };
     ```
   - Lines 389–398: If the document is missing in Firestore, it creates the profile doc non-blockingly as an auto-recovery mechanism.
   - Enforces that non-admin emails cannot retain an `admin` role:
     ```typescript
     const isAdminEmail = data.email?.toLowerCase() === 'admin@eldiariodeladiaspora.com';
     const effectiveRole = (data.role === 'admin' && !isAdminEmail) ? 'user' : (data.role || 'user');
     ```

---

### 2.4. Non-Blocking Fail-Safe Timeout Protection (1.8s Timeout & Adblocker Fallback)

#### Analysis of Adblocker Impact:
Browser adblockers (e.g. uBlock Origin, Brave Shields, AdGuard) frequently block `firestore.googleapis.com` or Google telemetry endpoints. When blocked, standard Firestore promises (`getDoc`, `setDoc`) do **not reject immediately**; instead, they remain in a pending state indefinitely (waiting on network reconnect).

#### Current Implementation vs Requirement:
1. `src/lib/auth.ts` line 20:
   ```typescript
   function withTimeout<T>(promise: Promise<T>, ms: number = 3000): Promise<T> { ... }
   ```
   - Default is `3000ms`.
   - Invocations throughout the file pass `2500ms`.
   - **Requirement**: Must be **1.8s (1800ms)**.
2. Invocations needing adjustment to `1800ms`:
   - `signUp` line 202: `withTimeout(setDoc(...), 2500)` -> change to `1800`.
   - `signInWithGoogle` line 264: `withTimeout(getDoc(userRef), 2500)` -> change to `1800`.
   - `signInWithGoogle` line 274: `withTimeout(setDoc(userRef, ...), 2500)` -> change to `1800`.
   - `signInWithGoogle` line 278: `withTimeout(updateDoc(userRef, ...), 2500)` -> change to `1800`.
   - `getUserProfile` line 416: `withTimeout(getDoc(userRef), 2500)` -> change to `1800`.
   - `getUserProfile` line 441: `withTimeout(setDoc(userRef, ...), 2500)` -> change to `1800`.
3. Invocations missing timeouts:
   - `getAllUsers()` line 456: `await getDocs(q)` -> needs `await withTimeout(getDocs(q), 1800)`.
   - `updateUserRole()` line 480: `await updateDoc(...)` -> needs `await withTimeout(updateDoc(...), 1800)`.
   - `src/hooks/useUserRole.ts` line 44: `await getDoc(ref)` -> has no timeout wrapper.
4. Fallback Resiliency:
   - When the 1.8s timeout fires, `getUserProfile()` catches the timeout and immediately returns `fallbackProfile`.
   - In `onAuthUserChanged`, `callback(authUser, fallbackProfile)` is invoked without delay.
   - The user session activates as a local reader (`role: 'user'`), unfreezing the UI and preventing authentication hangs.

---

### 2.5. Root Cause Analysis: Redirect Loops & Middleware Audit

#### Files Inspected:
- `src/middleware.ts`
- `src/lib/auth.ts`
- `src/app/login/page.tsx`
- `src/app/dashboard/layout.tsx`

#### Root Cause 1: Race Condition on `firebaseAuthToken` Cookie
1. In `src/lib/auth.ts`:
   - `signIn`, `signUp`, and `signInWithGoogle` all execute:
     `document.cookie = 'firebaseAuthToken=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT';`
   - After Firebase authentication resolves, none of these functions set the cookie synchronously.
   - The cookie was only set inside the `onAuthStateChanged` listener.
2. In `src/app/login/page.tsx`:
   - `onLoginSubmit` / `onSignUpSubmit` / `handleGoogleLogin`:
     ```typescript
     const user = await signInWithGoogle(); // or signIn or signUp
     ...
     const redirectUrl = searchParams.get('redirect') || '/dashboard/profile';
     router.push(redirectUrl);
     router.refresh();
     ```
   - `router.push(redirectUrl)` initiates an immediate navigation to `/dashboard/profile`.
3. In `src/middleware.ts`:
   - The Next.js edge runtime receives the HTTP request for `/dashboard/profile`.
   - `const token = request.cookies.get('firebaseAuthToken');`
   - Since the asynchronous `onAuthStateChanged` token fetch hasn't completed in the browser yet, `token` is `undefined`.
   - Middleware executes:
     ```typescript
     if (pathname.startsWith('/dashboard') && !token) {
       const loginUrl = new URL('/login', request.url);
       loginUrl.searchParams.set('redirect', pathname);
       return NextResponse.redirect(loginUrl);
     }
     ```
   - The user is bounced back to `/login?redirect=/dashboard/profile`.
   - In the browser, `onAuthStateChanged` sets the cookie a moment later.
   - The user attempts to sign in or navigate again, triggering a loop or confusing bounce.

**Solution**:
In `signIn()`, `signUp()`, and `signInWithGoogle()`, right after `user` is acquired, eagerly retrieve the ID token and synchronously set `document.cookie`:
```typescript
const token = await user.getIdToken().catch(() => 'mock-jwt-token');
if (typeof document !== 'undefined') {
  document.cookie = `firebaseAuthToken=${token}; path=/; max-age=${60 * 60 * 24 * 7}; SameSite=Lax`;
}
```
This guarantees the cookie is populated in the browser **before** `router.push()` is called.

#### Root Cause 2: Middleware `/dashboard` Unconditional Override
1. In `src/middleware.ts` lines 15–17:
   ```typescript
   if (pathname === '/dashboard') {
     return NextResponse.redirect(new URL('/dashboard/profile', request.url));
   }
   ```
2. Impact:
   - `/dashboard` is the main administrative overview page (`src/app/dashboard/page.tsx`), showing article statistics, category metrics, and quick actions.
   - When an administrator clicks "Panel Principal" (`/dashboard`), the middleware unconditionally redirects them to `/dashboard/profile`.
   - Non-admin readers are **already** redirected to `/dashboard/profile` by client-side checks in `DashboardLayout.tsx`:
     ```typescript
     if (userProfile.role !== "admin" && userProfile.role !== "editor" && userProfile.role !== "superadmin") {
       if (pathname !== '/dashboard/profile') {
         router.push('/dashboard/profile');
       ...
     ```
   - Having this rule in `src/middleware.ts` breaks the admin dashboard and causes unwanted redirects.

**Solution**:
Remove lines 15–17 from `src/middleware.ts`. Allow `/dashboard` requests with a valid token to proceed to `DashboardLayout`, where role-aware routing directs regular readers to `/dashboard/profile` and admins to the CMS overview.

---

## 3. Defect & Vulnerability Matrix

| ID | Location | Defect Description | Severity | Proposed Fix |
|---|---|---|---|---|
| **BUG-01** | `src/lib/auth.ts`: `signIn`, `signUp`, `signInWithGoogle` | Does not set `firebaseAuthToken` cookie before returning, causing middleware redirect bounce to `/login` | **Critical** | Await `user.getIdToken()` and set `document.cookie` before resolving |
| **BUG-02** | `src/middleware.ts` (lines 15–17) | Unconditionally redirects `/dashboard` to `/dashboard/profile`, locking admins out of the main dashboard overview | **High** | Remove unconditional redirect rule; let `DashboardLayout` handle role routing |
| **BUG-03** | `src/lib/auth.ts` (multiple lines) | Timeouts configured to `2500ms` and `3000ms` instead of required `1800ms` (1.8s) | **Medium** | Set `withTimeout` default to `1800ms` and update all calls to `1800` |
| **BUG-04** | `src/lib/auth.ts`: `getAllUsers`, `updateUserRole` | Firestore operations lack timeout wrappers, causing potential freeze if firestore is blocked | **Medium** | Wrap calls in `withTimeout(..., 1800)` |
| **BUG-05** | `src/hooks/useUserRole.ts` (line 44) | `getDoc(ref)` has no timeout wrapper; hangs indefinitely when Firestore is blocked by adblockers | **Medium** | Add `withTimeout(getDoc(ref), 1800)` with fallback to `'user'` |
| **BUG-06** | `src/lib/auth.ts`: `signUp` | Does not check `isExplicitAdmin` for `admin@eldiariodeladiaspora.com`, assigning `'user'` role | **Low** | Assign `role: isExplicitAdmin ? 'admin' : 'user'` in `signUp` |
| **BUG-07** | `src/app/login/page.tsx` | If user is already authenticated when visiting `/login`, there is no automatic redirection to `/dashboard/profile` | **Low** | Add `useEffect` checking `authUser && !loading` and redirecting |

---

## 4. Proposed Code Snippets (Ready for Implementation)

### 4.1. `src/lib/auth.ts`

```typescript
// 1. Update withTimeout default
function withTimeout<T>(promise: Promise<T>, ms: number = 1800): Promise<T> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new Error('Operation timed out'));
    }, ms);
    promise
      .then((res) => {
        clearTimeout(timer);
        resolve(res);
      })
      .catch((err) => {
        clearTimeout(timer);
        reject(err);
      });
  });
}

// 2. In signIn: Ensure token cookie is set synchronously
export async function signIn(email: string, password: string): Promise<User> {
  ...
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;
    try {
      const token = await user.getIdToken();
      if (typeof document !== 'undefined') {
        document.cookie = `firebaseAuthToken=${token}; path=/; max-age=${60 * 60 * 24 * 7}; SameSite=Lax`;
      }
    } catch (e) {
      console.warn("Could not set auth cookie immediately:", e);
    }
    return user;
  } catch (error: any) {
  ...

// 3. In signUp: Set token cookie and handle explicit admin
export async function signUp(name: string, email: string, password: string): Promise<User> {
  ...
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;
    const isExplicitAdmin = email.toLowerCase() === 'admin@eldiariodeladiaspora.com';
    const assignedRole = isExplicitAdmin ? 'admin' : 'user';

    // Synchronously set token cookie
    try {
      const token = await user.getIdToken();
      if (typeof document !== 'undefined') {
        document.cookie = `firebaseAuthToken=${token}; path=/; max-age=${60 * 60 * 24 * 7}; SameSite=Lax`;
      }
    } catch (e) {
      console.warn("Could not set auth cookie immediately:", e);
    }

    // Create user doc in Firestore (non-blocking with 1.8s timeout)
    try {
      const userRef = doc(db, 'users', user.uid);
      await withTimeout(setDoc(userRef, {
        uid: user.uid,
        email: user.email,
        name: name,
        role: assignedRole,
        createdAt: serverTimestamp(),
      }), 1800);
    } catch (err) {
      console.warn("[Autenticación] Escritura de perfil en Firestore no bloqueante:", err);
    }

    return user;
  ...

// 4. In signInWithGoogle: Set token cookie and use 1800ms timeouts
export async function signInWithGoogle(): Promise<User> {
  ...
  try {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    const userCredential = await signInWithPopup(auth, provider);
    const user = userCredential.user;

    // Synchronously set token cookie
    try {
      const token = await user.getIdToken();
      if (typeof document !== 'undefined') {
        document.cookie = `firebaseAuthToken=${token}; path=/; max-age=${60 * 60 * 24 * 7}; SameSite=Lax`;
      }
    } catch (e) {
      console.warn("Could not set auth cookie immediately:", e);
    }

    // Ensure user profile in Firestore (1.8s timeout)
    try {
      const userRef = doc(db, 'users', user.uid);
      const isExplicitAdmin = user.email?.toLowerCase() === 'admin@eldiariodeladiaspora.com';
      const assignedRole = isExplicitAdmin ? 'admin' : 'user';
      const docSnap = await withTimeout(getDoc(userRef), 1800);

      if (!docSnap.exists()) {
        await withTimeout(setDoc(userRef, {
          uid: user.uid,
          email: user.email || '',
          name: user.displayName || user.email?.split('@')[0] || 'Usuario Lector',
          photoUrl: user.photoURL || '',
          role: assignedRole,
          createdAt: serverTimestamp(),
        }), 1800);
      } else {
        const data = docSnap.data();
        if (!isExplicitAdmin && data.role === 'admin') {
          await withTimeout(updateDoc(userRef, { role: 'user' }), 1800);
        }
      }
    } catch (e) {
      console.warn("[Autenticación] Sincronización de perfil de Google omitida por timeout/error:", e);
    }

    return user;
  ...
```

### 4.2. `src/middleware.ts`

```typescript
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(request: NextRequest) {
  const token = request.cookies.get('firebaseAuthToken');
  const { pathname } = request.nextUrl;

  // Protect dashboard routes if no auth token is present
  if (pathname.startsWith('/dashboard') && !token) {
    const loginUrl = new URL('/login', request.url);
    loginUrl.searchParams.set('redirect', pathname);
    return NextResponse.redirect(loginUrl);
  }

  // Redirect from /no-access if no session
  if (!token && pathname === '/no-access') {
    return NextResponse.redirect(new URL('/login', request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/dashboard/:path*', '/dashboard', '/no-access'],
};
```
*(Notice: The unconditional `if (pathname === '/dashboard') redirect('/dashboard/profile')` is removed so admins can access `/dashboard`, while readers are safely routed to `/dashboard/profile` by `DashboardLayout.tsx`).*

---

## 5. Verification Strategy

1. **Unit & Manual Flow Verification**:
   - Test Email/Password registration on `/login?tab=register`:
     - Enter reader name, email, password.
     - Submit -> Verify direct transition to `/dashboard/profile` with reader avatar and details, zero redirect loops.
   - Test Google Sign-in:
     - Click "Crear Cuenta con Google" -> Verify Google account chooser modal opens (`prompt: 'select_account'`).
     - On selection -> Verify direct redirect to `/dashboard/profile`.
   - Test Adblocker simulation:
     - In DevTools or network tab, block requests to `firestore.googleapis.com`.
     - Log in -> Verify the 1.8s timeout triggers fallback profile without freezing or looping.
   - Test Admin Access:
     - Log in as `admin@eldiariodeladiaspora.com`.
     - Navigate to `/dashboard` -> Verify admin stats, categories, and articles load instead of being redirected to `/dashboard/profile`.
     - Log in as reader -> Navigate to `/dashboard` -> Verify `DashboardLayout` cleanly guides the reader to `/dashboard/profile` with no admin sidebar rendered.
