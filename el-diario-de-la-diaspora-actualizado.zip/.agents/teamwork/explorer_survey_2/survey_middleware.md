# Survey Report: Middleware, Auth Session Tokens & Routing Loops

**Author**: Explorer 2 (Architecture & Codebase Investigator)  
**Target Project**: El Diario de la Diáspora  
**Workspace**: `C:\Users\Legit\.gemini\antigravity\scratch\el-diario-de-la-diaspora-main`  
**Date**: 2026-09-26  

---

## 1. Executive Summary

A comprehensive investigation was conducted into the Next.js routing, middleware architecture, session token/cookie mechanics, and authentication redirect behavior in *El Diario de la Diáspora*. 

The investigation uncovered **four critical architectural defects** directly responsible for infinite redirect loops and route locking:
1. **Cookie Deletion & Async Race Condition in Auth Handlers**: In `src/lib/auth.ts`, `signIn()`, `signUp()`, and `signInWithGoogle()` explicitly delete the `firebaseAuthToken` cookie upon invocation (`document.cookie = 'firebaseAuthToken=; ... expires=1970'`), but on their successful completion paths they return the `User` object **without** setting the replacement cookie. When `src/app/login/page.tsx` immediately executes `router.push('/dashboard/profile')`, the browser initiates a navigation request lacking the session cookie. Edge middleware intercepts the request, determines that `token` is missing, and returns a 307 redirect back to `/login?redirect=/dashboard/profile`, trapping the user.
2. **Stale UID Guard Preventing Cookie Restoration**: In `src/lib/auth.ts:361`, `onAuthUserChanged` contains `if (authUser?.uid === currentUid && authUser) return;`. When a previously loaded user re-authenticates after the cookie was cleared by `signIn()` / `signUp()`, the event triggers with the same UID, returning early without ever acquiring a new token or restoring the cookie.
3. **Unconditional `/dashboard` Redirection in Middleware**: In `src/middleware.ts:15-17`, any request to `/dashboard` is redirected unconditionally to `/dashboard/profile` (`if (pathname === '/dashboard') return NextResponse.redirect(new URL('/dashboard/profile', request.url));`). This completely breaks the Admin Dashboard Overview (`src/app/dashboard/page.tsx` + `DashboardClient.tsx`), preventing editorial staff and admins from ever accessing their primary administrative overview, stats, and draft counts.
4. **Isolated Mode Disparity in `useUserRole.ts`**: In `src/hooks/useUserRole.ts`, `isIsolatedMode` is derived from `!process.env.NEXT_PUBLIC_FIREBASE_API_KEY`, which evaluates to `true` (since no `.env` file exists and `firebase.ts` relies on in-code fallbacks). Consequently, `useUserRole` ignores Firebase/Firestore and searches `localStorage.getItem('mock_user_session')`, causing role-dependent guards such as `DashboardClientWrapper.tsx` to fail and attempt redirects to `/no-access` (which does not exist, triggering 404 errors).

---

## 2. Middleware Architecture & Route Matching Analysis

### 2.1 File Inspection: `src/middleware.ts`

```typescript
// src/middleware.ts
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(request: NextRequest) {
  const token = request.cookies.get('firebaseAuthToken');
  const { pathname } = request.nextUrl;

  // Protect dashboard routes if no auth token is present
  if (pathname.startsWith('/dashboard') && !token) {
    const loginUrl = new URL('/login', request.url);
    loginUrl.searchParams.set('redirect', pathname);
    return NextResponse.redirect(loginUrl);
  }

  if (pathname === '/dashboard') {
    return NextResponse.redirect(new URL('/dashboard/profile', request.url));
  }

  // Redirect from /no-access if no session
  if (!token && pathname === '/no-access') {
    return NextResponse.redirect(new URL('/login', request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/dashboard/:path*', '/dashboard', '/no-access'],
};
```

### 2.2 Route Matcher Analysis
- `config.matcher`: Matches only routes beginning with `/dashboard/`, `/dashboard` itself, and `/no-access`.
- Public routes (`/`, `/articles/*`, `/category/*`, `/contacto`, etc.) and `/login` bypass middleware completely.
- Static assets (`_next/static`, `_next/image`, `favicon.ico`, `images/*`) are excluded from matcher, preventing performance overhead.

### 2.3 Middleware Defects Observed
1. **Unconditional Hijack of `/dashboard` (Lines 15–17)**:
   - When any user (reader, editor, admin) requests `/dashboard`, the middleware executes:
     `return NextResponse.redirect(new URL('/dashboard/profile', request.url));`
   - **Consequence**: The server component `src/app/dashboard/page.tsx` (which renders `DashboardClient` with article metrics, draft queues, category statistics, ad click data, and fast creation links) can NEVER be accessed.
   - The admin sidebar item "Panel Principal" (`<Link href="/dashboard">`) and navbar menu item "Panel" (`<Link href="/dashboard">`) both link to `/dashboard`. When clicked, middleware immediately bounces the user to `/dashboard/profile`.
2. **Missing Edge Role Awareness**:
   - The middleware only checks `request.cookies.get('firebaseAuthToken')`.
   - It cannot distinguish between a reader (`role: 'user'`) and an administrator (`role: 'admin'`).
   - As a result, a reader can request `/dashboard/articles`, pass middleware, and only be stopped client-side by `src/app/dashboard/layout.tsx`.
3. **Dead-End UX: `/no-access` (Lines 20–22)**:
   - Line 20 checks `if (!token && pathname === '/no-access') return NextResponse.redirect(new URL('/login', request.url));`.
   - While `src/app/no-access/page.tsx` exists as a bare unstyled component, redirecting authenticated reader users there (e.g. from `DashboardClientWrapper.tsx:51`) strands readers on a dead-end page without navigation or return links, rather than gracefully keeping them inside their profile (`/dashboard/profile`).

---

## 3. Auth Session Tokens & Cookies Lifecycle Analysis

### 3.1 Execution Boundary
- **Client Runtime**: Firebase Auth Client SDK (`firebase/auth`) operates entirely on the client, caching tokens in IndexedDB.
- **Edge / Server Runtime**: Next.js Middleware runs at the edge before any client code or React components mount. The edge runtime has zero access to IndexedDB or `localStorage`. It relies solely on HTTP Request Cookies.

### 3.2 Where and How Cookies Are Manipulated (`src/lib/auth.ts`)

| Location | Action on `firebaseAuthToken` | Notes |
|---|---|---|
| `auth.ts:111` (`signIn` start) | **Deleted**: `expires=Thu, 01 Jan 1970` | Clears cookie before network call |
| `auth.ts:147-148` (`signIn` success) | **NOT SET!** | Returns `user` without setting cookie |
| `auth.ts:175` (`signIn` fallback) | Set: `mock-jwt-token-diaspora` | Only sets cookie in error fallback |
| `auth.ts:186` (`signUp` start) | **Deleted**: `expires=Thu, 01 Jan 1970` | Clears cookie before registration |
| `auth.ts:190-207` (`signUp` success) | **NOT SET!** | Returns `user` without setting cookie |
| `auth.ts:239` (`signUp` fallback) | Set: `mock-jwt-token-newuser` | Only sets cookie in error fallback |
| `auth.ts:250` (`signInWithGoogle` start) | **Deleted**: `expires=Thu, 01 Jan 1970` | Clears cookie before popup |
| `auth.ts:256-285` (`signInWithGoogle` success) | **NOT SET!** | Returns `user` without setting cookie |
| `auth.ts:314` (`signInWithGoogle` fallback) | Set: `mock-jwt-token-google` | Only sets cookie in error fallback |
| `auth.ts:331` (`signOut`) | **Deleted**: `expires=Thu, 01 Jan 1970` | Clears cookie properly |
| `auth.ts:368` (`onAuthUserChanged`) | Asynchronously set: `token = await authUser.getIdToken()` | Deferred background callback |
| `auth.ts:390` (`onAuthUserChanged` null) | **Deleted**: `expires=Thu, 01 Jan 1970` | Clears cookie properly |

### 3.3 The Core Cookie Timing Race Condition
1. The user clicks "Iniciar Sesión", "Crear Mi Cuenta Ahora", or "Continuar con Google".
2. The function starts by expiring/deleting `firebaseAuthToken`.
3. Firebase Auth resolves the sign-in/up promise.
4. The function returns `user` immediately.
5. In `src/app/login/page.tsx`:
   ```typescript
   // Example from handleGoogleLogin / onLoginSubmit / onSignUpSubmit
   const user = await signIn(...);
   const redirectUrl = searchParams.get('redirect') || '/dashboard/profile';
   router.push(redirectUrl);
   router.refresh();
   ```
6. `router.push()` triggers a Next.js Server Component fetch for `/dashboard/profile`.
7. At this exact moment, `onAuthStateChanged` has either not fired yet, or `authUser.getIdToken()` is still in flight.
8. The browser transmits the HTTP request **without** `Cookie: firebaseAuthToken=...`.
9. `src/middleware.ts` runs on the server, observes `!token`, and redirects to:
   `/login?redirect=%2Fdashboard%2Fprofile`.
10. The user is bounced right back to `/login`.

---

## 4. Root Cause Analysis: The Infinite Redirect Loops

### 4.1 Loop Mechanism 1: The Login-to-Dashboard Ping-Pong
```
[User on /login]
       │ Submits credentials / Google OAuth
       ▼
[signIn / signUp]
       │ Clears firebaseAuthToken cookie
       │ Resolves Firebase promise
       │ Returns without setting replacement cookie
       ▼
[router.push('/dashboard/profile')]
       │ Sends HTTP request to Next.js server (Cookie: NONE)
       ▼
[src/middleware.ts]
       │ Checks request.cookies.get('firebaseAuthToken') -> undefined
       ▼
[NextResponse.redirect('/login?redirect=/dashboard/profile')]
       │ Next.js Router navigates back to /login
       ▼
[User back on /login]
```

### 4.2 Loop Mechanism 2: Stale UID Guard in `onAuthUserChanged`
In `src/lib/auth.ts:359-363`:
```typescript
let currentUid: string | null = null;
const unsubscribe = onAuthStateChanged(auth, async (authUser) => {
  if (authUser?.uid === currentUid && authUser) return;
  currentUid = authUser ? authUser.uid : null;
```
If a user is already loaded in browser memory (`currentUid === 'uid-123'`), and subsequently calls `signIn()`:
1. `signIn()` clears the cookie (`expires=1970`).
2. Firebase re-triggers `onAuthStateChanged` with the same `uid-123`.
3. Because `authUser.uid === currentUid`, it **returns early**.
4. Lines 364–372 (which set `document.cookie = firebaseAuthToken=...`) NEVER execute!
5. The cookie remains deleted indefinitely. Every attempt to access `/dashboard` or `/dashboard/profile` is permanently rejected by middleware.

### 4.3 Loop Mechanism 3: Orphan Cookie vs Client Session Mismatch
In `src/app/dashboard/layout.tsx:88-92`:
```typescript
useEffect(() => {
  if (!loading && !authUser) {
    router.push('/login');
  }
}, [loading, authUser, router]);
```
If a client has a stale or orphan `firebaseAuthToken` cookie (e.g. from an earlier mock session or unexpired token), but Firebase client state has no user:
1. Browser requests `/dashboard/profile`.
2. Middleware detects `firebaseAuthToken` -> Allows access.
3. Page loads on client, `useAuth` finishes loading with `authUser === null`.
4. `DashboardLayout` executes `router.push('/login')`.
5. Crucially, `DashboardLayout` does **not** clear the cookie.
6. If `/login` redirects authenticated users based on cookie, the user is bounced back and forth indefinitely.

### 4.4 Loop Mechanism 4: Unconditional `/dashboard` Middleware Redirection
```
Admin navigates to /dashboard
       │
       ▼
[src/middleware.ts]
       │ if (pathname === '/dashboard')
       │   return NextResponse.redirect('/dashboard/profile')
       ▼
Admin lands on /dashboard/profile
       │ Admin clicks "Panel Principal" (<Link href="/dashboard">)
       ▼
[src/middleware.ts]
       │ Immediately redirects back to /dashboard/profile
```
Admins are permanently blocked from viewing the main admin dashboard.

---

## 5. Role-Based Access Control & Routing Behavior Matrix

### 5.1 Roles Defined in the System
- `'admin'`: Explicit editorial administrator (e.g., `admin@eldiariodeladiaspora.com`). Has access to `/dashboard` (overview), `/dashboard/articles`, `/dashboard/categories`, `/dashboard/statistics`, `/dashboard/users`, and `/dashboard/settings/*`.
- `'editor'`: Editorial contributor. Has access to `/dashboard/articles` and `/dashboard/profile`.
- `'user'`: Regular reader. Strictly restricted to `/dashboard/profile` and public reader pages. Admin sidebar must be completely hidden.

### 5.2 Routing Behavior Matrix: Current vs Required

| User Role | Route Visited | Current Behavior | Required / Correct Behavior |
|---|---|---|---|
| **Unauthenticated** | `/dashboard` | Redirects to `/login?redirect=/dashboard` | **Redirect to `/login?redirect=/dashboard`** (PASS) |
| **Unauthenticated** | `/dashboard/profile` | Redirects to `/login?redirect=/dashboard/profile` | **Redirect to `/login?redirect=/dashboard/profile`** (PASS) |
| **Unauthenticated** | `/dashboard/articles` | Redirects to `/login?redirect=/dashboard/articles` | **Redirect to `/login?redirect=/dashboard/articles`** (PASS) |
| **Unauthenticated** | `/login` | Displays Login / Sign-up Tabs | **Displays Login / Sign-up Tabs** (PASS) |
| **Reader (`role: 'user'`)** | `/login` | Remains on `/login` form | **Auto-redirect to `/dashboard/profile`** |
| **Reader (`role: 'user'`)** | `/dashboard` | Middleware redirects to `/dashboard/profile` | **Redirect to `/dashboard/profile`** |
| **Reader (`role: 'user'`)** | `/dashboard/profile` | Renders Profile (no admin sidebar) | **Renders Profile (no admin sidebar)** (PASS) |
| **Reader (`role: 'user'`)** | `/dashboard/articles` | Passes middleware, client layout pushes to `/dashboard/profile` | **Redirect to `/dashboard/profile`** |
| **Reader (`role: 'user'`)** | `/dashboard/settings/*`| Passes middleware, client layout pushes to `/dashboard/profile` | **Redirect to `/dashboard/profile`** |
| **Admin (`role: 'admin'`)** | `/login` | Remains on `/login` form | **Auto-redirect to `/dashboard`** |
| **Admin (`role: 'admin'`)** | `/dashboard` | **BUG:** Middleware redirects to `/dashboard/profile`! | **Renders Admin Overview (`DashboardClient`)** with sidebar |
| **Admin (`role: 'admin'`)** | `/dashboard/profile` | Renders Profile with admin sidebar | **Renders Profile with admin sidebar** (PASS) |
| **Admin (`role: 'admin'`)** | `/dashboard/articles` | Renders Articles table with sidebar | **Renders Articles table with sidebar** (PASS) |
| **Admin (`role: 'admin'`)** | `/dashboard/settings/*`| Renders Site Settings with sidebar | **Renders Site Settings with sidebar** (PASS) |

---

## 6. Actionable Remediation Plan & Exact Files Needing Changes

### File 1: `src/lib/auth.ts`
1. **Implement Synchronous Cookie Management**:
   Define `syncAuthCookies(user: User, role?: string)` and `clearAuthCookies()`:
   ```typescript
   export async function syncAuthCookies(user: User, role?: string): Promise<void> {
     if (typeof document === 'undefined') return;
     try {
       const token = await user.getIdToken();
       document.cookie = `firebaseAuthToken=${token}; path=/; max-age=${60 * 60 * 24 * 7}; SameSite=Lax`;
       if (role) {
         document.cookie = `userRole=${role}; path=/; max-age=${60 * 60 * 24 * 7}; SameSite=Lax`;
       }
     } catch (e) {
       document.cookie = `firebaseAuthToken=mock-jwt-token; path=/; max-age=${60 * 60 * 24 * 7}; SameSite=Lax`;
     }
   }

   export function clearAuthCookies(): void {
     if (typeof document === 'undefined') return;
     document.cookie = 'firebaseAuthToken=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT; SameSite=Lax';
     document.cookie = 'userRole=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT; SameSite=Lax';
   }
   ```
2. **Update `signIn()`**:
   In the successful Firebase branch, await token acquisition and cookie synchronization **before returning**:
   ```typescript
   const userCredential = await signInWithEmailAndPassword(auth, email, password);
   const user = userCredential.user;
   const isExplicitAdmin = email.toLowerCase() === 'admin@eldiariodeladiaspora.com';
   const profile = await getUserProfile(user.uid).catch(() => null);
   const role = profile?.role || (isExplicitAdmin ? 'admin' : 'user');
   await syncAuthCookies(user, role);
   return user;
   ```
3. **Update `signUp()`**:
   In the successful registration branch, sync cookies before returning:
   ```typescript
   await syncAuthCookies(user, 'user');
   return user;
   ```
4. **Update `signInWithGoogle()`**:
   In the successful popup branch, sync cookies before returning:
   ```typescript
   const isExplicitAdmin = user.email?.toLowerCase() === 'admin@eldiariodeladiaspora.com';
   const role = isExplicitAdmin ? 'admin' : 'user';
   await syncAuthCookies(user, role);
   return user;
   ```
5. **Update `signOut()`**:
   Call `clearAuthCookies()`.
6. **Fix `onAuthUserChanged()`**:
   Remove the early return that bypasses cookie setting when `currentUid === authUser.uid`. Always guarantee that if `authUser` is truthy, cookies are synchronized; if falsy, `clearAuthCookies()` is called.

### File 2: `src/middleware.ts`
1. **Remove the Unconditional `/dashboard` Hijack**:
   Delete:
   ```typescript
   // REMOVE THIS:
   if (pathname === '/dashboard') {
     return NextResponse.redirect(new URL('/dashboard/profile', request.url));
   }
   ```
2. **Implement Role-Aware Edge Redirection**:
   Read both `firebaseAuthToken` and `userRole` cookies:
   ```typescript
   export function middleware(request: NextRequest) {
     const token = request.cookies.get('firebaseAuthToken')?.value;
     const role = request.cookies.get('userRole')?.value;
     const { pathname } = request.nextUrl;

     // 1. Unauthenticated requests to any dashboard route -> Redirect to /login
     if (pathname.startsWith('/dashboard') && !token) {
       const loginUrl = new URL('/login', request.url);
       loginUrl.searchParams.set('redirect', pathname);
       return NextResponse.redirect(loginUrl);
     }

     // 2. Reader user trying to access admin dashboard routes -> Redirect to profile
     if (role === 'user' && pathname.startsWith('/dashboard') && pathname !== '/dashboard/profile') {
       return NextResponse.redirect(new URL('/dashboard/profile', request.url));
     }

     // 3. /no-access route fallback
     if (pathname === '/no-access') {
       return NextResponse.redirect(new URL(token ? '/dashboard/profile' : '/login', request.url));
     }

     return NextResponse.next();
   }
   ```

### File 3: `src/app/login/page.tsx`
1. **Add Authenticated Auto-Redirect**:
   In `LoginContent`, use `useAuth()`: if `!loading && authUser && userProfile`, automatically redirect the already-authenticated user:
   ```typescript
   useEffect(() => {
     if (!loading && authUser && userProfile) {
       const isAdmin = userProfile.role === 'admin' || userProfile.role === 'editor';
       const defaultTarget = isAdmin ? '/dashboard' : '/dashboard/profile';
       const target = searchParams.get('redirect') || defaultTarget;
       router.push(target);
     }
   }, [loading, authUser, userProfile, router, searchParams]);
   ```
2. **Fix Destination in `handleQuickAdminLogin`**:
   Change fallback from `/dashboard/articles` to `/dashboard`.
3. **Fix Destination in `onLoginSubmit`**:
   If admin, target `/dashboard` (or `redirect` parameter); if reader, target `/dashboard/profile`.

### File 4: `src/app/dashboard/layout.tsx`
1. **Prevent Orphan Cookie Loops**:
   When `!loading && !authUser`, ensure cookies are cleared before pushing to `/login`:
   ```typescript
   useEffect(() => {
     if (!loading && !authUser) {
       if (typeof document !== 'undefined') {
         document.cookie = 'firebaseAuthToken=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT; SameSite=Lax';
         document.cookie = 'userRole=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT; SameSite=Lax';
       }
       router.push('/login');
     }
   }, [loading, authUser, router]);
   ```
2. **Ensure Robust Profile Fallback**:
   If `authUser` exists but `userProfile` is null after loading, construct a safe reader profile fallback rather than hanging indefinitely on the spinner.

### File 5: `src/hooks/useUserRole.ts`
1. **Align `isIsolatedMode`**:
   Remove `!process.env.NEXT_PUBLIC_FIREBASE_API_KEY` from the isolated condition, or unify isolated mode configuration across all modules so `useUserRole` subscribes to real Firebase Auth by default.

### File 6: `src/components/admin/DashboardClientWrapper.tsx`
1. **Eliminate Bare `/no-access` Redirect**:
   Replace `redirect('/no-access')` with `redirect('/dashboard/profile')`, or render an inline `Alert` with "Acceso Restringido", keeping readers safely in their profile rather than stranding them on the bare `/no-access` page.

---

## 7. Verification Method

1. **Verify No Redirect Loop on Email/Password Sign-Up**:
   - Register a new reader user at `/login?tab=register`.
   - Verify immediate, smooth redirection to `/dashboard/profile`.
   - Verify `firebaseAuthToken` and `userRole=user` cookies are present.
   - Verify no 307 bounces back to `/login`.
2. **Verify No Redirect Loop on Google Sign-In**:
   - Click "Continuar con Google".
   - Verify prompt `prompt: 'select_account'` executes.
   - Verify redirection to `/dashboard/profile` without looping.
3. **Verify Admin Dashboard Access**:
   - Log in as `admin@eldiariodeladiaspora.com`.
   - Navigate to `/dashboard`.
   - Verify `src/app/dashboard/page.tsx` renders the full metrics grid, draft queue, and admin sidebar.
   - Verify clicking "Panel Principal" remains on `/dashboard` without bouncing to `/dashboard/profile`.
4. **Verify Reader Role Isolation**:
   - Log in as reader user (`role: 'user'`).
   - Manually navigate to `/dashboard`, `/dashboard/articles`, or `/dashboard/settings/ads`.
   - Verify immediate redirection to `/dashboard/profile`.
   - Verify the admin sidebar is completely absent.
5. **Verify Unauthenticated Protection**:
   - Clear all cookies in incognito mode.
   - Navigate to `/dashboard` or `/dashboard/profile`.
   - Verify redirection to `/login?redirect=...`.
