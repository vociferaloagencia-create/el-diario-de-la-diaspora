# Handoff Report — Explorer 2: Middleware & Routing Loops

**Agent**: Explorer 2 (Architecture & Codebase Investigator)  
**Parent Agent**: Project Orchestrator (`orchestrator_main` / ID: `1004b9ab-dfa5-423d-b744-a829b4bb274e`)  
**Workspace**: `C:\Users\Legit\.gemini\antigravity\scratch\el-diario-de-la-diaspora-main`  
**Working Directory**: `C:\Users\Legit\.gemini\antigravity\scratch\el-diario-de-la-diaspora-main\.agents\teamwork\explorer_survey_2`  
**Date**: 2026-09-26  

---

## 1. Observation

### Observation 1: Cookie Deletion on Entry Without Immediate Restoration
- **File**: `src/lib/auth.ts`
  - In `signIn()` (lines 108–149):
    ```typescript
    export async function signIn(email: string, password: string): Promise<User> {
      if (typeof window !== 'undefined') {
        localStorage.removeItem('mock_user_session');
        document.cookie = 'firebaseAuthToken=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT';
      }
      ...
      try {
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        return userCredential.user;
      }
    ```
    Line 111 deletes `firebaseAuthToken` cookie immediately. If `signInWithEmailAndPassword` succeeds (line 147), `return userCredential.user` executes **without setting `document.cookie`**.
  - In `signUp()` (lines 183–207):
    ```typescript
    export async function signUp(name: string, email: string, password: string): Promise<User> {
      if (typeof window !== 'undefined') {
        localStorage.removeItem('mock_user_session');
        document.cookie = 'firebaseAuthToken=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT';
      }
      try {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        ...
        return user;
    ```
    Line 186 deletes `firebaseAuthToken`. The success path at line 207 returns `user` **without setting `document.cookie`**.
  - In `signInWithGoogle()` (lines 247–285):
    ```typescript
    export async function signInWithGoogle(): Promise<User> {
      if (typeof window !== 'undefined') {
        localStorage.removeItem('mock_user_session');
        document.cookie = 'firebaseAuthToken=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT';
      }
      try {
        const provider = new GoogleAuthProvider();
        provider.setCustomParameters({ prompt: 'select_account' });
        const userCredential = await signInWithPopup(auth, provider);
        const user = userCredential.user;
        ...
        return user;
    ```
    Line 250 deletes `firebaseAuthToken`. The success path at line 285 returns `user` **without setting `document.cookie`**.

### Observation 2: Immediate Navigation Following Auth Calls
- **File**: `src/app/login/page.tsx`
  - In `handleGoogleLogin` (lines 73–81):
    ```typescript
    const user = await signInWithGoogle();
    ...
    const redirectUrl = searchParams.get('redirect') || '/dashboard/profile';
    router.push(redirectUrl);
    router.refresh();
    ```
  - In `onLoginSubmit` (lines 122–133):
    ```typescript
    const user = await signIn(values.email, values.password);
    ...
    const isAdmin = values.email.toLowerCase().includes('admin');
    const redirectUrl = searchParams.get('redirect') || (isAdmin ? '/dashboard/articles' : '/dashboard/profile');
    router.push(redirectUrl);
    router.refresh();
    ```
  - In `onSignUpSubmit` (lines 149–156):
    ```typescript
    await signUp(values.name, values.email, values.password);
    ...
    const redirectUrl = searchParams.get('redirect') || '/dashboard/profile';
    router.push(redirectUrl);
    router.refresh();
    ```
  All four authentication actions call `router.push(redirectUrl)` synchronously after the auth promise resolves, while the cookie has been expired by the auth function and the asynchronous `onAuthStateChanged` callback has not completed.

### Observation 3: Edge Middleware Cookie Check & Bouncing
- **File**: `src/middleware.ts` (lines 4–13):
  ```typescript
  export function middleware(request: NextRequest) {
    const token = request.cookies.get('firebaseAuthToken');
    const { pathname } = request.nextUrl;

    // Protect dashboard routes if no auth token is present
    if (pathname.startsWith('/dashboard') && !token) {
      const loginUrl = new URL('/login', request.url);
      loginUrl.searchParams.set('redirect', pathname);
      return NextResponse.redirect(loginUrl);
    }
  ```
  When the HTTP request arrives without `firebaseAuthToken`, middleware responds with `NextResponse.redirect('/login?redirect=...')`.

### Observation 4: Stale UID Guard in `onAuthUserChanged`
- **File**: `src/lib/auth.ts` (lines 359–368):
  ```typescript
  let currentUid: string | null = null;
  const unsubscribe = onAuthStateChanged(auth, async (authUser) => {
    if (authUser?.uid === currentUid && authUser) return;
    currentUid = authUser ? authUser.uid : null;

    if (authUser) {
      let token = 'mock-jwt-token';
      try {
        token = await authUser.getIdToken().catch(() => 'mock-jwt-token');
        document.cookie = `firebaseAuthToken=${token}; path=/; max-age=${60 * 60 * 24 * 7}`;
  ```
  If `currentUid` was previously set to `authUser.uid`, when `onAuthStateChanged` triggers after `signIn()` clears the cookie, `authUser?.uid === currentUid` is `true`. The function returns early at line 361 without setting `document.cookie`.

### Observation 5: Unconditional `/dashboard` Redirection in Middleware
- **File**: `src/middleware.ts` (lines 15–17):
  ```typescript
  if (pathname === '/dashboard') {
    return NextResponse.redirect(new URL('/dashboard/profile', request.url));
  }
  ```
  Every request to `/dashboard` is redirected to `/dashboard/profile`, preventing access to `src/app/dashboard/page.tsx` (`DashboardClient`) for all users, including administrators.

### Observation 6: Disparity in Isolated Mode Flag
- **File**: `src/hooks/useUserRole.ts` (lines 8–10):
  ```typescript
  const isIsolatedMode = !process.env.NEXT_PUBLIC_FIREBASE_API_KEY || 
    process.env.NEXT_PUBLIC_FIREBASE_API_KEY.includes('mock') ||
    process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID === 'demo-isolated';
  ```
  Compared to `src/lib/auth.ts:18`:
  `const isIsolatedMode = false;`.
  Because `NEXT_PUBLIC_FIREBASE_API_KEY` is not defined in the environment (fallback is in `src/lib/firebase.ts`), `useUserRole` evaluates `isIsolatedMode` to `true`, querying `localStorage.getItem('mock_user_session')` instead of Firestore.

---

## 2. Logic Chain

1. **Premise 1 (from Observation 1)**: `signIn`, `signUp`, and `signInWithGoogle` execute `document.cookie = 'firebaseAuthToken=; ... expires=1970'`, clearing the token in the browser before invoking Firebase.
2. **Premise 2 (from Observation 1 & Observation 4)**: The success paths of `signIn`, `signUp`, and `signInWithGoogle` return the `User` object without setting the replacement cookie. Setting the cookie is delegated to `onAuthStateChanged`, which is asynchronous and also returns early if `authUser?.uid === currentUid`.
3. **Premise 3 (from Observation 2)**: The login page immediately executes `router.push('/dashboard/profile')` and `router.refresh()` as soon as the auth function returns.
4. **Inference 1**: The client-side navigation request to `/dashboard/profile` is dispatched over HTTP with an empty or deleted `firebaseAuthToken` cookie.
5. **Premise 4 (from Observation 3)**: `src/middleware.ts` runs on the server/edge for `/dashboard/profile`. Seeing `!token`, it responds with HTTP 307 redirecting back to `/login?redirect=%2Fdashboard%2Fprofile`.
6. **Inference 2 (Root Cause of Infinite Loop)**: The user is bounced back to `/login`. If the user submits again or if automatic redirect triggers, the exact sequence repeats. Furthermore, if `currentUid` matches `authUser.uid`, `onAuthStateChanged` never restores the cookie, locking the user in a permanent redirect loop.
7. **Premise 5 (from Observation 5)**: In `middleware.ts`, `if (pathname === '/dashboard') return NextResponse.redirect(new URL('/dashboard/profile', request.url));` executes unconditionally for all users possessing a valid token.
8. **Inference 3 (Root Cause of Admin Dashboard Inaccessibility)**: Admins attempting to visit `/dashboard` (via URL, sidebar link "Panel Principal", or navbar menu "Panel") are always intercepted and redirected to `/dashboard/profile`. The main admin overview page (`src/app/dashboard/page.tsx`) is unreachable.

---

## 3. Caveats

1. **Firestore Security Rules**: Explorer 3 is surveying `firestore.rules`. Firestore security rules operate independently of Next.js middleware routing, but both rely on proper authentication tokens.
2. **Adblocker / Network Fallback**: If network requests to Firebase or Firestore fail (e.g. adblocker or offline), fallback logic exists in `src/lib/auth.ts`. However, fallback mock cookies (`mock-jwt-token-...`) must follow the exact same cookie synchronization rules as real tokens to avoid middleware rejection.
3. **External Environment Variables**: The project does not currently contain a `.env.local` file; it relies on hardcoded fallback keys in `src/lib/firebase.ts`. Any environment variable checks that expect `process.env.NEXT_PUBLIC_FIREBASE_API_KEY` to be defined will evaluate as falsy unless an `.env` file is provided.

---

## 4. Conclusion

The middleware and authentication routing architecture requires four specific, localized modifications:

1. **Synchronous Cookie Synchronization in `src/lib/auth.ts`**:
   - Introduce `syncAuthCookies(user: User, role?: string)` which awaits `user.getIdToken()` and writes `firebaseAuthToken` and `userRole` cookies with `SameSite=Lax` and `path=/`.
   - Call `await syncAuthCookies(user, role)` before returning from `signIn()`, `signUp()`, and `signInWithGoogle()`.
   - Remove the early return `if (authUser?.uid === currentUid && authUser) return;` in `onAuthUserChanged` to ensure the cookie is refreshed whenever an authenticated user state is present.
   - Introduce `clearAuthCookies()` to wipe both `firebaseAuthToken` and `userRole` on `signOut()`.

2. **Refactor `src/middleware.ts`**:
   - Delete the unconditional redirect `if (pathname === '/dashboard') return NextResponse.redirect('/dashboard/profile')`.
   - Allow admins (`role === 'admin' || role === 'editor' || role === 'superadmin'`) to access `/dashboard` and administrative sub-routes.
   - Restrict regular readers (`role === 'user'`) accessing `/dashboard` or admin sub-routes by redirecting them to `/dashboard/profile`.
   - Redirect unauthenticated users (`!token`) accessing any `/dashboard*` route to `/login?redirect=${pathname}`.

3. **Refactor `src/app/login/page.tsx`**:
   - In `handleQuickAdminLogin`, set redirect target to `searchParams.get('redirect') || '/dashboard'`.
   - In `onLoginSubmit`, set admin redirect target to `searchParams.get('redirect') || '/dashboard'` and reader to `searchParams.get('redirect') || '/dashboard/profile'`.
   - Add client-side session detection: if `!loading && authUser && userProfile`, automatically redirect to `/dashboard` (admin) or `/dashboard/profile` (reader).

4. **Align `src/app/dashboard/layout.tsx` & `src/hooks/useUserRole.ts`**:
   - In `DashboardLayout`, when `!loading && !authUser`, ensure cookies are cleared before `router.push('/login')` to prevent orphan cookie ping-pong.
   - In `useUserRole.ts`, align `isIsolatedMode` with `firebase.ts` and `auth.ts`.
   - In `DashboardClientWrapper.tsx`, redirect non-permitted users to `/dashboard/profile` instead of the bare `/no-access` page.

---

## 5. Verification Method

### Automated Build & Compilation
```powershell
npm.cmd run build
```
Verify Next.js compiles all pages (`/dashboard`, `/dashboard/profile`, `/login`) and middleware bundle without errors.

### Manual Verification Scenarios
1. **Reader Account Creation & Redirection**:
   - Open `/login?tab=register`.
   - Register a reader account (`test-reader@diaspora.com`).
   - Confirm immediate redirect to `/dashboard/profile` with ZERO redirect loops or 307 bounces back to `/login`.
   - Inspect browser cookies: verify `firebaseAuthToken` and `userRole=user` are set with `path=/`.
2. **Reader Role Boundary**:
   - As reader, manually enter URL `/dashboard` or `/dashboard/articles`.
   - Confirm middleware/layout immediately redirects to `/dashboard/profile`.
   - Verify the admin sidebar is completely hidden.
3. **Admin Sign-In & Dashboard Access**:
   - Log in as `admin@eldiariodeladiaspora.com` (or click "Acceso Rápido Administrador").
   - Confirm direct navigation to `/dashboard`.
   - Confirm `DashboardClient` renders statistics, published articles, drafts, and categories.
   - Click "Panel Principal" in the sidebar: verify it stays on `/dashboard` and does NOT redirect to `/dashboard/profile`.
   - Click "Panel" in the public navbar: verify it navigates to `/dashboard`.
4. **Sign-Out Cookie Invalidation**:
   - Click logout in the dashboard header or user menu.
   - Confirm redirection to `/login` or `/`.
   - Inspect browser cookies: verify `firebaseAuthToken` and `userRole` cookies have expired (`Thu, 01 Jan 1970`).
   - Attempt to navigate to `/dashboard/profile`: verify middleware redirects to `/login?redirect=%2Fdashboard%2Fprofile`.

### Invalidation Conditions
- If `document.cookie` cannot be read by middleware because `SameSite` or `path` is incorrectly scoped.
- If `useAuth()` takes longer than expected to resolve on slower connections without a loading state, causing layout flash.
