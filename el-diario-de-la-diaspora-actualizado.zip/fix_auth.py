import re

with open('src/components/site/AuthArea.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

content = content.replace('title="Acceder a tu cuenta"', 'title="Iniciar Sesión"')
content = content.replace('aria-label="Acceder"', 'aria-label="Iniciar Sesión"')
content = content.replace('>[11px]">Acceder</span>', '>[11px]">Iniciar Sesión</span>')
content = content.replace('href="/login?tab=login"', 'href="/login"')

with open('src/components/site/AuthArea.tsx', 'w', encoding='utf-8') as f:
    f.write(content)
