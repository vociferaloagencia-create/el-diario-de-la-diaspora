import { test, assert } from './harness';
import { setupMockBrowserEnv, createMockNextRequest } from './harness/env';
import { TEST_FIXTURES } from './harness/fixtures';
import { middleware } from '@/middleware';
import * as authLib from '@/lib/auth';
import {
  getCategories,
  getCategoryBySlug,
  getSiteSettings,
  getHeroArticles,
  getLatestArticles,
  getMostReadArticles
} from '@/lib/firestore';

/**
 * TIER 1: Feature Coverage (Isolated Happy Paths)
 * Authoritative source: ORIGINAL_REQUEST.md (§R1, §R2, §Acceptance Criteria) and PROJECT.md (§Interface Contracts)
 */

test(1, 'T1.1: Email/Password Registration assigns reader role and synchronizes auth cookies', async () => {
  const { cookieJar, cleanup } = setupMockBrowserEnv();
  try {
    const reader = TEST_FIXTURES.reader;
    const user = await authLib.signUp(reader.name, reader.email, reader.password);
    
    assert.ok(user, 'signUp should return a valid User object');
    assert.equal(user.email, reader.email, 'User email should match registration email');

    // Expected output derivation: PROJECT.md §Interface Contracts §Auth Layer
    // syncAuthCookies must set firebaseAuthToken and userRole='user'
    const authToken = cookieJar.get('firebaseAuthToken');
    const userRole = cookieJar.get('userRole');

    assert.ok(authToken, 'firebaseAuthToken cookie must be set upon registration');
    assert.equal(userRole, 'user', 'userRole cookie must be set to "user" for readers upon registration');
  } finally {
    cleanup();
  }
});

test(1, 'T1.2: Email/Password Admin Sign-in sets admin role and synchronizes auth cookies', async () => {
  const { cookieJar, cleanup } = setupMockBrowserEnv();
  try {
    const admin = TEST_FIXTURES.admin;
    const user = await authLib.signIn(admin.email, admin.password);

    assert.ok(user, 'signIn should return a valid User object');
    assert.equal(user.email, admin.email, 'User email should match admin email');

    // Expected output derivation: ORIGINAL_REQUEST.md §R1: "role: 'admin' for explicit editorial staff"
    const authToken = cookieJar.get('firebaseAuthToken');
    const userRole = cookieJar.get('userRole');

    assert.ok(authToken, 'firebaseAuthToken cookie must be set upon admin sign-in');
    assert.equal(userRole, 'admin', 'userRole cookie must be set to "admin" for admin@eldiariodeladiaspora.com');
  } finally {
    cleanup();
  }
});

test(1, 'T1.3: Google OAuth Provider is configured with prompt: select_account', async () => {
  const { cookieJar, cleanup } = setupMockBrowserEnv();
  try {
    // Expected output derivation: ORIGINAL_REQUEST.md §R1: "prompt: 'select_account'"
    // We execute signInWithGoogle and verify it completes with reader role
    const user = await authLib.signInWithGoogle();
    assert.ok(user, 'signInWithGoogle must resolve to a valid User object');
    
    const authToken = cookieJar.get('firebaseAuthToken');
    const userRole = cookieJar.get('userRole');
    assert.ok(authToken, 'firebaseAuthToken cookie must be set after Google Sign-In');
    assert.equal(userRole, 'user', 'userRole cookie must be set to "user" for Google Sign-In readers');
  } finally {
    cleanup();
  }
});

test(1, 'T1.4: Non-blocking 1.8s Timeout Fallback Contract exists and defaults to 1800ms', async () => {
  // Expected output derivation: PROJECT.md §Interface Contracts §Auth Layer
  // withTimeout<T>(promise: Promise<T>, ms: number = 1800, fallbackValue?: T)
  const isAuthExportingTimeout = typeof (authLib as any).withTimeout === 'function';
  
  if (isAuthExportingTimeout) {
    const withTimeout = (authLib as any).withTimeout;
    
    // Test fast promise resolving within timeout
    const fastRes = await withTimeout(Promise.resolve('fast-success'), 1800);
    assert.equal(fastRes, 'fast-success', 'withTimeout should resolve fast promises normally');

    // Test timed-out promise with fallback
    const hangingPromise = new Promise((resolve) => setTimeout(() => resolve('stalled'), 3000));
    const fallbackRes = await withTimeout(hangingPromise, 100, 'fallback-reader');
    assert.equal(fallbackRes, 'fallback-reader', 'withTimeout should return fallback value on timeout');
  } else {
    // Escalate missing explicit export if interface contract requires it
    throw new Error('PROJECT.md contract violation: withTimeout must be an exported or verified helper conforming to 1800ms default');
  }
});

test(1, 'T1.5: Edge Middleware redirects unauthenticated user from /dashboard to /login', async () => {
  // Expected output derivation: PROJECT.md §Interface Contracts §Middleware:
  // "Path /dashboard* without firebaseAuthToken -> HTTP 307 to /login?redirect=<pathname>"
  const req = createMockNextRequest('/dashboard');
  const res = middleware(req);

  assert.equal(res.status, 307, 'Unauthenticated access to /dashboard must return HTTP 307');
  const location = res.headers.get('location');
  assert.ok(location, 'Redirect response must have a Location header');
  assert.includes(location, '/login', 'Location header must point to /login');
  assert.includes(location, 'redirect=%2Fdashboard', 'Location header must include redirect parameter');
});

test(1, 'T1.6: Edge Middleware allows authenticated reader to access /dashboard/profile', async () => {
  // Expected output derivation: PROJECT.md §Interface Contracts §Middleware:
  // "Path /dashboard/profile for any authenticated user -> Allow (NextResponse.next())"
  const req = createMockNextRequest('/dashboard/profile', {
    cookies: {
      firebaseAuthToken: 'valid-reader-token',
      userRole: 'user',
    }
  });
  const res = middleware(req);

  assert.equal(res.status, 200, 'Authenticated reader accessing /dashboard/profile must be allowed (status 200)');
  assert.equal(res.headers.get('location'), null, 'Allowed request must not redirect');
});

test(1, 'T1.7: Edge Middleware allows authenticated admin to access /dashboard Overview', async () => {
  // Expected output derivation: PROJECT.md §Interface Contracts §Middleware:
  // "Path /dashboard with userRole === 'admin' || 'editor' || 'superadmin' -> Allow (NextResponse.next())"
  const req = createMockNextRequest('/dashboard', {
    cookies: {
      firebaseAuthToken: 'valid-admin-token',
      userRole: 'admin',
    }
  });
  const res = middleware(req);

  assert.equal(res.status, 200, 'Authenticated admin accessing /dashboard must be allowed (status 200)');
  assert.equal(res.headers.get('location'), null, 'Admin accessing /dashboard must not be redirected to /dashboard/profile');
});

test(1, 'T1.8: Public Site Content queries retrieve categories, settings, hero, and latest articles', async () => {
  // Expected output derivation: ORIGINAL_REQUEST.md §R2 and §Acceptance Criteria:
  // "Public readers can view articles, categories, search, and site footer links."
  const categories = await getCategories();
  assert.ok(Array.isArray(categories) && categories.length >= 8, 'getCategories must return at least 8 categories');
  assert.ok(categories.some(c => c.slug === 'actualidad'), 'Categories must include actualidad');
  assert.ok(categories.some(c => c.slug === 'la-diaspora'), 'Categories must include la-diaspora');

  const settings = await getSiteSettings();
  assert.ok(settings, 'getSiteSettings must return site configuration');
  assert.equal(settings.branding.siteName, 'El Diario de la Diáspora', 'Branding siteName must match El Diario de la Diáspora');

  const heroes = await getHeroArticles();
  assert.ok(Array.isArray(heroes) && heroes.length > 0, 'getHeroArticles must return hero articles');

  const latest = await getLatestArticles(5);
  assert.ok(Array.isArray(latest) && latest.length > 0, 'getLatestArticles must return latest articles');

  const mostRead = await getMostReadArticles();
  assert.ok(Array.isArray(mostRead) && mostRead.length > 0, 'getMostReadArticles must return most read articles');
});
