import { test, assert } from './harness';
import { setupMockBrowserEnv, createMockNextRequest } from './harness/env';
import { middleware } from '@/middleware';
import * as authLib from '@/lib/auth';
import { getUserProfile } from '@/lib/auth';

/**
 * TIER 2: Boundary & Corner Cases
 * Authoritative source: ORIGINAL_REQUEST.md (§R1, Acceptance Criteria) and PROJECT.md (§Interface Contracts)
 */

test(2, 'T2.1: Authentication Input Validation rejects malformed emails and short passwords', async () => {
  // Expected output derivation: ORIGINAL_REQUEST.md §R1 & Acceptance Criteria
  const { cleanup } = setupMockBrowserEnv();
  try {
    // Attempt sign in with empty strings
    await assert.rejects(
      async () => {
        await authLib.signIn('', '');
      },
      undefined,
      'Empty credentials should be rejected by authentication'
    );
  } finally {
    cleanup();
  }
});

test(2, 'T2.2: Adblocked Firestore / Network Freeze resolves via 1.8s fallback to reader session without crashing', async () => {
  // Expected output derivation: ORIGINAL_REQUEST.md §Acceptance Criteria:
  // "All network or offline timeouts gracefully fall back to local reader session without crashing."
  // Non-blocking fail-safe timeout protection so auth never freezes or loops even if browser adblockers block firestore.googleapis.com.
  const { cleanup } = setupMockBrowserEnv();
  try {
    const start = Date.now();
    // Fetch profile for an arbitrary UID under simulated network failure/offline mode
    const profile = await getUserProfile('test-offline-adblocked-uid');
    const elapsed = Date.now() - start;

    assert.ok(profile, 'getUserProfile must return a fallback profile when Firestore is offline or blocked');
    assert.equal(profile?.role, 'user', 'Fallback profile must have default reader role "user"');
    assert.ok(elapsed <= 3500, `Profile retrieval should not hang indefinitely (took ${elapsed}ms, expected <= 3500ms)`);
  } finally {
    cleanup();
  }
});

test(2, 'T2.3: Unauthorized reader accessing /dashboard is bounced to /dashboard/profile', async () => {
  // Expected output derivation: PROJECT.md §Interface Contracts §Middleware:
  // "Path /dashboard with userRole === 'user' -> HTTP 307 to /dashboard/profile"
  const req = createMockNextRequest('/dashboard', {
    cookies: {
      firebaseAuthToken: 'valid-reader-token',
      userRole: 'user',
    }
  });

  const res = middleware(req);
  assert.equal(res.status, 307, 'Reader accessing /dashboard must return HTTP 307 redirect');
  const location = res.headers.get('location');
  assert.ok(location, 'Must provide redirect Location header');
  assert.includes(location, '/dashboard/profile', 'Reader accessing /dashboard must be redirected to /dashboard/profile');
});

test(2, 'T2.4: Unauthorized reader accessing admin sub-routes is redirected to /dashboard/profile', async () => {
  // Expected output derivation: PROJECT.md §Interface Contracts §Middleware:
  // "Path /dashboard/articles*, /categories*, /ads*, /settings* with userRole === 'user' -> HTTP 307 to /dashboard/profile"
  const adminSubRoutes = [
    '/dashboard/articles',
    '/dashboard/articles/new',
    '/dashboard/categories',
    '/dashboard/ads',
    '/dashboard/settings',
    '/dashboard/settings/branding',
    '/dashboard/users',
  ];

  for (const route of adminSubRoutes) {
    const req = createMockNextRequest(route, {
      cookies: {
        firebaseAuthToken: 'valid-reader-token',
        userRole: 'user',
      }
    });

    const res = middleware(req);
    assert.equal(res.status, 307, `Reader accessing admin sub-route ${route} must receive HTTP 307 redirect`);
    const location = res.headers.get('location');
    assert.ok(location, `Location header missing for ${route}`);
    assert.includes(location, '/dashboard/profile', `Reader accessing ${route} must be redirected to /dashboard/profile`);
  }
});

test(2, 'T2.5: Unauthenticated access to /no-access redirects to /login', async () => {
  // Expected output derivation: PROJECT.md §Architecture & Middleware:
  // Unauthenticated user requesting /no-access is redirected to /login
  const req = createMockNextRequest('/no-access');
  const res = middleware(req);

  assert.equal(res.status, 307, 'Unauthenticated /no-access request must return HTTP 307');
  const location = res.headers.get('location');
  assert.ok(location, 'Must provide redirect Location header');
  assert.includes(location, '/login', 'Unauthenticated /no-access must redirect to /login');
});

test(2, 'T2.6: Zero Redirect Loop guarantee for authenticated reader on /dashboard/profile', async () => {
  // Expected output derivation: ORIGINAL_REQUEST.md §Acceptance Criteria:
  // "No infinite redirect loops between /login and /dashboard/profile."
  // Authenticated reader accessing /dashboard/profile must be allowed directly (HTTP 200, no redirect)
  const req = createMockNextRequest('/dashboard/profile', {
    cookies: {
      firebaseAuthToken: 'valid-reader-token',
      userRole: 'user',
    }
  });

  const res = middleware(req);
  assert.equal(res.status, 200, 'Authenticated reader on /dashboard/profile must receive HTTP 200 pass-through');
  assert.equal(res.headers.get('location'), null, 'Must not emit redirect location for valid reader on /dashboard/profile');
});
