import { test, assert } from './harness';
import { setupMockBrowserEnv, createMockNextRequest } from './harness/env';
import { TEST_FIXTURES } from './harness/fixtures';
import { middleware } from '@/middleware';
import * as authLib from '@/lib/auth';

/**
 * TIER 3: Cross-Feature Combinations
 * Multi-step user journeys combining authentication, cookie synchronization, edge middleware, and session lifecycle.
 * Authoritative source: ORIGINAL_REQUEST.md (§R1, Acceptance Criteria) and PROJECT.md (§Interface Contracts)
 */

test(3, 'T3.1: Complete Reader Flow: Registration -> Profile access -> Admin route probe -> Bounce-back to profile', async () => {
  const { cookieJar, cleanup } = setupMockBrowserEnv();
  try {
    const readerFixture = TEST_FIXTURES.reader;

    // Step 1: Reader registers
    const user = await authLib.signUp(readerFixture.name, readerFixture.email, readerFixture.password);
    assert.ok(user, 'Reader registration must complete successfully');

    // Step 2: Verify cookies synchronized
    const token = cookieJar.get('firebaseAuthToken');
    const role = cookieJar.get('userRole');
    assert.ok(token, 'firebaseAuthToken must be set in cookies');
    assert.equal(role, 'user', 'userRole cookie must be "user"');

    // Step 3: Reader visits /dashboard/profile -> Allowed
    const profileReq = createMockNextRequest('/dashboard/profile', {
      cookies: cookieJar.getAll()
    });
    const profileRes = middleware(profileReq);
    assert.equal(profileRes.status, 200, 'Reader should have direct access to /dashboard/profile (status 200)');
    assert.equal(profileRes.headers.get('location'), null, 'Reader should not be redirected away from /dashboard/profile');

    // Step 4: Reader attempts to access admin /dashboard -> Bounced back to /dashboard/profile
    const adminDashboardReq = createMockNextRequest('/dashboard', {
      cookies: cookieJar.getAll()
    });
    const adminDashboardRes = middleware(adminDashboardReq);
    assert.equal(adminDashboardRes.status, 307, 'Reader attempting /dashboard must be redirected (307)');
    assert.includes(adminDashboardRes.headers.get('location'), '/dashboard/profile', 'Reader attempting /dashboard must bounce back to /dashboard/profile');

    // Step 5: Reader attempts to access /dashboard/articles -> Bounced back to /dashboard/profile
    const adminArticlesReq = createMockNextRequest('/dashboard/articles', {
      cookies: cookieJar.getAll()
    });
    const adminArticlesRes = middleware(adminArticlesReq);
    assert.equal(adminArticlesRes.status, 307, 'Reader attempting /dashboard/articles must be redirected (307)');
    assert.includes(adminArticlesRes.headers.get('location'), '/dashboard/profile', 'Reader attempting /dashboard/articles must bounce back to /dashboard/profile');

    // Step 6: Reader attempts to access /dashboard/settings -> Bounced back to /dashboard/profile
    const adminSettingsReq = createMockNextRequest('/dashboard/settings', {
      cookies: cookieJar.getAll()
    });
    const adminSettingsRes = middleware(adminSettingsReq);
    assert.equal(adminSettingsRes.status, 307, 'Reader attempting /dashboard/settings must be redirected (307)');
    assert.includes(adminSettingsRes.headers.get('location'), '/dashboard/profile', 'Reader attempting /dashboard/settings must bounce back to /dashboard/profile');
  } finally {
    cleanup();
  }
});

test(3, 'T3.2: Complete Admin Flow: Sign-in -> Overview & CMS access -> Logout -> Cookie wipe -> Protected route block', async () => {
  const { cookieJar, cleanup } = setupMockBrowserEnv();
  try {
    const adminFixture = TEST_FIXTURES.admin;

    // Step 1: Admin signs in
    const adminUser = await authLib.signIn(adminFixture.email, adminFixture.password);
    assert.ok(adminUser, 'Admin sign-in must succeed');

    // Step 2: Auth cookies synchronized
    const token = cookieJar.get('firebaseAuthToken');
    const role = cookieJar.get('userRole');
    assert.ok(token, 'firebaseAuthToken must be set for admin');
    assert.equal(role, 'admin', 'userRole cookie must be set to "admin"');

    // Step 3: Admin visits /dashboard Overview -> Allowed (Status 200, no redirect)
    const overviewReq = createMockNextRequest('/dashboard', {
      cookies: cookieJar.getAll()
    });
    const overviewRes = middleware(overviewReq);
    assert.equal(overviewRes.status, 200, 'Admin must have access to /dashboard Overview (status 200)');
    assert.equal(overviewRes.headers.get('location'), null, 'Admin should not be redirected away from /dashboard');

    // Step 4: Admin visits /dashboard/articles CMS -> Allowed
    const articlesReq = createMockNextRequest('/dashboard/articles', {
      cookies: cookieJar.getAll()
    });
    const articlesRes = middleware(articlesReq);
    assert.equal(articlesRes.status, 200, 'Admin must have access to /dashboard/articles (status 200)');
    assert.equal(articlesRes.headers.get('location'), null, 'Admin should not be redirected away from /dashboard/articles');

    // Step 5: Admin visits /dashboard/categories -> Allowed
    const categoriesReq = createMockNextRequest('/dashboard/categories', {
      cookies: cookieJar.getAll()
    });
    const categoriesRes = middleware(categoriesReq);
    assert.equal(categoriesRes.status, 200, 'Admin must have access to /dashboard/categories (status 200)');

    // Step 6: Admin logs out via signOut()
    await authLib.signOut();

    // Step 7: Verify auth cookies are wiped
    // Expected output derivation: PROJECT.md §Interface Contracts:
    // clearAuthCookies() expires firebaseAuthToken and userRole
    const postLogoutToken = cookieJar.get('firebaseAuthToken');
    const postLogoutRole = cookieJar.get('userRole');
    assert.ok(!postLogoutToken, 'firebaseAuthToken must be wiped upon signOut()');
    assert.ok(!postLogoutRole, 'userRole must be wiped upon signOut()');

    // Step 8: Subsequent attempt to access /dashboard must be blocked and redirected to /login
    const postLogoutReq = createMockNextRequest('/dashboard', {
      cookies: cookieJar.getAll()
    });
    const postLogoutRes = middleware(postLogoutReq);
    assert.equal(postLogoutRes.status, 307, 'Logged-out user accessing /dashboard must receive HTTP 307 redirect');
    const location = postLogoutRes.headers.get('location');
    assert.ok(location, 'Must provide redirect Location header');
    assert.includes(location, '/login', 'Must redirect to /login');
    assert.includes(location, 'redirect=%2Fdashboard', 'Must preserve return redirect URL');
  } finally {
    cleanup();
  }
});
