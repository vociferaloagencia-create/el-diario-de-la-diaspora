import type { Category, Article } from '@/lib/types';

export const TEST_FIXTURES = {
  reader: {
    name: 'Carlos Lector',
    email: 'carlos.diaspora@example.com',
    password: 'Password123!',
    expectedRole: 'user',
  },
  admin: {
    name: 'Director Editorial',
    email: 'admin@eldiariodeladiaspora.com',
    password: 'admin123456',
    expectedRole: 'admin',
  },
  editor: {
    name: 'Editor Jefe',
    email: 'editor@eldiariodeladiaspora.com',
    password: 'Editor123!',
    expectedRole: 'editor',
  },
  mockCategory: {
    name: 'Comunidad Hispana',
    slug: 'comunidad-hispana',
    order: 10,
    isVisible: true,
  } as Omit<Category, '_id'>,
  mockArticle: {
    title: 'Nueva iniciativa cultural en la diáspora',
    slug: 'nueva-iniciativa-cultural-diaspora',
    excerpt: 'Líderes comunitarios anuncian una nueva red cultural.',
    content: 'Contenido completo sobre la red comunitaria en el exterior...',
    categoryId: 'la-diaspora',
    authorId: 'author-1',
    status: 'published' as const,
    publishedAt: new Date().toISOString(),
    isMainHero: false,
    heroOrder: 2,
    showOnMostRead: true,
    mostReadOrder: 1,
  }
};
