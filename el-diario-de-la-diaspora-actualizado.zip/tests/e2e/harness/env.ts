import { NextRequest } from 'next/server';

export interface CookieAttributes {
  value: string;
  path?: string;
  maxAge?: number;
  expires?: Date;
  sameSite?: string;
}

export class MockCookieJar {
  private cookies: Map<string, CookieAttributes> = new Map();

  setCookieHeader(cookieStr: string) {
    if (!cookieStr) return;
    const parts = cookieStr.split(';').map(p => p.trim());
    const [nameVal] = parts;
    const eqIdx = nameVal.indexOf('=');
    if (eqIdx === -1) return;
    const key = nameVal.substring(0, eqIdx).trim();
    const value = nameVal.substring(eqIdx + 1).trim();

    const attrs: CookieAttributes = { value };

    for (let i = 1; i < parts.length; i++) {
      const part = parts[i];
      const lower = part.toLowerCase();
      if (lower.startsWith('path=')) {
        attrs.path = part.substring(5);
      } else if (lower.startsWith('max-age=')) {
        attrs.maxAge = parseInt(part.substring(8), 10);
      } else if (lower.startsWith('expires=')) {
        attrs.expires = new Date(part.substring(8));
      } else if (lower.startsWith('samesite=')) {
        attrs.sameSite = part.substring(9);
      }
    }

    // Check if expired
    if ((attrs.maxAge !== undefined && attrs.maxAge <= 0) ||
        (attrs.expires && attrs.expires.getTime() <= Date.now())) {
      this.cookies.delete(key);
    } else {
      this.cookies.set(key, attrs);
    }
  }

  getCookieString(): string {
    const list: string[] = [];
    for (const [k, v] of this.cookies.entries()) {
      list.push(`${k}=${v.value}`);
    }
    return list.join('; ');
  }

  get(name: string): string | undefined {
    return this.cookies.get(name)?.value;
  }

  getAttributes(name: string): CookieAttributes | undefined {
    return this.cookies.get(name);
  }

  has(name: string): boolean {
    return this.cookies.has(name);
  }

  clear() {
    this.cookies.clear();
  }

  getAll(): Record<string, string> {
    const res: Record<string, string> = {};
    for (const [k, v] of this.cookies.entries()) {
      res[k] = v.value;
    }
    return res;
  }
}

export class MockLocalStorage {
  private store: Map<string, string> = new Map();

  getItem(key: string): string | null {
    return this.store.has(key) ? this.store.get(key)! : null;
  }

  setItem(key: string, value: string): void {
    this.store.set(key, String(value));
  }

  removeItem(key: string): void {
    this.store.delete(key);
  }

  clear(): void {
    this.store.clear();
  }
}

export function setupMockBrowserEnv(initialCookies?: Record<string, string>) {
  const cookieJar = new MockCookieJar();
  const storage = new MockLocalStorage();

  if (initialCookies) {
    for (const [k, v] of Object.entries(initialCookies)) {
      cookieJar.setCookieHeader(`${k}=${v}; path=/`);
    }
  }

  const originalWindow = (globalThis as any).window;
  const originalDocument = (globalThis as any).document;
  const originalLocalStorage = (globalThis as any).localStorage;

  const mockDocument = {
    get cookie() {
      return cookieJar.getCookieString();
    },
    set cookie(val: string) {
      cookieJar.setCookieHeader(val);
    }
  };

  const mockWindow = {
    localStorage: storage,
    document: mockDocument,
    location: { href: 'http://localhost:3000' }
  };

  (globalThis as any).window = mockWindow;
  (globalThis as any).document = mockDocument;
  (globalThis as any).localStorage = storage;

  const cleanup = () => {
    (globalThis as any).window = originalWindow;
    (globalThis as any).document = originalDocument;
    (globalThis as any).localStorage = originalLocalStorage;
  };

  return { cookieJar, storage, cleanup };
}

export function createMockNextRequest(
  urlOrPath: string,
  options?: {
    cookies?: Record<string, string>;
    headers?: Record<string, string>;
  }
): NextRequest {
  const baseUrl = 'http://localhost:3000';
  const url = urlOrPath.startsWith('http') ? urlOrPath : `${baseUrl}${urlOrPath.startsWith('/') ? '' : '/'}${urlOrPath}`;
  
  const headers = new Headers(options?.headers || {});
  if (options?.cookies && Object.keys(options.cookies).length > 0) {
    const cookieHeaderVal = Object.entries(options.cookies)
      .map(([k, v]) => `${k}=${v}`)
      .join('; ');
    headers.set('cookie', cookieHeaderVal);
  }

  return new NextRequest(url, { headers });
}
