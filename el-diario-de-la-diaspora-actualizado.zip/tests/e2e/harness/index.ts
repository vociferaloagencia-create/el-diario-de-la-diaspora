export interface TestCase {
  name: string;
  tier: number;
  fn: () => Promise<void> | void;
}

export interface TestResult {
  name: string;
  tier: number;
  status: 'PASS' | 'FAIL';
  durationMs: number;
  error?: Error;
}

export class TestRunner {
  private tests: TestCase[] = [];

  register(tier: number, name: string, fn: () => Promise<void> | void) {
    this.tests.push({ tier, name, fn });
  }

  async run(filterTier?: number): Promise<{ results: TestResult[]; summary: { total: number; passed: number; failed: number } }> {
    const results: TestResult[] = [];
    const testsToRun = filterTier ? this.tests.filter(t => t.tier === filterTier) : this.tests;

    for (const test of testsToRun) {
      const start = Date.now();
      try {
        await test.fn();
        const durationMs = Date.now() - start;
        results.push({
          name: test.name,
          tier: test.tier,
          status: 'PASS',
          durationMs,
        });
        console.log(`  [PASS] [Tier ${test.tier}] ${test.name} (${durationMs}ms)`);
      } catch (err: any) {
        const durationMs = Date.now() - start;
        const error = err instanceof Error ? err : new Error(String(err));
        results.push({
          name: test.name,
          tier: test.tier,
          status: 'FAIL',
          durationMs,
          error,
        });
        console.log(`  [FAIL] [Tier ${test.tier}] ${test.name} (${durationMs}ms)`);
        console.log(`         Error: ${error.message}`);
      }
    }

    const passed = results.filter(r => r.status === 'PASS').length;
    const failed = results.filter(r => r.status === 'FAIL').length;
    return {
      results,
      summary: {
        total: results.length,
        passed,
        failed,
      }
    };
  }
}

// Global runner instance
export const runner = new TestRunner();

export function test(tier: number, name: string, fn: () => Promise<void> | void) {
  runner.register(tier, name, fn);
}

// Assertion library
export const assert = {
  equal<T>(actual: T, expected: T, msg?: string) {
    if (actual !== expected) {
      throw new Error(msg || `AssertionError: Expected ${JSON.stringify(expected)} but got ${JSON.stringify(actual)}`);
    }
  },

  notEqual<T>(actual: T, expected: T, msg?: string) {
    if (actual === expected) {
      throw new Error(msg || `AssertionError: Expected value NOT to equal ${JSON.stringify(expected)}`);
    }
  },

  ok(val: any, msg?: string) {
    if (!val) {
      throw new Error(msg || `AssertionError: Expected truthy value but got ${JSON.stringify(val)}`);
    }
  },

  includes(container: string | any[], item: any, msg?: string) {
    if (!container || !container.includes(item)) {
      throw new Error(msg || `AssertionError: Expected ${JSON.stringify(container)} to include ${JSON.stringify(item)}`);
    }
  },

  notIncludes(container: string | any[], item: any, msg?: string) {
    if (container && container.includes(item)) {
      throw new Error(msg || `AssertionError: Expected ${JSON.stringify(container)} NOT to include ${JSON.stringify(item)}`);
    }
  },

  match(str: string, regex: RegExp, msg?: string) {
    if (!regex.test(str)) {
      throw new Error(msg || `AssertionError: Expected "${str}" to match regex ${regex}`);
    }
  },

  async rejects(fn: () => Promise<any>, expectedErr?: string | RegExp, msg?: string) {
    let threw = false;
    let thrownErr: any = null;
    try {
      await fn();
    } catch (err: any) {
      threw = true;
      thrownErr = err;
    }
    if (!threw) {
      throw new Error(msg || 'AssertionError: Expected function to reject, but it resolved successfully');
    }
    if (expectedErr) {
      const errMsg = thrownErr?.message || String(thrownErr);
      if (typeof expectedErr === 'string' && !errMsg.includes(expectedErr)) {
        throw new Error(`AssertionError: Expected error message to include "${expectedErr}", got "${errMsg}"`);
      } else if (expectedErr instanceof RegExp && !expectedErr.test(errMsg)) {
        throw new Error(`AssertionError: Expected error message to match ${expectedErr}, got "${errMsg}"`);
      }
    }
  }
};
