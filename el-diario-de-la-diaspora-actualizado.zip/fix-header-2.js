const fs = require('fs');
let code = fs.readFileSync('src/components/site/Header.tsx', 'utf8');

code = code.replace(/Repblica/g, 'República');
code = code.replace(/Mxico/g, 'México');
code = code.replace(/Canad/g, 'Canadá');
code = code.replace(/Espaa/g, 'España');
code = code.replace(/Opinin/g, 'Opinión');
code = code.replace(/\+'/g, '→');

fs.writeFileSync('src/components/site/Header.tsx', code, 'utf8');
console.log('Fixed Header.tsx explicitly');
