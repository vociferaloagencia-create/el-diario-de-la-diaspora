const fs = require('fs');

function fixGenericEncoding(filePath) {
  let code = fs.readFileSync(filePath, 'utf8');
  
  // Dashboard and generic issues
  code = code.replace(/categorA-as/g, 'categorías');
  code = code.replace(/categorAa/g, 'categoría');
  code = code.replace(/artAculos/g, 'artículos');
  code = code.replace(/artA-culo/g, 'artículo');
  code = code.replace(/InformaciA3n/g, 'Información');
  code = code.replace(/EliminaciA3n/g, 'Eliminación');
  code = code.replace(/ActualizaciA3n/g, 'Actualización');
  code = code.replace(/configuraciA3n/g, 'configuración');
  code = code.replace(/CreaciA3n/g, 'Creación');
  
  // Header hidden issues
  code = code.replace(/visiA3n/g, 'visión');
  code = code.replace(/indicA3/g, 'indicó');
  code = code.replace(/AcordeA3n/g, 'Acordeón');
  code = code.replace(/paA-ses/g, 'países');
  code = code.replace(/SubmenA/g, 'Submenú');
  code = code.replace(/MenA/g, 'Menú');
  code = code.replace(/LA\?NEA/g, 'LÍNEA');

  fs.writeFileSync(filePath, code, 'utf8');
}

fixGenericEncoding('src/components/site/Header.tsx');
fixGenericEncoding('src/lib/firestore.ts');
fixGenericEncoding('src/app/dashboard/categories/page.tsx');
console.log('Fixed additional encoding issues');
