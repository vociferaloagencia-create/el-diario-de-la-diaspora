const fs = require('fs');
let code = fs.readFileSync('src/app/login/page.tsx', 'utf8');

// 1. Remove handleQuickAdminLogin function
const funcStart = code.indexOf('async function handleQuickAdminLogin() {');
const funcEnd = code.indexOf('async function onLoginSubmit');
if (funcStart !== -1 && funcEnd !== -1) {
    code = code.substring(0, funcStart) + code.substring(funcEnd);
}

// 2. Remove the button
const buttonRegex = /<Button\s+type="button"\s+variant="outline"\s+className="[^"]+"\s+onClick=\{handleQuickAdminLogin\}[^>]*>\s*Acceso Rápido Administrador\s*<\/Button>/g;
code = code.replace(buttonRegex, '');

fs.writeFileSync('src/app/login/page.tsx', code, 'utf8');
console.log('Successfully removed backdoor button and function.');
