const fs = require('fs');

function fixEncoding(filePath) {
  let code = fs.readFileSync(filePath, 'utf8');
  
  // Clean up literal \n\n bug
  code = code.replace(/\\n\\n/g, '');
  code = code.replace(/<\/div>\s*\{\/\* Centro: LOGO OFICIAL AMPLIO, DESTACADO Y GRUESO \*\/\}/g, '</div>\n\n          {/* Centro: LOGO OFICIAL AMPLIO, DESTACADO Y GRUESO */}'); // Restore the actual newline
  
  // Accents and weird characters
  code = code.replace(/DiÃ¡spora/g, 'Diáspora');
  code = code.replace(/DiÃ.spora/g, 'Diáspora');
  
  code = code.replace(/EconomÃ.a/g, 'Economía');
  code = code.replace(/EconomÃa/g, 'Economía');
  
  code = code.replace(/OpiniÃ³n/g, 'Opinión');
  
  code = code.replace(/RepÃºblica/g, 'República');
  
  code = code.replace(/MÃ©xico/g, 'México');
  
  code = code.replace(/EspaÃ±a/g, 'España');
  
  code = code.replace(/CanadÃ¡/g, 'Canadá');
  
  code = code.replace(/SUSCRÃ.BETE/g, 'SUSCRÍBETE');
  code = code.replace(/SUSCRIBETE/g, 'SUSCRÍBETE');
  
  code = code.replace(/EdiciÃ³n/g, 'Edición');
  code = code.replace(/Ãšltima/g, 'Última');
  code = code.replace(/Ã.ltima/g, 'Última');
  code = code.replace(/Ã.LTIMA/g, 'ÚLTIMA');
  code = code.replace(/CategorÃ.as/g, 'Categorías');
  code = code.replace(/EstadÃ.sticas/g, 'Estadísticas');
  code = code.replace(/ArtÃ.culos/g, 'Artículos');
  code = code.replace(/NavegaciÃ³n/g, 'Navegación');
  code = code.replace(/PeriÃ³dico/g, 'Periódico');
  code = code.replace(/VisiÃ³n/g, 'Visión');
  
  fs.writeFileSync(filePath, code, 'utf8');
  console.log('Fixed ' + filePath);
}

fixEncoding('src/components/site/Header.tsx');
fixEncoding('src/lib/firestore.ts');
