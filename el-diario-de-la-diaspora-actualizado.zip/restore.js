const fs = require('fs');
let code = fs.readFileSync('src/components/site/Header.tsx', 'utf8');

// Restore Language imports
code = code.replace(
  'import { TranslatedCategoryName }',
  'import { LanguageTranslator, setPageLanguage } from "./LanguageTranslator";\nimport { TranslatedCategoryName }'
);

// Restore <LanguageTranslator />
code = code.replace(
  '<BrowserNotificationPrompt />',
  '<LanguageTranslator />\n      <BrowserNotificationPrompt />'
);

// Restore Desktop language buttons
const desktopTarget = /\{\/\* Derecha: Buscar \+ Boton SUSCRIBETE \+ Perfil \*\/\}[\s\n]*<div className="flex items-center justify-end gap-2 sm:gap-3 flex-1">/;
const desktopReplacement = `{/* Derecha: Selector 4 Idiomas + Buscar + Boton SUSCRIBETE + Perfil */}
          <div className="flex items-center justify-end gap-2 sm:gap-3 flex-1">
            
            {/* SELECTOR DE IDIOMA */}
            <div className="hidden lg:flex items-center bg-slate-100 dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-lg p-0.5 mr-2">
              {(['ES', 'FR', 'EN', 'AR'] as const).map((lang) => (
                <button
                  key={lang}
                  type="button"
                  onClick={() => handleLanguageChange(lang)}
                  className={\`notranslate px-1.5 py-0.5 text-[10px] font-extrabold uppercase rounded transition-all \${
                    currentLang === lang
                      ? 'bg-primary text-white shadow-sm font-black'
                      : 'text-slate-600 dark:text-slate-400 hover:text-primary dark:hover:text-white'
                  }\`}
                  title={\`Cambiar idioma a \${lang}\`}
                >
                  {lang}
                </button>
              ))}
            </div>`;
code = code.replace(desktopTarget, desktopReplacement);

// Restore Mobile language buttons
const mobileTarget = /<div className="flex-1 overflow-y-auto px-5 py-4 space-y-5">[\s\n]*<div>[\s\n]*<h3 className="text-xs font-extrabold uppercase tracking-widest text-primary mb-2.5 flex items-center gap-1.5">/;
const mobileReplacement = `<div className="flex-1 overflow-y-auto px-5 py-4 space-y-5">
                  {/* Selector de Idioma Movil */}
                  <div className="flex items-center justify-between p-2.5 bg-slate-100 dark:bg-slate-900 rounded-lg mb-1 border border-slate-200/80 dark:border-slate-800">
                    <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 font-headline uppercase flex items-center gap-1.5">
                      <Globe className="w-3.5 h-3.5 text-primary" />
                      Idioma / Language:
                    </span>
                    <div className="flex items-center bg-white dark:bg-slate-950 border border-slate-200/90 dark:border-slate-800 rounded-md p-0.5">
                      {(['ES', 'FR', 'EN', 'AR'] as const).map((lang) => (
                        <button
                          key={lang}
                          type="button"
                          onClick={() => {
                            handleLanguageChange(lang);
                            setIsSheetOpen(false);
                          }}
                          className={\`notranslate px-2 py-1 text-[11px] font-extrabold uppercase rounded transition-all \${
                            currentLang === lang
                              ? 'bg-primary text-white shadow-xs font-black'
                              : 'text-slate-600 dark:text-slate-400 hover:text-primary'
                          }\`}
                        >
                          {lang}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-xs font-extrabold uppercase tracking-widest text-primary mb-2.5 flex items-center gap-1.5">`;
code = code.replace(mobileTarget, mobileReplacement);

fs.writeFileSync('src/components/site/Header.tsx', code, 'utf8');
console.log('Restored Header.tsx buttons');
