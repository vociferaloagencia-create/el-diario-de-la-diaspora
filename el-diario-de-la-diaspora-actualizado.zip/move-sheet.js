const fs = require('fs');
let code = fs.readFileSync('src/components/site/Header.tsx', 'utf8');

// Extract the whole Sheet block
const sheetRegex = /<Sheet open=\{isSheetOpen\} onOpenChange=\{setIsSheetOpen\}>[\s\S]*?<\/Sheet>/;
const sheetMatch = code.match(sheetRegex);

if (sheetMatch) {
  const sheetCode = sheetMatch[0];
  
  // Remove from right column
  code = code.replace(sheetRegex, '');
  
  // Insert into left column
  const leftColumnRegex = /\{\/\* Izquierda: Fecha formal y EdiciÃ³n Digital \*\/\}[\s\n]*<div className="hidden lg:flex items-center gap-2 text-slate-500 dark:text-slate-400 font-headline flex-1">/;
  const leftColumnReplacement = `{/* Izquierda: Menu Movil + Fecha formal */}
          <div className="flex items-center gap-2 lg:gap-4 flex-1">
            ${sheetCode}
            <div className="hidden lg:flex items-center gap-2 text-slate-500 dark:text-slate-400 font-headline">`;
  
  code = code.replace(leftColumnRegex, leftColumnReplacement);
  // Also we need to fix the closing div of the old left column.
  // The old left column was a single div. Now we wrapped it in a flex container. So we need to add a closing div.
  // Wait, let's just replace the exact left column block.
  
  const exactLeftBlock = `{/* Izquierda: Fecha formal y EdiciÃ³n Digital */}
          <div className="hidden lg:flex items-center gap-2 text-slate-500 dark:text-slate-400 font-headline flex-1">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[11px] font-bold uppercase tracking-wider">
              {dateStr}
            </span>
            <span className="text-slate-300 dark:text-slate-700">|</span>
            <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
              EdiciÃ³n Digital
            </span>
          </div>`;

  const newLeftBlock = `{/* Izquierda: Menu Movil + Fecha formal */}
          <div className="flex items-center gap-2 flex-1">
            ${sheetCode}
            <div className="hidden lg:flex items-center gap-2 text-slate-500 dark:text-slate-400 font-headline">
              <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[11px] font-bold uppercase tracking-wider">
                {dateStr}
              </span>
              <span className="text-slate-300 dark:text-slate-700">|</span>
              <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                EdiciÃ³n Digital
              </span>
            </div>
          </div>`;

  // Actually, wait, the file has a specific UTF-8 encoding. I should use a more forgiving regex.
  const regexLeft = /\{\/\* Izquierda:[^\n]*[\s\n]*<div className="hidden lg:flex items-center gap-2 text-slate-500 dark:text-slate-400 font-headline flex-1">[\s\S]*?Edici[^\n]*\s*<\/span>\s*<\/div>/;
  
  code = code.replace(regexLeft, (match) => {
     // replace 'flex-1' in the inner div to avoid double flex-1
     let inner = match.replace('flex-1', '');
     return `<div className="flex items-center gap-2 flex-1">\n${sheetCode}\n${inner}\n</div>`;
  });

  fs.writeFileSync('src/components/site/Header.tsx', code, 'utf8');
  console.log('Moved sheet to left');
} else {
  console.log('Sheet not found');
}
