const fs = require('fs');
let code = fs.readFileSync('src/app/category/[slug]/page.tsx', 'utf8');

const filterBlock = `  // Filtrado por país en La Diáspora si se especifica
  if (slug === 'la-diaspora' && selectedCountry && selectedCountry !== 'Todas') {
    let term = selectedCountry.toLowerCase();
    if (term === 'república de chile') {
        term = 'chile';
    }
    const filtered = allArticles.filter(a => 
      a.title?.toLowerCase().includes(term) ||
      a.summary?.toLowerCase().includes(term) ||
      a.tags?.some(t => t.toLowerCase().includes(term))
    );
    if (filtered.length > 0) {
      allArticles = filtered;
    }
  }`;

// I will just use block replacement
const oldBlockMatch = code.match(/\/\/ Filtrado por país en La Diáspora si se especifica\s+if \(slug === 'la-diaspora' && selectedCountry && selectedCountry !== 'Todas'\) \{[\s\S]*?if \(filtered\.length > 0\) \{\s+allArticles = filtered;\s+\}\s+\}/);

if (oldBlockMatch) {
    code = code.replace(oldBlockMatch[0], filterBlock);
    fs.writeFileSync('src/app/category/[slug]/page.tsx', code, 'utf8');
    console.log('Fixed category page term logic');
} else {
    console.log('Could not find old block match');
}
