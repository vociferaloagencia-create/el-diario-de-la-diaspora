const { execSync } = require('child_process');

const envs = {
  'NEXT_PUBLIC_FIREBASE_API_KEY': 'AIzaSyBVbDSMJmqG2-ULAtxROw-1tM6TSOvN5Ho',
  'NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN': 'el-diario-de-la-diaspora.firebaseapp.com',
  'NEXT_PUBLIC_FIREBASE_PROJECT_ID': 'el-diario-de-la-diaspora',
  'NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET': 'el-diario-de-la-diaspora.firebasestorage.app',
  'NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID': '941690277108',
  'NEXT_PUBLIC_FIREBASE_APP_ID': '1:941690277108:web:cf45e4a4456dff389da2a1'
};

for (const [key, value] of Object.entries(envs)) {
    console.log(`Adding ${key}...`);
    try {
        execSync(`echo | set /p="${value}" | vercel env add ${key} production --type config`, { stdio: 'inherit' });
    } catch (e) {
        console.error(`Failed to add ${key}`);
    }
}
