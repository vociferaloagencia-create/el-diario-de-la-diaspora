const fs = require('fs');
let content = fs.readFileSync('src/components/site/AuthArea.tsx', 'utf8');
content = content.replace(/Acceder a tu cuenta/g, 'Iniciar Sesión');
content = content.replace(/aria-label="Acceder"/g, 'aria-label="Iniciar Sesión"');
content = content.replace(/>Acceder</g, '>Iniciar Sesión<');
content = content.replace(/href="\/login\?tab=login"/g, 'href="/login"');
fs.writeFileSync('src/components/site/AuthArea.tsx', content);
