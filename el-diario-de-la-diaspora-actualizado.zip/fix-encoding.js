const fs = require('fs');

function fixEncoding(filePath) {
  let code = fs.readFileSync(filePath, 'utf8');
  
  code = code.replace(/DiA.spora/g, 'Diáspora');
  code = code.replace(/EdiciA3n/g, 'Edición');
  code = code.replace(/EconomA.a/g, 'Economía');
  code = code.replace(/OpiniA3n/g, 'Opinión');
  code = code.replace(/paA.ses/g, 'países');
  code = code.replace(/SUSCRA.BETE/g, 'SUSCRÍBETE');
  code = code.replace(/CategorA.as/g, 'Categorías');
  code = code.replace(/EstadA.sticas/g, 'Estadísticas');
  code = code.replace(/ArtA.culos/g, 'Artículos');
  code = code.replace(/NavegaciA3n/g, 'Navegación');
  code = code.replace(/PeriA3dico/g, 'Periódico');
  code = code.replace(/VisiA3n/g, 'Visión');
  code = code.replace(/A.ltima/g, 'Última');
  code = code.replace(/A.LTIMA/g, 'ÚLTIMA');
  code = code.replace(/SecciA3n/g, 'Sección');
  
  fs.writeFileSync(filePath, code, 'utf8');
  console.log('Fixed encoding in ' + filePath);
}

fixEncoding('src/components/site/Header.tsx');
fixEncoding('src/lib/firestore.ts');
fixEncoding('src/app/dashboard/layout.tsx');
