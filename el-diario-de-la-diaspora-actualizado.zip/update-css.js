const fs = require('fs');
let code = fs.readFileSync('src/app/globals.css', 'utf8');

const newCSS = `
/* Universal Language Overrides for GTranslate */
html:not([lang="fr"]) .lang-fr-only { display: none !important; }
html:not([lang="en"]) .lang-en-only { display: none !important; }
html[lang="fr"] .hide-on-fr { display: none !important; }
html[lang="en"] .hide-on-en { display: none !important; }
`;

code = code.replace('/* French Google Translate specific word overrides */', newCSS + '\n/* Legacy French Overrides */');

fs.writeFileSync('src/app/globals.css', code, 'utf8');
console.log('globals.css updated');
