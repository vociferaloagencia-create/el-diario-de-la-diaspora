const fs = require('fs');
let code = fs.readFileSync('src/components/site/Header.tsx', 'utf8');

const target = `{/* Navegaci`;
const fullTargetPattern = /\{\/\* Navegaci[^]*? de Categor[^]*? \*\/\}/;

const replacement = `</div>
        </div>
      </div>

      {/* 2. SECOND ROW Navigation */}
      <div className="bg-primary w-full shadow-sm">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          {/* Navegacion horizontal de Categorias */}`;

code = code.replace(fullTargetPattern, replacement);
fs.writeFileSync('src/components/site/Header.tsx', code, 'utf8');
console.log('Fixed div matching');
