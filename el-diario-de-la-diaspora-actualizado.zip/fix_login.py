import re

with open('src/app/login/page.tsx', 'r', encoding='utf-8') as f:
    content = f.read()

# Remove the 'register' activeTab state
content = re.sub(r"const initialTab = [^;]+;\n  const \[activeTab, setActiveTab\] = useState\<'login' \| 'register'\>\(initialTab\);\n", "", content)

# Remove the signUpSchema entirely
content = re.sub(r"const signUpSchema = z\.object\(\{.*?\}\)\.refine\(.*?\}\);\n\n", "", content, flags=re.DOTALL)

# Remove the signUpForm entirely
content = re.sub(r"  const signUpForm = useForm\<z\.infer\<typeof signUpSchema\>\>\(\{.*?\}\);\n\n", "", content, flags=re.DOTALL)

# Remove the onSignUpSubmit entirely
content = re.sub(r"  async function onSignUpSubmit\(values: z\.infer\<typeof signUpSchema\>\) \{.*?\}\n\n", "", content, flags=re.DOTALL)

# Replace the JSX inside <CardContent> with a simplified version
simplified_jsx = '''<div className="space-y-6 mt-4">
            <Form {...loginForm}>
              <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                <FormField
                  control={loginForm.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">Correo Electrónico</FormLabel>
                      <FormControl>
                        <Input type="email" placeholder="tu@email.com" {...field} className="h-11 text-sm bg-slate-50 dark:bg-slate-900/50" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={loginForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <div className="flex items-center justify-between">
                        <FormLabel className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">Contraseña</FormLabel>
                        <Link href="/forgot-password" className="text-xs font-semibold text-primary hover:underline">
                          ¿Olvidaste tu contraseña?
                        </Link>
                      </div>
                      <FormControl>
                        <PasswordInput placeholder="••••••••" {...field} className="h-11 text-sm bg-slate-50 dark:bg-slate-900/50" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={loginForm.control}
                  name="rememberMe"
                  render={({ field }) => (
                    <FormItem className="flex items-center space-x-2 space-y-0 pt-1">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <FormLabel className="text-xs font-medium text-slate-600 dark:text-slate-300 cursor-pointer">
                        Recordarme en este dispositivo
                      </FormLabel>
                    </FormItem>
                  )}
                />

                <Button type="submit" className="w-full font-bold h-11 bg-primary hover:bg-primary/90 text-white uppercase tracking-wider text-sm mt-2" disabled={isSubmitting}>
                  {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Iniciar Sesión
                </Button>
              </form>
            </Form>

            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-slate-200 dark:border-slate-800" />
              </div>
              <div className="relative flex justify-center text-xs uppercase tracking-wider font-semibold">
                <span className="bg-card px-3 text-slate-500">O Ingresa Rápido</span>
              </div>
            </div>

            <div className="flex flex-col gap-3">
              <Button
                type="button"
                variant="outline"
                className="w-full font-semibold border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-900 h-11 text-sm shadow-sm"
                onClick={handleGoogleLogin}
                disabled={isSubmitting || isGoogleSubmitting}
              >
                {isGoogleSubmitting ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
                    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
                  </svg>
                )}
                Acceder con Google
              </Button>
            </div>
          </div>
'''

content = re.sub(r"<Tabs defaultValue=\{activeTab\}.*?</Tabs>", simplified_jsx, content, flags=re.DOTALL)
content = content.replace("import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';", "")
content = content.replace("UserPlus, ", "")
content = content.replace("signUp, ", "")

with open('src/app/login/page.tsx', 'w', encoding='utf-8') as f:
    f.write(content)
