const fs = require('fs');
let code = fs.readFileSync('src/components/site/Header.tsx', 'utf8');

code = code.replace(/\{ name: 'República de Chile', slug: 'chile' \}/g, "{ name: 'República de Chile', slug: 'República de Chile' }");

fs.writeFileSync('src/components/site/Header.tsx', code, 'utf8');
console.log('Fixed Header chile slug');
