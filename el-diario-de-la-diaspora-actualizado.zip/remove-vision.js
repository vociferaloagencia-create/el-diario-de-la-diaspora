const fs = require('fs');
let code = fs.readFileSync('src/components/site/Header.tsx', 'utf8');

const target = `                  <Link
                    href="/category/la-diaspora"
                    onClick={() => setIsSheetOpen(false)}
                    className="block text-xs font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-300 hover:text-primary py-1"
                  >
                    Visión
                  </Link>`;

if (code.includes(target)) {
  code = code.replace(target, '');
  fs.writeFileSync('src/components/site/Header.tsx', code, 'utf8');
  console.log('Successfully removed Visión');
} else {
  console.log('Target not found, checking alternatives...');
  // Fallback regex if spacing differs
  const regex = /<Link[^>]*href="\/category\/la-diaspora"[^>]*>\s*Visión\s*<\/Link>/;
  if (regex.test(code)) {
    code = code.replace(regex, '');
    fs.writeFileSync('src/components/site/Header.tsx', code, 'utf8');
    console.log('Removed Visión via regex');
  } else {
    console.log('Could not find Visión at all!');
  }
}
