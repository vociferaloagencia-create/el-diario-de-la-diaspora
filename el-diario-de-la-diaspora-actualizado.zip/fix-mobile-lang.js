const fs = require('fs');
let code = fs.readFileSync('src/components/site/Header.tsx', 'utf8');

code = code.replace(
  '<div className="hidden lg:flex items-center bg-slate-100 dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-lg p-0.5 mr-2">',
  '<div className="flex items-center bg-slate-100 dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-lg p-0.5 mr-1 sm:mr-2">'
);

fs.writeFileSync('src/components/site/Header.tsx', code, 'utf8');
console.log('Fixed Language Buttons Visibility');
