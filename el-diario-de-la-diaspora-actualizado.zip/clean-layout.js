const fs = require('fs');
let code = fs.readFileSync('src/app/layout.tsx', 'utf8');

const regex = /\{\/\* GTranslate Plugin Widget \*\/\}[\s\n]*<div className="gtranslate_wrapper"><\/div>[\s\n]*<script dangerouslySetInnerHTML=\{\{[\s\n]*__html: `window\.gtranslateSettings.*`[\s\n]*\}\} \/>[\s\n]*<script src="https:\/\/cdn\.gtranslate\.net\/widgets\/latest\/float\.js" defer><\/script>/g;

code = code.replace(regex, '');
fs.writeFileSync('src/app/layout.tsx', code, 'utf8');
console.log('Cleaned layout.tsx');
