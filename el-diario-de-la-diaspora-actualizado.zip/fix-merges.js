const fs = require('fs');
let code = fs.readFileSync('src/lib/firestore.ts', 'utf8');

// 1. getCategories
code = code.replace(
  "return docs.length > 0 ? docs : defaultCategories;",
  "const dbIds = new Set(docs.map(c => c._id));\n    const remainingDefaults = defaultCategories.filter(c => !dbIds.has(c._id));\n    return [...docs, ...remainingDefaults].sort((a,b) => a.order - b.order);"
);

// 2. getHeroArticles
code = code.replace(
  "return filtered.length > 0 ? filtered : defaultArticles.filter(a => a.isMainHero);",
  "const dbIds = new Set(filtered.map(a => a._id));\n    const remainingDefaults = defaultArticles.filter(a => a.isMainHero && !dbIds.has(a._id));\n    return [...filtered, ...remainingDefaults];"
);

// 3. getMostReadArticles
code = code.replace(
  "return filtered.length > 0 ? filtered : defaultArticles.filter(a => a.showOnMostRead).slice(0, 4);",
  "const dbIds = new Set(filtered.map(a => a._id));\n    const remainingDefaults = defaultArticles.filter(a => a.showOnMostRead && !dbIds.has(a._id));\n    return [...filtered, ...remainingDefaults].slice(0, 4);"
);

// 4. getLatestArticles
code = code.replace(
  "return filtered.length > 0 ? filtered : defaultArticles.slice(0, limitCount);",
  "const dbIds = new Set(filtered.map(a => a._id));\n    const remainingDefaults = defaultArticles.filter(a => !dbIds.has(a._id));\n    return [...filtered, ...remainingDefaults].slice(0, limitCount);"
);

// 5. getReels
code = code.replace(
  "return reels.length > 0 ? reels : defaultReels;",
  "const dbIds = new Set(reels.map(r => r._id));\n    const remainingDefaults = defaultReels.filter(r => !dbIds.has(r._id));\n    return [...reels, ...remainingDefaults];"
);

fs.writeFileSync('src/lib/firestore.ts', code, 'utf8');
console.log('Fixed all data mergers in firestore.ts');
