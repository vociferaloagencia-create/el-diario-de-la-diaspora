const fs = require('fs');
let code = fs.readFileSync('src/components/site/Header.tsx', 'utf8');

const oldArrayMatch = code.match(/const DIASPORA_COUNTRIES = \[.*?\];/s);
if (oldArrayMatch) {
  const newArray = `const DIASPORA_COUNTRIES = [
  { name: 'República Dominicana', slug: 'republica-dominicana' },
  { name: 'México', slug: 'mexico' },
  { name: 'Brasil', slug: 'brasil' },
  { name: 'Chile', slug: 'chile' },
  { name: 'Cuba', slug: 'cuba' },
  { name: 'Bahamas', slug: 'bahamas' },
  { name: 'Venezuela', slug: 'venezuela' },
  { name: 'EE.UU.', slug: 'eeuu' },
  { name: 'Canadá', slug: 'canada' },
  { name: 'Francia', slug: 'francia' },
  { name: 'España', slug: 'espana' },
  { name: 'Argentina', slug: 'argentina' },
  { name: 'Guayana Francesa', slug: 'guayana-francesa' },
  { name: 'Suiza', slug: 'suiza' },
];`;
  code = code.replace(oldArrayMatch[0], newArray);
}

const oldOpinion = code.match(/\{ _id: 'opinion', name: 'Editorial \/ Opini[^']*', slug: 'opinion', order: 8, isVisible: true \},/);
if (oldOpinion) {
  code = code.replace(oldOpinion[0], `{ _id: 'opinion', name: 'Editorial / Opinión', slug: 'opinion', order: 8, isVisible: true },`);
}

const oldPaisesLabel = code.match(/PaA-ses de la Di[^s]*spora:/);
if (oldPaisesLabel) {
  code = code.replace(oldPaisesLabel[0], `Países de la Diáspora:`);
}

fs.writeFileSync('src/components/site/Header.tsx', code, 'utf8');
console.log('Fixed Header.tsx completely');
