const fs = require('fs');
let code = fs.readFileSync('src/lib/auth.ts', 'utf8');

// Replace all instances of `isExplicitAdmin` assigning 'admin' role to assigning 'superadmin' role.
code = code.replace(/isExplicitAdmin \? 'admin' : 'user'/g, "isExplicitAdmin ? 'superadmin' : 'user'");

// Remove the demotion block entirely:
/*
        if (!isExplicitAdmin && data.role === 'admin') {
          await withTimeout(updateDoc(userRef, { role: 'user' }), 1800);
          assignedRole = 'user';
        } else if (data.role) {
          assignedRole = data.role;
        }
*/
const blockToReplace = `        if (!isExplicitAdmin && data.role === 'admin') {
          await withTimeout(updateDoc(userRef, { role: 'user' }), 1800);
          assignedRole = 'user';
        } else if (data.role) {
          assignedRole = data.role;
        }`;
const replacementBlock = `        if (data.role) {
          assignedRole = data.role;
        }`;

code = code.replace(blockToReplace, replacementBlock);

fs.writeFileSync('src/lib/auth.ts', code, 'utf8');
console.log('Successfully updated auth.ts to grant superadmin and removed demotion trap');
