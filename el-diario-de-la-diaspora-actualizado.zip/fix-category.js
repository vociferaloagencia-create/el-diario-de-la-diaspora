const fs = require('fs');
let code = fs.readFileSync('src/app/category/[slug]/page.tsx', 'utf8');

const oldArrayMatch = code.match(/const DIASPORA_COUNTRIES = \[.*?\];/s);
if (oldArrayMatch) {
  const newArray = `const DIASPORA_COUNTRIES = [
  'Todas',
  'República Dominicana',
  'México',
  'Brasil',
  'Chile',
  'Cuba',
  'Bahamas',
  'Venezuela',
  'EE.UU.',
  'Canadá',
  'Francia',
  'España',
  'Argentina',
  'Guayana Francesa',
  'Suiza'
];`;
  code = code.replace(oldArrayMatch[0], newArray);
}

// Change overflow-x-auto to flex-wrap
code = code.replace('className="flex items-center gap-1.5 overflow-x-auto no-scrollbar scroll-smooth py-1"', 'className="flex items-center gap-1.5 flex-wrap py-1"');

// Add translate="no" to the country names so they don't break in Google Translate
code = code.replace(/>\s*\{country\}\s*<\/Link>/g, ' translate="no">\n                            {country}\n                          </Link>');

fs.writeFileSync('src/app/category/[slug]/page.tsx', code, 'utf8');
console.log('Fixed category page');
