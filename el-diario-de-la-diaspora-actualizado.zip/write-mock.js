const fs = require('fs');

const mockDataContent = `import type { Article, Reel, Author } from './types';

export const defaultAuthors: Author[] = [
  {
    _id: 'redaccion-diaspora',
    name: 'Redacción Diáspora',
    slug: 'redaccion-diaspora',
    bio: 'Equipo editorial especializado en noticias internacionales y comunidades hispanas.',
    avatarUrl: '/images/hero_summit.jpg',
    role: 'Editorial',
    socialLinks: {
      twitter: 'https://twitter.com',
      website: 'https://eldiariodeladiaspora.com',
    },
  },
];

export const defaultReels: Reel[] = [
  {
    _id: 'reel-1',
    title: 'Resumen de la Cumbre Internacional de la Diáspora en 60 segundos',
    url: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    createdAt: '2026-09-03T12:00:00Z',
  },
  {
    _id: 'reel-2',
    title: 'Así funciona el nuevo pasaporte biométrico dominicano',
    url: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    createdAt: '2026-09-03T11:00:00Z',
  },
  {
    _id: 'reel-3',
    title: 'Lo mejor del Festival de Culturas de la Diáspora',
    url: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    createdAt: '2026-09-03T10:00:00Z',
  },
];

export const defaultArticles: Article[] = [
  {
    _id: 'cumbre-iberoamericana-diaspora-2026',
    title: 'Cumbre Internacional de la Diáspora: Líderes globales aprueban histórico pacto de integración y derechos migratorios',
    slug: 'cumbre-iberoamericana-diaspora-2026',
    summary: 'Delegaciones de más de 25 naciones firman en Madrid un acuerdo sin precedentes para agilizar la homologación de títulos, facilitar la inversión productiva de remesas y proteger a los trabajadores en el exterior.',
    content: '<p>En una jornada calificada como histórica por analistas y diplomáticos, mandatarios y representantes de las principales comunidades en el exterior cerraron hoy la Cumbre Internacional de la Diáspora con la firma del Tratado Global de Movilidad y Protección Migratoria.</p><p>El documento ratifica compromisos multilaterales para reducir sustancialmente los costes de envío de remesas, blindar los derechos laborales de los trabajadores migrantes e instaurar ventanillas únicas de homologación universitaria, lo cual beneficiará a millones de profesionales a nivel global.</p><h2>Un Acuerdo Sin Precedentes</h2><p>La delegación subrayó la importancia de dejar atrás las trabas burocráticas que durante décadas han frenado el desarrollo de los profesionales en el extranjero. "Nuestra meta no es solo proteger, sino potenciar el talento que nuestra gente aporta a los países de acogida", declaró el portavoz principal de la cumbre.</p><p>Además de los temas económicos, se abordaron políticas de inclusión cultural y educación bilingüe para las segundas y terceras generaciones de emigrantes, asegurando que las raíces culturales no se pierdan con la asimilación.</p><h2>Próximos Pasos</h2><p>Los estados miembros tienen ahora un plazo de 12 meses para ratificar estos acuerdos en sus respectivos parlamentos nacionales. Se espera que los primeros efectos reales de este tratado se empiecen a notar en los procesos migratorios a partir de mediados de 2027.</p>',
    categoryId: 'la-diaspora',
    subCategoryId: null,
    authorId: 'redaccion-diaspora',
    heroImageUrl: '/images/hero_summit.jpg',
    thumbnailUrl: '/images/hero_summit.jpg',
    publishedAt: '2026-09-04T10:00:00Z',
    status: 'published',
    isMainHero: true,
    heroOrder: 1,
    showOnMostRead: true,
    mostReadOrder: 1,
    tags: ['diaspora', 'internacional', 'cumbre']
  },
  {
    _id: 'remesas-alcanzan-cifras-record-2026',
    title: 'Las remesas alcanzan cifras récord en el primer semestre: Un impulso vital para la economía nacional',
    slug: 'remesas-alcanzan-cifras-record-2026',
    summary: 'El Banco Central reporta un incremento del 14% en la entrada de divisas, impulsado por la digitalización de los servicios de envío y la reactivación económica en Estados Unidos y Europa.',
    content: '<p>El flujo de remesas hacia los países de origen ha superado todas las expectativas durante la primera mitad del año, registrando un aumento del 14% en comparación con el mismo período del año anterior, según los últimos datos publicados por el Banco Central.</p><p>Este crecimiento exponencial se atribuye a dos factores principales: la sólida recuperación del mercado laboral en Estados Unidos y la adopción masiva de plataformas digitales que han reducido significativamente las comisiones de transferencia.</p><h2>Impacto en los Hogares</h2><p>Para muchas familias, este aumento representa un alivio directo frente a la inflación global. Los fondos no solo se están destinando al consumo básico, sino que se observa una tendencia al alza en la inversión en pequeños negocios y educación.</p><p>"Nuestra comunidad en el exterior sigue demostrando un compromiso inquebrantable con el desarrollo de nuestro país. Cada divisa enviada es un bloque más en la construcción de una economía resiliente", señaló el Ministro de Economía durante una rueda de prensa matutina.</p><h2>Perspectivas para Fin de Año</h2><p>Los analistas financieros proyectan que, de mantenerse esta tendencia, el año cerrará con un superávit histórico en la balanza de pagos. Sin embargo, advierten sobre la necesidad de crear instrumentos financieros que permitan canalizar una mayor porción de estos fondos hacia proyectos de infraestructura y ahorro a largo plazo.</p>',
    categoryId: 'economia',
    subCategoryId: null,
    authorId: 'redaccion-diaspora',
    heroImageUrl: '/images/economia_remesas.jpg',
    thumbnailUrl: '/images/economia_remesas.jpg',
    publishedAt: '2026-09-03T15:30:00Z',
    status: 'published',
    isMainHero: false,
    showOnMostRead: true,
    mostReadOrder: 2,
    tags: ['economia', 'remesas']
  },
  {
    _id: 'festival-cultural-madrid',
    title: 'El Gran Festival de la Hispanidad en Madrid reunió a más de 500,000 asistentes de toda la diáspora',
    slug: 'festival-cultural-madrid',
    summary: 'Música, gastronomía y arte se dieron cita en una celebración multitudinaria que destacó la riqueza y diversidad de la comunidad hispana en el corazón de Europa.',
    content: '<p>Las calles de Madrid se llenaron de color, ritmo y sabor este fin de semana durante la celebración del Gran Festival de la Hispanidad. Con una asistencia estimada en más de medio millón de personas, el evento se consolida como el encuentro cultural más importante de la diáspora en Europa.</p><h2>Un Despliegue de Tradiciones</h2><p>Desde pabellones gastronómicos ofreciendo desde arepas y tacos hasta ceviche y mofongo, hasta escenarios vibrantes con presentaciones en vivo de artistas internacionales, el festival fue un homenaje a la diversidad latinoamericana.</p><p>"Es emocionante ver cómo nuestras raíces florecen tan lejos de casa. Este evento no solo nos conecta con nuestra cultura, sino que nos permite compartirla con el resto del mundo", comentó María Fernández, organizadora principal del evento.</p><h2>El Rol de las Nuevas Generaciones</h2><p>Una de las grandes sorpresas del festival fue la destacada participación de jóvenes talentos, quienes fusionaron ritmos tradicionales con sonidos urbanos y electrónicos, demostrando que la cultura hispana está en constante evolución y adaptación.</p>',
    categoryId: 'cultura',
    subCategoryId: null,
    authorId: 'redaccion-diaspora',
    heroImageUrl: '/images/cultura_festival.jpg',
    thumbnailUrl: '/images/cultura_festival.jpg',
    publishedAt: '2026-09-03T10:00:00Z',
    status: 'published',
    isMainHero: false,
    showOnMostRead: true,
    mostReadOrder: 3,
    tags: ['cultura', 'madrid', 'festival']
  },
  {
    _id: 'nuevo-programa-vivienda',
    title: 'Gobierno lanza nuevo programa de viviendas subsidiadas exclusivo para dominicanos en el exterior',
    slug: 'nuevo-programa-vivienda',
    summary: 'Con tasas de interés preferenciales y facilidades de pago, el plan "Mi Casa en mi Tierra" busca incentivar el retorno y la inversión en el sector inmobiliario nacional.',
    content: '<p>En un esfuerzo por estrechar lazos con la comunidad en el exterior y dinamizar el sector construcción, el Gobierno ha oficializado el lanzamiento de "Mi Casa en mi Tierra", un ambicioso plan de financiamiento hipotecario diseñado exclusivamente para la diáspora.</p><h2>Facilidades y Requisitos</h2><p>El programa ofrece tasas de interés fijas por 10 años, un subsidio inicial para el pago del enganche y la posibilidad de gestionar todo el proceso de manera 100% virtual a través de los consulados. Los solicitantes solo necesitarán presentar comprobantes de ingresos de sus países de residencia y mantener un historial de envíos constantes al país.</p><p>"Queremos que cada compatriota que se levanta temprano a trabajar en el extranjero sepa que tiene la oportunidad real de tener un techo propio aquí en su tierra", afirmó el Presidente durante el acto de lanzamiento.</p><h2>Reacción de la Comunidad</h2><p>La noticia ha sido recibida con gran entusiasmo en ciudades con alta concentración de dominicanos, como Nueva York y Madrid, donde las consultas en los portales gubernamentales han colapsado temporalmente debido a la alta demanda.</p>',
    categoryId: 'nacional',
    subCategoryId: null,
    authorId: 'redaccion-diaspora',
    heroImageUrl: '/images/nacional_consulado.jpg',
    thumbnailUrl: '/images/nacional_consulado.jpg',
    publishedAt: '2026-09-02T14:00:00Z',
    status: 'published',
    isMainHero: false,
    showOnMostRead: true,
    mostReadOrder: 4,
    tags: ['vivienda', 'gobierno']
  },
  {
    _id: 'innovacion-tech-diaspora',
    title: 'Startups fundadas por migrantes lideran la nueva ola de innovación tecnológica en Silicon Valley',
    slug: 'innovacion-tech-diaspora',
    summary: 'Un reciente estudio revela que el 35% de los nuevos unicornios tecnológicos en Estados Unidos tienen al menos un fundador de origen hispano.',
    content: '<p>La influencia hispana en el mundo de la tecnología está alcanzando niveles históricos. Según un informe publicado por Tech Innovators Group, el 35% de las startups valoradas en más de mil millones de dólares (unicornios) fundadas este año en Silicon Valley cuentan con emprendedores hispanos en su equipo fundador.</p><h2>Superando Barreras</h2><p>Estos emprendedores no solo están creando soluciones disruptivas en áreas como inteligencia artificial, fintech y salud digital, sino que también están abriendo puertas para otros profesionales latinos en la industria.</p><p>"Llegar aquí no fue fácil. Tuvimos que trabajar el doble para conseguir el mismo reconocimiento, pero nuestra resiliencia y perspectiva única nos han dado una ventaja competitiva invaluable", explica Carlos Rivera, CEO de una prometedora empresa de ciberseguridad.</p><h2>Invirtiendo en el Futuro</h2><p>Además de su éxito comercial, muchos de estos fundadores están creando fondos de inversión semilla dedicados exclusivamente a apoyar a startups tecnológicas en América Latina, creando un círculo virtuoso de desarrollo y oportunidades transfronterizas.</p>',
    categoryId: 'actualidad',
    subCategoryId: null,
    authorId: 'redaccion-diaspora',
    heroImageUrl: '/images/actualidad_tech.jpg',
    thumbnailUrl: '/images/actualidad_tech.jpg',
    publishedAt: '2026-09-02T09:00:00Z',
    status: 'published',
    isMainHero: false,
    showOnMostRead: false,
    tags: ['tecnologia', 'startups', 'innovacion']
  },
  {
    _id: 'acuerdo-deportivo-internacional',
    title: 'Grandes Ligas expanden academias y programas de reclutamiento en toda Latinoamérica',
    slug: 'acuerdo-deportivo-internacional',
    summary: 'Una millonaria inversión promete transformar la infraestructura deportiva y brindar mejores oportunidades educativas a jóvenes prospectos.',
    content: '<p>En un movimiento estratégico para asegurar el futuro del béisbol profesional, la organización de las Grandes Ligas (MLB) ha anunciado un ambicioso plan de expansión que triplicará su presencia e inversión en academias de desarrollo a lo largo de Latinoamérica durante los próximos cinco años.</p><h2>Más allá del Deporte</h2><p>El nuevo programa no se limitará al entrenamiento físico. Las nuevas instalaciones requerirán, por mandato, ofrecer educación secundaria completa, clases intensivas de inglés y programas de educación financiera para todos los jóvenes reclutados.</p><p>"Hemos entendido que nuestra responsabilidad va más allá de producir buenos atletas; debemos formar ciudadanos íntegros preparados para la vida, sin importar si llegan a las mayores o no", declaró el Comisionado de la MLB.</p><h2>Impacto Comunitario</h2><p>Se espera que la construcción y mantenimiento de estas nuevas academias genere miles de empleos directos e indirectos en las comunidades locales, consolidando al deporte no solo como una vía de escape, sino como un motor de desarrollo económico sostenible.</p>',
    categoryId: 'deportes',
    subCategoryId: null,
    authorId: 'redaccion-diaspora',
    heroImageUrl: '/images/deportes_baseball.jpg',
    thumbnailUrl: '/images/deportes_baseball.jpg',
    publishedAt: '2026-09-01T16:00:00Z',
    status: 'published',
    isMainHero: false,
    showOnMostRead: false,
    tags: ['deportes', 'beisbol']
  }
];
`;
fs.writeFileSync('src/lib/mock-data.ts', mockDataContent, 'utf8');
console.log('Successfully wrote clean mock-data.ts');
