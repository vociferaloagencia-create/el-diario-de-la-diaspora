const fs = require('fs');
let code = fs.readFileSync('src/components/site/Header.tsx', 'utf8');

const target = 'className="lg:hidden relative z-50 hover:bg-slate-100 dark:hover:bg-slate-900"';
const replacement = 'className="relative z-50 hover:bg-slate-100 dark:hover:bg-slate-900"';

if (code.includes(target)) {
  code = code.replace(target, replacement);
  fs.writeFileSync('src/components/site/Header.tsx', code, 'utf8');
  console.log('Successfully removed lg:hidden');
} else {
  console.log('Target not found in Header.tsx');
}
