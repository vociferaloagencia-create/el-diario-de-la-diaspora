# TEST_INFRA — Comprehensive E2E Testing Infrastructure

## Overview
This document defines the test architecture, methodology, and infrastructure for the end-to-end (E2E) verification of **El Diario de la Diáspora**. The test suite employs an opaque-box, requirement-driven 4-tier model designed to exercise authentication flows, edge routing middleware, non-blocking resilience timeouts, role-based access control, editorial workflows, and reader experiences.

---

## 1. Core Testing Principles

### 1.1 Requirements-Driven & Authoritative Output Derivation
All test assertions and expected outputs are derived strictly from:
- `ORIGINAL_REQUEST.md`: Requirements R1 (Authentication & Resiliency), R2 (Editorial Panel & CMS), and Acceptance Criteria.
- `PROJECT.md`: Architecture, Interface Contracts (§Auth Layer ↔ Middleware, §Middleware ↔ Dashboard Routes), and Feature Inventory.

Tests avoid testing implementation trivia or internal variables; instead, tests observe public contract interfaces, HTTP redirect statuses and headers, cookie mutations, and UI permission boundaries.

### 1.2 The 4-Tier Test Architecture

```
+--------------------------------------------------------------------------+
| Tier 4: Real-World Workloads                                            |
|   - Editorial article publishing & category workflows                   |
|   - Reader end-to-end content consumption & navigation                  |
+--------------------------------------------------------------------------+
| Tier 3: Cross-Feature Combinations                                       |
|   - Registration -> Profile -> Admin probe -> Bounce-back               |
|   - Admin login -> Overview -> Logout -> Cookie wipe -> Protected route |
|   - Privilege escalation immunity across session updates                |
+--------------------------------------------------------------------------+
| Tier 2: Boundary & Corner Cases                                         |
|   - Empty, malformed, and mismatched credential validation              |
|   - 1.8s (1800ms) Firestore network freeze & AdBlock fallback           |
|   - Unauthorized reader access to /dashboard and admin sub-paths        |
|   - Unauthenticated access to /dashboard and /no-access                 |
|   - Zero redirect loop guarantee between /login and /dashboard/profile  |
+--------------------------------------------------------------------------+
| Tier 1: Feature Coverage (Isolated Happy Paths)                         |
|   - Email/Password auth & role defaults                                 |
|   - Google OAuth popup configuration with prompt: 'select_account'      |
|   - Synchronous cookie synchronization (firebaseAuthToken, userRole)    |
|   - Edge middleware route guards (/dashboard*, /dashboard/profile)      |
|   - Public reader queries (categories, settings, articles, hero, reels) |
+--------------------------------------------------------------------------+
```

### 1.3 Progressive Testability & Self-Containment
Each test case is completely isolated:
- Dedicated cookie jar and simulated session state per test.
- No dependency on global execution order.
- Clean setup and teardown for each scenario.

---

## 2. Test Harness Architecture

The test harness runs under Node.js / `tsx`, providing high-speed, 100% deterministic test execution without requiring heavy external browser binaries while directly validating actual runtime components:

### 2.1 Next.js Edge Middleware Emulation
Next.js Edge middleware relies on `NextRequest` and `NextResponse` from `next/server`. The harness instantiates genuine `NextRequest` objects with specified URL paths, search parameters, and cookie headers (`firebaseAuthToken`, `userRole`). It invokes `middleware(request)` and asserts on:
- HTTP Response Status (e.g., 307 Temporary Redirect vs 200 Next pass-through).
- `location` header values (e.g., `/login?redirect=...` or `/dashboard/profile`).
- Set-Cookie response directives (e.g., cookie expiration or renewal).

### 2.2 Auth & Cookie Synchronization Harness
The browser environment is emulated with an in-memory document cookie store and storage interface:
- Captures `syncAuthCookies(user, role)` invocations.
- Asserts presence, expiration (`max-age=604800` vs `expires=1970`), path (`/`), and values for both `firebaseAuthToken` and `userRole`.
- Verifies `clearAuthCookies()` completely clears credentials on sign out.

### 2.3 Non-blocking 1.8s Timeout & AdBlock Simulation
To verify the 1.8s timeout requirement (`withTimeout(..., 1800)`):
- The test harness simulates hanging Firestore network requests (mimicking browser adblockers intercepting `firestore.googleapis.com`).
- The harness measures wall-clock execution time to ensure the timeout fires at or near 1800ms (within a strict window) rather than hanging indefinitely.
- The harness confirms graceful fallback to a local reader profile (`role: 'user'`) without unhandled promise rejections.

---

## 3. Test Suites Layout

The test files reside in `tests/e2e/`:

```
tests/e2e/
├── harness/
│   ├── index.ts             # Test runner, assertion library & reporting
│   ├── env.ts               # Browser/DOM cookie jar & Next.js request mock helpers
│   └── fixtures.ts          # Standard user identities and test payloads
├── tier1-feature-coverage.test.ts       # Tier 1 tests
├── tier2-boundary-corner-cases.test.ts  # Tier 2 tests
├── tier3-cross-feature-combinations.test.ts # Tier 3 tests
└── tier4-real-world-workloads.test.ts   # Tier 4 tests
scripts/
└── run-e2e-tests.js         # Unified entrypoint runner script
```

---

## 4. Execution Commands

The test runner can be executed directly from the project root:

```bash
# Direct runner execution:
node scripts/run-e2e-tests.js

# Alternative via tsx:
npx.cmd tsx scripts/run-e2e-tests.js
```

### Exit Codes
- `0`: All tests passed across all 4 tiers.
- `1`: One or more tests failed (detailed diagnostic stack trace printed).
